<h1 align=center>
  <img src="https://github.com/user-attachments/assets/9d626e0f-0601-4640-8981-ad66d8ac4853" alt="TypeWords" style="width: 500px;"/>
</h1>

<p align="center">
  <a href="/README.md">English</a> |
  <a href="/docs/README.es.md">Español</a> |
  <a href="/docs/README.de.md">Deutsch</a> |
  <a href="/docs/README.fr.md">Français</a> |
  <a href="/docs/README.pt.md">Português</a> |
  <a href="/docs/README.ru.md">Русский</a> |
  <a href="/docs/README.uk.md">Українська</a> |
  <a href="/docs/README.ja.md">日本語</a> |
  <a href="/docs/README.ko.md">한국인</a> |
  <a href="/docs/README.th.md">ไทย</a> |
  <a href="/docs/README.vi.md">Tiếng Việt</a> |
  <a href="/docs/README.id.md">Bahasa Indonesia</a> |
  <a href="/docs/README.zh-TW.md">繁體中文</a> |
  <a href="/docs/README.zh-CN.md">简体中文</a> 
</p>

<p align="center">
  <b>Learn English, one keystroke at a time; smarter memorization, more efficient learning - an open-source word and article practice tool</b>
</p>

## Project Introduction

<https://www.bilibili.com/video/BV1QwYv6eEAS>

## Online Access

<https://typewords.cc>

<img width="1920" height="1440" alt="practice words" src="/public/imgs/words.png" />
<img width="1920" height="1440" alt="practice articles" src="/public/imgs/articles.png" />

## Features

### Word Practice

- Practice modes: Follow-along / Dictation / Self-test / Spelling from memory
- Smart mode: Automatically calculates learning words based on memory curves, deepening memory through dictation
- Free mode: No restrictions, plan your own learning
- Provides phonetics, pronunciation (American/British), example sentences, phrases, synonyms, root words, etymology, error statistics, and more

### Article Memorization

- Built-in classic textbooks; you can also add or import articles with one-click translation and bilingual comparison
- Follow-along + dictation dual modes, sentence-by-sentence input with automatic pronunciation for more efficient memorization
- Supports listening while writing from memory to reinforce learning

### Favorites, Wrong Words, Mastered

- Words typed incorrectly while learning are automatically added to your wrong word book for later review
- Actively add words to mastered to automatically skip them in future sessions
- Add words to favorites for consolidation and review

### Highly Customizable

- Rich keyboard sound effects
- Customizable shortcuts
- Highly configurable settings

### Clean and Efficient

- Clean design, modern UI, ad-free
- Refreshing interface, simple operation
- No forced subscription to any platform

### Vocabulary Library

Built-in commonly used vocabulary including CET-4, CET-6, GMAT, GRE, IELTS, SAT, TOEFL, Graduate English, TEM-4, TEM-8, and more (official website only).
Designed to meet most users' vocabulary learning needs. Community contributions of additional vocabulary are welcome.

## Running the Project

### Japanese learning / 日语学习

- 在学习语言入口切换英语与日语，或访问 `/japanese`。日语界面提供平假名、片假名、浊音、拗音、40 个入门词汇及例句、两篇短文。
- 支持罗马音与日语输入法、跟打与回忆练习、错题复习、浏览器本地进度保存。日语进度独立保存，不包含在原有英语备份和 Supabase 同步中。
- `public/audio/japanese/` 内置 238 段 MP3（约 2.4 MiB）。单词、例句和短文可直接播放，无需安装系统语音。音源信息和授权位于该目录的 `README.txt` 和 `LICENSE-Mei.txt`。
- 导入的自定义文章逐句练习，使用设备的日语语音朗读；目前没有接入付费在线合成服务。
- 可导入 Excel（第一张表）、CSV、TSV、JSON 日语词书，每本最多 3,000 个词条、文件最多 2 MB，最多保存 10 本。页面提供模板，支持单词、假名、中文释义、例句及其读音和翻译。未填写假名的词书使用日语输入法练习。自定义词书和进度保存在当前浏览器，原始上传文件请自行保留。
- 运行 `pnpm run test:japanese` 检查输入判定和音频包。新增音频：`pnpm run audio:japanese:manifest`，然后按 `scripts/generate-japanese-audio.py` 中的说明生成 MP3。Python 工具只在制作音频时需要。

Hexo + GitHub Pages（本项目配置的站点为 `https://fbyxdyn.github.io/`）：

```powershell
pnpm run generate:hexo
node scripts/integrate-hexo.mjs F:/blog             # 准备可审阅的配置
node scripts/integrate-hexo.mjs F:/blog --apply     # 备份配置并写入 source/typewords
cd F:/blog
npx hexo generate
# 确认本地页面后，发布：npx hexo deploy
```

博客导航“日语学习”指向 `/typewords/japanese/`。`skip_render` 保证应用文件不被 Hexo 改写，`include` 和 `.nojekyll` 保证 `_nuxt` 等资源能够发布。构建同时提供本版本源码下载。

#### Note: This project can run standalone with data saved locally. Manual backup is required when switching devices; this does not affect normal usage.

This project is built with `Nuxt` and requires a Node.js environment.

1. Install NodeJS, refer to the [official documentation](https://nodejs.org/en/download)
2. The project is large. It's recommended to use `git clone --depth 1 https://github.com/zyronon/TypeWords.git` to clone only the latest commit. GitHub's Download ZIP feature will not work properly.
3. In the project root directory, open a terminal and run `pnpm install` to download dependencies.
4. Run `pnpm run dev` to start the project. The default address is [`http://localhost:5567`](http://localhost:5567)
5. Open [`http://localhost:5567`](http://localhost:5567) in your browser to access the project.
6. Run `pnpm run generate` to build the project files.

## Features and Suggestions

The project is currently in early development, with new features being added continuously. If you have any suggestions or feature requests, feel free to open an `Issue`.
If you like the design philosophy of this software, please submit a `PR`. Thank you for your support!

## Contributing Guide

[Contributing Guidelines](/docs/CONTRIBUTING.md)

If you're interested in this project, we welcome your contributions and will provide as much help as possible.

Before contributing, please communicate with the developers to avoid code conflicts.

Thank you again for your contributions!


## ❤️ Support TypeWords
If TypeWords has been helpful to you, feel free to sponsor the project to support server operation and future development.  
Of course, sponsorship is not required for use—sharing the project, submitting feedback, or contributing code are also highly valuable forms of support.

<img width="300" height="390" alt="practice words" src="/public/imgs/zhifubao.png" />
<img width="300" height="390" alt="practice words" src="/public/imgs/weixin.png" />

