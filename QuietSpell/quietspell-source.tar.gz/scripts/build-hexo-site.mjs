import { spawnSync } from 'node:child_process'
import { writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const env = {
  ...process.env,
  NUXT_APP_BASE_URL: '/QuietSpell/',
  ORIGIN: 'https://fbyxdyn.github.io',
  QUIETSPELL_SOURCE_ARCHIVE: 'true',
}
const built = spawnSync(process.execPath, [path.join(root, 'node_modules/nuxt/bin/nuxt.mjs'), 'generate'], {
  cwd: root,
  env,
  stdio: 'inherit',
})
if (built.status !== 0) process.exit(built.status ?? 1)
writeFileSync(
  path.join(root, '.output/public/index.html'),
  '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>QuietSpell</title><meta http-equiv="refresh" content="0;url=/QuietSpell/japanese/"><link rel="canonical" href="https://fbyxdyn.github.io/QuietSpell/japanese/"><p><a href="/QuietSpell/japanese/">进入 QuietSpell 日语学习</a></p></html>'
)
// Distribute the corresponding source alongside the GPL application.
const archive = spawnSync(
  'tar',
  [
    '-czf',
    '.output/public/quietspell-source.tar.gz',
    'app',
    'docs',
    'i18n',
    'public',
    'scripts',
    'LICENSE',
    'README.md',
    'package.json',
    'pnpm-lock.yaml',
    'pnpm-workspace.yaml',
    'nuxt.config.ts',
    'uno.config.ts',
    'tsconfig.json',
    'gulpfile.js',
  ],
  { cwd: root, stdio: 'inherit' }
)
if (archive.error || archive.status !== 0)
  throw archive.error ?? new Error('Failed to create the corresponding source archive. Ensure tar is installed.')
console.log('Hexo site and corresponding source archive generated in .output/public.')
