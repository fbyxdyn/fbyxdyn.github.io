"""Render source contacts or export only the separately reviewed example batch."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];TMP=ROOT/'tmp/pdfs'
p=argparse.ArgumentParser();p.add_argument('--export',action='store_true');args=p.parse_args()
book_path=ROOT/'app/core/japanese/books/n3-pdf-0.json'
book=json.loads(book_path.read_text(encoding='utf-8'))
entries={e['source']['number']:e for e in book['entries']}
rows=[]
for line in (ROOT/'scripts/n3-kanzen-reviewed-examples.txt').read_text(encoding='utf-8').splitlines():
    if not line.strip() or line.startswith('#'):continue
    number,text,meaning=line.split('|',2)
    rows.append((int(number),text,meaning))
assert len({r[0] for r in rows})==len(rows)
if args.export:
    spec=importlib.util.spec_from_file_location('n3_source',ROOT/'scripts/build-n3-wordbooks.py')
    s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
    out=[]
    for n,text,meaning in rows:
        e=entries[n]
        reading=''.join(e['reading'] if t['string']==e['text'] else
                        s.hiragana(t['read'] if t['pos']!='記号' else t['string'])
                        for t in s.pyopenjtalk.run_frontend(text))
        # Both dictionaries otherwise return きゅうじ; the scanned ruby is くじ.
        if n==1066:reading=reading.replace('きゅうじ','くじ')
        if n in (450,851):reading=reading.replace('あした','あす')
        out.append({'id':e['id'],'text':e['text'],'reading':e['reading'],
                    'examples':[{'text':text,'reading':reading,'meaning':meaning}],
                    'detailsSource':f"新完全原书 OCR 校订例句（PDF 第 {e['source']['page']} 页；译文重新整理，本地待审核）"})
    folder=ROOT/'output/n3-books/kanzen'
    result={'sourceBookSha256':hashlib.sha256(book_path.read_bytes()).hexdigest(),'entries':out}
    (folder/'source-examples.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Exported',len(out),'reviewed examples')
else:
    from PIL import Image,ImageDraw,ImageFont
    cells={}
    for f in (TMP/'recognized-cells-v4').glob('b0-*.json'):
        for c in json.loads(f.read_text(encoding='utf-8')):cells[c['number']]=c
    font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',18)
    rows.sort();page=None
    for start in range(0,len(rows),20):
        canvas=Image.new('RGB',(2600,5*175),'#ddd');draw=ImageDraw.Draw(canvas)
        for i,(n,_,_) in enumerate(rows[start:start+20]):
            c=cells[n]
            if page!=c['page']:
                page=c['page'];name=f'b0-p{page:03}'
                meta=json.loads((TMP/'ja'/f'{name}-1.json').read_text(encoding='utf-8'))
                im=Image.new('RGB',(meta['width'],meta['fullHeight']),'white')
                im.paste(Image.open(TMP/'tiles'/f'{name}-0.png'),(0,0))
                im.paste(Image.open(TMP/'tiles'/f'{name}-1.png'),(0,meta['offsetY']))
            crop=im.crop((690,c['top']-12,1755,c['top']+190));crop.thumbnail((640,145))
            x=i%4*650;y=i//4*175
            draw.text((x+5,y+1),f"{n} {entries[n]['text']} p{page}",fill='black',font=font)
            canvas.paste(crop,(x+5,y+28))
        canvas.save(TMP/f'proof-kanzen-examples-{start//20}.png')
    print(len(rows),'examples,',(len(rows)+19)//20,'contact sheets')
