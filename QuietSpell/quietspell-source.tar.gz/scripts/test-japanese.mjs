import assert from 'node:assert/strict'
import { readFile, stat } from 'node:fs/promises'
import test from 'node:test'
import { JAPANESE_LESSONS } from '../app/core/japanese/content.ts'
import { createCustomArticle, getRomaji, isJapaneseAnswerCorrect, kanaToRomaji } from '../app/core/japanese/input.ts'
import { parseJapaneseWordbookRows, parseJapaneseWordbookText } from '../app/core/japanese/wordbook.ts'
import { createJapaneseSession, shouldHandleJapaneseKey } from '../app/core/japanese/learning.ts'
import { enrichJapaneseEntry, getJapaneseExamples } from '../app/core/japanese/details.ts'

test('rich Japanese wordbooks survive saving and re-import without dropping teaching details', () => {
  const input = [
    {
      word: '友達',
      reading: 'ともだち',
      meaning: '朋友',
      partOfSpeech: '名词',
      senses: [{ meaning: '朋友', note: '日常用语' }],
      example: { text: '友達と映画を見ます。', reading: 'ともだちとえいがをみます。', meaning: '和朋友看电影。' },
      examples: [{ text: '友達に会います。', reading: 'ともだちにあいます。', meaning: '见朋友。' }],
      phrases: [{ text: '友達になる', reading: 'ともだちになる', meaning: '成为朋友' }],
      synonyms: [{ text: '友人', reading: 'ゆうじん', meaning: '朋友', note: '较正式' }],
      usage: '留意语体差别。',
      detailsSource: '学习补充（自编例句）',
    },
  ]
  const book = parseJapaneseWordbookRows(input)
  assert.equal(book.entries[0].synonyms[0].note, '较正式')
  assert.equal(getJapaneseExamples(book.entries[0]).length, 2)
  assert.deepEqual(parseJapaneseWordbookRows(JSON.parse(JSON.stringify(book.entries))), book)
  assert.throws(() => parseJapaneseWordbookRows([{ ...input[0], synonyms: [{ meaning: '缺少日文' }] }]), /不能为空/)
  assert.throws(() => parseJapaneseWordbookRows([{ ...input[0], examples: '无效 JSON' }]), /JSON/)
})

test('supplement matching distinguishes homographs and cannot replace the original OCR identity or meaning', () => {
  const word = {
    id: 'keep-id',
    text: '明日',
    reading: 'あした',
    meaning: '明天',
    source: { book: 0, page: 7, number: 3 },
  }
  const supplement = { text: '明日', reading: 'あした', usage: '常用读法', examples: [] }
  assert.equal(enrichJapaneseEntry(word, [{ ...supplement, reading: 'あす' }]), word)
  const merged = enrichJapaneseEntry(word, [supplement])
  assert.equal(merged.id, word.id)
  assert.equal(merged.meaning, word.meaning)
  assert.deepEqual(merged.source, word.source)
  assert.equal(merged.usage, '常用读法')
  const example = { text: '友達に会います。', reading: 'ともだちにあいます。', meaning: '见朋友。' }
  assert.equal(getJapaneseExamples({ ...word, example, examples: [example] }).length, 1)
})

test('daily plan excludes new words from reviews, caps reviews and follows the English stage order', () => {
  const entries = Array.from({ length: 12 }, (_, i) => ({ id: String(i), text: '猫', reading: 'ねこ', meaning: '猫' }))
  const plan = createJapaneseSession({
    lessonId: 'test',
    entries,
    start: 6,
    daily: 2,
    reviewRatio: 2,
    mode: 'system',
    dueIds: ['6', '0', '0', '1', '2', '3', '4', 'deleted'],
  })
  assert.equal(plan.newCount, 2)
  assert.equal(plan.reviewCount, 4)
  assert.equal(plan.tasks.length, 18)
  assert.deepEqual(
    plan.tasks.slice(0, 6).map(t => [t.entryId, t.stage]),
    [
      ['6', 'follow'],
      ['7', 'follow'],
      ['6', 'listen'],
      ['7', 'listen'],
      ['6', 'recall'],
      ['7', 'recall'],
    ]
  )
  assert.deepEqual(
    plan.tasks.filter(t => t.review && t.stage === 'identify').map(t => t.entryId),
    ['0', '1', '2', '3']
  )
  assert.equal(
    plan.tasks.some(t => t.review && t.entryId === '6'),
    false
  )
})

test('finished books do not restart silently, review-only and zero-review plans retain their meaning', () => {
  const entries = JAPANESE_LESSONS[0].entries
  const options = {
    lessonId: 'kana',
    entries,
    start: entries.length,
    daily: 2,
    reviewRatio: 0,
    mode: 'listen',
    dueIds: [entries[0].id],
  }
  assert.equal(createJapaneseSession(options).tasks.length, 0)
  const review = createJapaneseSession({ ...options, reviewOnly: true })
  assert.equal(review.newCount, 0)
  assert.equal(review.reviewCount, 1)
  assert.equal(review.tasks[0].stage, 'listen')
})

test('IME candidate confirmation, Safari composition ordering, repeats and legacy keycode never submit', () => {
  assert.equal(shouldHandleJapaneseKey({ key: 'Enter', isComposing: true }, false, 1000), false)
  assert.equal(shouldHandleJapaneseKey({ key: 'Enter' }, true, 1000), false)
  assert.equal(shouldHandleJapaneseKey({ key: 'Enter', keyCode: 229 }, false, 1000), false)
  assert.equal(shouldHandleJapaneseKey({ key: 'Enter' }, false, 0), false)
  assert.equal(shouldHandleJapaneseKey({ key: 'Enter', repeat: true }, false, 1000), false)
  assert.equal(shouldHandleJapaneseKey({ key: 'Space' }, false, 1000), false)
  assert.equal(shouldHandleJapaneseKey({ key: 'Enter' }, false, 1000), true)
})

const sample = (reading, extra = {}) => ({ id: 'test', text: reading, reading, meaning: '', ...extra })

test('kana readings cover contracted sounds, gemination, nasal separation and katakana long vowels', () => {
  assert.equal(kanaToRomaji('がっこう'), 'gakkou')
  assert.equal(kanaToRomaji('きょう'), 'kyou')
  assert.equal(kanaToRomaji('しんよう'), "shin'you")
  assert.equal(kanaToRomaji('まっちゃ'), 'matcha')
  assert.equal(kanaToRomaji('コーヒー'), 'ko-hi-')
  assert.equal(kanaToRomaji('ﾍﾞｯﾄﾞ'), 'beddo')
})

test('common romanization variants and full-width input are accepted without accepting misspellings', () => {
  for (const [reading, answer] of [
    ['し', 'si'],
    ['ち', 'ti'],
    ['つ', 'tu'],
    ['ふ', 'hu'],
    ['しゃ', 'sya'],
    ['じゃ', 'zya'],
    ['コーヒー', 'koohii'],
    ['ん', 'nn'],
  ]) {
    assert.ok(isJapaneseAnswerCorrect(answer, sample(reading), 'romaji'), `${reading}: ${answer}`)
  }
  assert.ok(isJapaneseAnswerCorrect('ＳＨＩ', sample('し'), 'romaji'))
  assert.ok(isJapaneseAnswerCorrect('n', sample('ん'), 'romaji'))
  assert.ok(isJapaneseAnswerCorrect("shin'you", sample('しんよう'), 'romaji'))
  assert.ok(isJapaneseAnswerCorrect('shinnyou', sample('しんよう'), 'romaji'))
  assert.equal(isJapaneseAnswerCorrect('gakou', sample('がっこう'), 'romaji'), false)
  assert.equal(isJapaneseAnswerCorrect('kohi', sample('コーヒー'), 'romaji'), false)
})

test('Japanese input accepts original text or reading, preserves script and significant sounds', () => {
  const entry = sample('がっこう', { text: '学校' })
  assert.ok(isJapaneseAnswerCorrect('学校', entry, 'japanese'))
  assert.ok(isJapaneseAnswerCorrect('がっこう', entry, 'japanese'))
  assert.equal(isJapaneseAnswerCorrect('がこう', entry, 'japanese'), false)
  assert.equal(isJapaneseAnswerCorrect('ア', sample('あ'), 'japanese'), false)
  assert.ok(isJapaneseAnswerCorrect('ｱ', sample('ア'), 'japanese'))
  assert.ok(isJapaneseAnswerCorrect('か\u3099っこう', entry, 'japanese'))
  assert.equal(isJapaneseAnswerCorrect('。', sample('', { text: '今日は晴れです。' }), 'japanese'), false)
  assert.equal(isJapaneseAnswerCorrect('', entry, 'japanese'), false)
})

test('particles have intentional pronunciation variants and punctuation can be omitted', () => {
  const greeting = JAPANESE_LESSONS.find(item => item.id === 'greetings').entries[0]
  assert.ok(isJapaneseAnswerCorrect('konnichiwa', greeting, 'romaji'))
  assert.ok(isJapaneseAnswerCorrect('konnichiha', greeting, 'romaji'))
  const sentence = JAPANESE_LESSONS.find(item => item.id === 'introduction').entries[1]
  assert.ok(isJapaneseAnswerCorrect('WATASHI WA GAKUSEI DESU', sentence, 'romaji'))
  assert.ok(isJapaneseAnswerCorrect('わたしはがくせいです', sentence, 'japanese'))
})

test('custom articles split Japanese punctuation and lines, enforce size and do not invent readings', () => {
  const entries = createCustomArticle('今日は晴れです。\n学校に行きます！元気ですか？')
  assert.equal(entries.length, 3)
  assert.equal(entries[1].text, '学校に行きます！')
  assert.equal(entries[0].reading, '')
  assert.throws(() => createCustomArticle('hello world'))
  assert.throws(() => createCustomArticle('あ'.repeat(20001)))
})

test('all built-in lessons have usable answers and locally bundled pronunciation, including examples', async () => {
  const root = new URL('../public/audio/japanese/', import.meta.url)
  const manifest = JSON.parse(await readFile(new URL('../app/core/japanese/audio-manifest.json', import.meta.url)))
  const ids = new Set()
  assert.equal(JAPANESE_LESSONS[0].entries.length, 46)
  assert.equal(JAPANESE_LESSONS[1].entries.length, 46)
  for (const lesson of JAPANESE_LESSONS) {
    assert.ok(!ids.has(lesson.id))
    ids.add(lesson.id)
    assert.equal(new Set(lesson.entries.map(item => item.id)).size, lesson.entries.length)
    for (const entry of lesson.entries) {
      assert.ok(isJapaneseAnswerCorrect(getRomaji(entry), entry, 'romaji'), entry.text)
      assert.ok(isJapaneseAnswerCorrect(entry.text, entry, 'japanese'), entry.text)
      if (lesson.kind === 'words') assert.ok(entry.example, `Missing example for ${entry.text}`)
      for (const text of [entry.text, entry.example?.text].filter(Boolean)) {
        assert.match(manifest[text] ?? '', /^[a-f0-9]{20}\.mp3$/)
        assert.ok((await stat(new URL(manifest[text], root))).size > 1000)
      }
    }
  }
})

test('CSV and TSV import handles Chinese headers, BOM, quoted commas and multiline examples', () => {
  const csv =
    '\uFEFF单词,假名,释义,例句,例句翻译\r\n猫,ねこ,猫,"猫が好きです。\n犬も好きです。","I like cats, and dogs."\r\n'
  const book = parseJapaneseWordbookText(csv, '动物')
  assert.equal(book.title, '动物')
  assert.equal(book.entries[0].example.text, '猫が好きです。\n犬も好きです。')
  assert.equal(book.entries[0].example.meaning, 'I like cats, and dogs.')
  assert.equal(parseJapaneseWordbookText('word\tkana\tmeaning\n学校\tがっこう\t学校').entries[0].reading, 'がっこう')
  assert.throws(() => parseJapaneseWordbookText('word,kana\n"猫,ねこ'), /引号/)
})

test('JSON wordbooks preserve examples and support existing Word translation arrays', () => {
  const book = parseJapaneseWordbookText(
    JSON.stringify({
      name: '测试词书',
      words: [
        {
          word: '学校',
          reading: 'がっこう',
          trans: [{ cn: '学校' }],
          example: { text: '学校に行きます。', reading: 'がっこうにいきます。', meaning: '去学校。' },
        },
        { word: 'ねこ', meaning: '猫' },
      ],
    })
  )
  assert.equal(book.entries[0].meaning, '学校')
  assert.equal(book.entries[0].example.text, '学校に行きます。')
  assert.equal(book.entries[1].reading, 'ねこ')
  // Stored entries are parsed again on reload without losing IDs, readings or examples.
  assert.deepEqual(parseJapaneseWordbookRows(book.entries, book.title), book)
})

test('wordbook import rejects invalid data, enforces limits and removes duplicate words', () => {
  assert.equal(parseJapaneseWordbookRows([{ word: '猫' }, { word: '猫' }]).entries.length, 1)
  assert.equal(parseJapaneseWordbookRows([{ word: '学校' }]).entries[0].reading, '')
  assert.throws(() => parseJapaneseWordbookRows([{ word: '学校', reading: 'gakkou' }]), /假名/)
  assert.throws(() => parseJapaneseWordbookRows([{ meaning: 'missing word' }]), /缺少单词/)
  assert.throws(() => parseJapaneseWordbookRows(Array.from({ length: 3001 }, () => ({ word: '猫' }))), /3,000/)
  assert.throws(() => parseJapaneseWordbookText('['), /JSON/)
  assert.throws(() => parseJapaneseWordbookText('x'.repeat(2000001)), /2 MB/)
})

test('similar-sound notes survive importing and saving separately from synonyms', () => {
  const book = parseJapaneseWordbookRows([
    {
      word: '学校',
      reading: 'がっこう',
      meaning: '学校',
      similarSounds: [
        { text: '格好', reading: 'かっこう', meaning: '样子', note: '首音为清音「か」，不是浊音「が」。' },
      ],
    },
  ])
  assert.equal(book.entries[0].similarSounds[0].reading, 'かっこう')
  assert.equal(book.entries[0].synonyms, undefined)
  assert.deepEqual(parseJapaneseWordbookRows(book.entries), book)
})

test('Excel first-sheet data uses the same validated wordbook schema', async () => {
  const XLSX = await import('xlsx')
  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet([{ 单词: '猫', 假名: 'ねこ', 释义: '猫', 例句: '猫が好きです。' }]),
    '日语'
  )
  const encoded = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' })
  const decoded = XLSX.read(encoded, {
    type: 'buffer',
    sheetRows: 3002,
    cellFormula: false,
    cellHTML: false,
    sheets: 0,
  })
  const book = parseJapaneseWordbookRows(
    XLSX.utils.sheet_to_json(decoded.Sheets[decoded.SheetNames[0]], { defval: '' })
  )
  assert.equal(book.entries[0].reading, 'ねこ')
  assert.equal(book.entries[0].example.text, '猫が好きです。')
})

test('downloadable CSV and JSON templates import successfully', async () => {
  for (const filename of ['japanese-wordbook.csv', 'japanese-wordbook.json']) {
    const book = parseJapaneseWordbookText(
      await readFile(new URL(`../public/templates/${filename}`, import.meta.url), 'utf8')
    )
    assert.ok(book.entries.length >= 2)
    assert.ok(book.entries[0].example.text)
  }
})

test('N3 teaching supplements match real words and keep the original entry identifiers and PDF sources', async () => {
  const supplements = JSON.parse(
    await readFile(new URL('../app/core/japanese/books/n3-enrichment.json', import.meta.url), 'utf8')
  )
  const books = await Promise.all(
    [0, 1].map(async i =>
      JSON.parse(await readFile(new URL(`../app/core/japanese/books/n3-pdf-${i}.json`, import.meta.url), 'utf8'))
    )
  )
  const entries = books.flatMap(book => book.entries)
  assert.ok(supplements.length >= 12)
  for (const item of supplements) {
    const original = entries.find(entry => entry.text === item.text && entry.reading === item.reading)
    assert.ok(original, `No exact source match: ${item.text}/${item.reading}`)
    const merged = enrichJapaneseEntry(original, [item])
    assert.equal(merged.id, original.id)
    assert.equal(merged.meaning, original.meaning)
    assert.deepEqual(merged.source, original.source)
    assert.ok(getJapaneseExamples(merged).length >= 2)
    assert.ok(merged.phrases.length >= 2)
    assert.match(merged.detailsSource, /自编例句/)
    for (const word of item.synonyms ?? []) assert.ok(word.note, `Missing distinction: ${word.text}`)
    parseJapaneseWordbookRows([{ ...item, meaning: original.meaning }])
  }
})
