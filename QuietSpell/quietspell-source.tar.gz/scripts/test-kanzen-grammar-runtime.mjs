import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { createServer } from 'vite'

const root = fileURLToPath(new URL('../', import.meta.url))
const server = await createServer({ configFile: false, root, cacheDir: `${root}.cache/vite-grammar-review-tests`, server: { middlewareMode: true, hmr: false }, logLevel: 'error' })
try {
  const { N3_BOOKS } = await server.ssrLoadModule('/app/core/japanese/n3-books.ts')
  const { isJapaneseAnswerCorrect } = await server.ssrLoadModule('/app/core/japanese/input.ts')
  const source = JSON.parse(await readFile(new URL('../app/core/japanese/books/n3-kanzen-grammar.json', import.meta.url)))
  const grammar = N3_BOOKS.find(book => book.id === source.id)
  assert.equal(grammar.sourceType, 'grammar')
  assert.equal(grammar.entries.length, 211)
  assert.deepEqual(grammar.entries, source.entries)
  for (const entry of grammar.entries) {
    assert.ok(entry.label && entry.usage && entry.source.page, entry.id)
    assert.ok(isJapaneseAnswerCorrect(entry.text, entry, 'japanese'), entry.id + ' written text')
    assert.ok(isJapaneseAnswerCorrect(entry.reading, entry, 'japanese'), entry.id + ' kana reading')
  }
  console.log('Grammar runtime: 211 original texts/readings accepted; independent explanations preserved.')
} finally {
  await server.close()
}
