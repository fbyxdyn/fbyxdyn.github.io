"""Conservative kana/mora comparisons for listening contrasts, without guessing pitch accent."""
import collections,re,unicodedata

def morae(reading):
 result=[]
 for char in reading:
  if char in 'ゃゅょぁぃぅぇぉ' and result and result[-1]!='っ':result[-1]+=char
  else:result.append(char)
 return result
def unvoice(value):
 return ''.join(c for c in unicodedata.normalize('NFD',value) if unicodedata.category(c)!='Mn')
def vowel(value):
 last=value[-1:]
 for letters,v in [('あかがさざただなはばぱまゃやらわぁ','a'),('いきぎしじちぢにひびぴみりぃ','i'),('うくぐすずつづぬふぶぷむゅゆるぅ','u'),('えけげせぜてでねへべぺめれぇ','e'),('おこごそぞとどのほぼぽもょよろをぉ','o')]:
  if last in letters:return v
 return None
def contrast(left,right):
 a=morae(left);b=morae(right)
 if a==b:return (0,'假名读音相同；注意区分词义。')
 expand=str.maketrans('ゃゅょぁぃぅぇぉ','やゆよあいうえお')
 if left.translate(expand)==right.translate(expand):return (1,'近音：注意小写假名；拗音等连读与普通假名分成两个音拍的区别。')
 if len(a)==len(b):
  changes=[(i,x,y) for i,(x,y) in enumerate(zip(a,b)) if x!=y]
  if len(changes)!=1:return None
  i,x,y=changes[0]
  if unvoice(x)==unvoice(y):return (1,f'近音：第{i+1}音拍「{x}／{y}」有清音、浊音或半浊音差别。')
  if len(a)>=3 and (vowel(x)==vowel(y) or i>=2):return (3,f'近音：第{i+1}音拍为「{x}／{y}」，其余音拍相同。')
  return None
 if abs(len(a)-len(b))!=1:return None
 shorter,longer=(a,b) if len(a)<len(b) else (b,a)
 for i,extra in enumerate(longer):
  if longer[:i]+longer[i+1:]!=shorter:continue
  if extra=='っ':return (1,'近音：注意促音「っ」的有无，需要留出短暂停顿。')
  if extra=='ー':return (1,'近音：注意长音「ー」的有无。')
  if i and extra in 'あいうえお' and ((vowel(longer[i-1])==vowel(extra)) or (vowel(longer[i-1])=='o' and extra=='う') or (vowel(longer[i-1])=='e' and extra=='い')):
   return (2,f'近音：注意「{extra}」这一音拍的有无及元音长度。')
 return None

def build_similar_sounds(entries):
 pool={}
 for e in entries:pool[(e['text'],e['reading'])]={'text':e['text'],'reading':e['reading'],'meaning':e['meaning']}
 for text,reading,meaning in [('橋','はし','桥'),('雨','あめ','雨'),('飴','あめ','糖，糖果'),('病院','びょういん','医院'),('美容院','びよういん','美容院'),('紙','かみ','纸'),('髪','かみ','头发'),('ビール','びーる','啤酒'),('おばさん','おばさん','阿姨，伯母等；中年女性'),('おばあさん','おばあさん','奶奶等；老年女性'),('おじさん','おじさん','叔叔，伯父等；中年男性'),('おじいさん','おじいさん','爷爷等；老年男性')]:
  pool.setdefault((text,reading),{'text':text,'reading':reading,'meaning':meaning})
 candidates=list(pool.values());result={}
 for e in entries:
  key=(e['text'],e['reading']);found=[]
  for other in candidates:
   if other['text']==e['text'] or abs(len(other['reading'])-len(e['reading']))>2:continue
   match=contrast(e['reading'],other['reading'])
   if match:found.append((match[0],abs(len(e['reading'])-len(other['reading'])),other['text'],{**other,'note':match[1]}))
  found.sort(key=lambda r:r[:3])
  if found:result[key]=[r[3] for r in found[:3]]
 return result
