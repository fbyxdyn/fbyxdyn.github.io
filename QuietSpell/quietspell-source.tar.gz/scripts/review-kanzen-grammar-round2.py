"""Produce an isolated editorial proposal. Never mutate the shared grammar inputs."""
import copy
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/n3-books/kanzen-grammar'
SOURCE = ROOT / 'app/core/japanese/books/n3-kanzen-grammar.json'
BASE_SHA = 'b3d0cdeb66faa78705f7850e550268e12b8a0329184fe39cd92a9487a1bca93c'

# Values are edited learning notes, not verbatim transcriptions of the scan.
PROPOSALS = {
    'kg-p1-l03-g01': {
        'connection': '動詞・い形容詞の普通形／な形容詞＋な／名詞＋くらい・ぐらい・ほど',
        'reason': '把连体接续写清楚，避免学习者把な形容词的だ直接接到くらい前。',
    },
    'kg-p1-l05-g03': {
        'connection': '名詞等＋から；動詞・い形容詞の普通形／な形容詞＋な・である／名詞＋である＋ことから',
        'reason': '补充ことから前的名词、な形容词接续；原书PDF38页列出了该区别。',
    },
    'kg-p1-l06-g01': {
        'connection': '動詞・い形容詞の普通形＋なら・のなら；名詞・な形容詞＋なら・なのなら（だ不接在なら前）',
        'reason': '区分名词なら与名词なのなら，不让普通形＋なら被理解为学生だなら。',
    },
    'kg-p1-l06-g02': {
        'connection': '動詞て形・い形容詞くて形＋は／名詞・な形容詞＋では；普通形＋のでは（名詞・な形容詞の現在肯定形はなのでは）',
        'reason': '补充非动词条件句接法；原PDF39页下半损坏，作为明确的编辑补充处理。',
    },
    'kg-p1-l08-g03': {
        'connection': '動詞・い形容詞の普通形／な形容詞＋な・である／名詞＋の・な・である＋わけではない；普通形＋というわけではない（名詞・な形容詞のだは省略も可）',
        'reason': '原书PDF46页分别列出わけではない和というわけではない的接续，不能合并为无例外普通形。',
    },
    'kg-p1-l08-g04': {
        'connection': '動詞ない形／い形容詞くない形／な形容詞・名詞＋でない・ではない＋ことはない',
        'reason': '补全双重否定前的非动词形式；参照PDF46页。',
    },
    'kg-p1-l08-g05': {
        'connection': '述語の連体形＋ことは＋同じ述語の普通形・丁寧形＋が（な形容詞の現在肯定形はな＋ことは）',
        'reason': '前后重复的词不必使用相同礼貌形式；补出な形容词接续。',
    },
    'kg-p1-l11-g04': {
        'connection': '自認の用法：動詞た形・ている形／い形容詞の普通形／な形容詞＋な／名詞＋の＋つもりだ。動詞辞書形・ない形＋つもりだは別の「打算」の用法',
        'grammarMeaning': '本课表示“自认为……”：本人这样认定，但实际情况或别人的看法未必如此。区别于辞书形・ない形＋つもりだ所表示的打算。',
        'reason': '重要修正：PDF58页该语法点是自认，原书明确排除本用法的动词辞书形・ない形；现有接续却仅写这两种形式，且与若いつもり例句不符。',
    },
    'kg-p1-a13': {
        'connection': '動詞・い形容詞の連体形／な形容詞＋な／名詞＋だけ',
        'reason': '明确だけ前的な形容词形式，避免泛用普通形导致接错だ。',
    },
    'kg-p1-a14': {
        'connection': '動詞可能形・辞書形／い形容詞／な形容詞＋な＋だけ（例：食べられるだけ・好きなだけ）',
        'reason': '当前例句是好きなだけ，原说明只写动词，补出与例句对应的な形容词。',
    },
    'kg-p1-c01': {
        'connection': '説明する内容の連体形＋ことだ（動詞・い形容詞の普通形／な形容詞＋な／名詞＋である等）',
        'reason': '说明こと名词化所需连体形式，不能机械套用名词＋だこと。',
    },
    'kg-p1-c04': {
        'connection': '場面を表す動詞・い形容詞の普通形／な形容詞＋な／名詞＋な＋の＋知覚を表す動詞',
        'reason': '补充の名词化接续的だ→な例外。',
    },
    'kg-p1-c06': {
        'connection': '動詞・い形容詞の普通形／な形容詞・名詞＋な＋のは＋強調したい情報＋だ',
        'reason': '把のは前名词、な形容词的形式写明。',
    },
    'kg-p1-d01': {
        'connection': '動詞・い形容詞の普通形＋かのようだ／名詞・な形容詞＋であるかのようだ；名詞＋のようだ',
        'reason': '补清かのようだ的名词接法；PDF77页有である的提示。',
    },
    'kg-p1-d02': {
        'connection': '動詞・い形容詞の普通形／な形容詞＋な・である／名詞＋の・である＋ように',
        'reason': '参照PDF77页，把比较用ように前的名词、な形容词形式明确列出。',
    },
    'kg-p1-d04': {
        'connection': '動詞辞書形・た形・ている形＋ように（例：前に話したように）',
        'reason': 'PDF78页此项是前置表达，不宜扩展成所有普通形均可直接接。',
    },
    'kg-p1-d06': {
        'connection': '動詞辞書形・ない形＋ように（と）＋頼む・言う・注意する等',
        'reason': '请求、指示内容通常用辞书形或ない形，不应泛写普通形；参照PDF78页。',
    },
    'kg-p1-d07': {
        'connection': '動詞ます・ません＋ように（例：合格できますように・雨が降りませんように）',
        'reason': '明确否定祈愿形式，避免把ます形误理解为去ます后的语干。',
    },
    'kg-p1-e01': {
        'connection': '動詞・い形容詞の普通形／な形容詞＋な・である／名詞＋の・な・である＋わけだ；普通形＋というわけだ',
        'reason': '按PDF81页区分直接接わけ与引用というわけ。',
    },
    'kg-p1-f01': {
        'connection': '名詞（＋助詞）／動詞辞書形・ている形＋ばかり',
        'reason': 'PDF87页本项不宜写成任意动词普通形；たばかり另有独立条目。',
    },
    'kg-p1-f03': {
        'connection': '名詞（＋助詞）／動詞・い形容詞の普通形／な形容詞＋な・である／名詞＋である＋ばかりでなく',
        'reason': '补清な形容词接法；名词可直接接，也可用である，参照PDF88页。',
    },
    'kg-p1-i22': {
        'translation': '如果可以选择，我倒希望自己生来就是男性。',
        'reason': '生まれたかった是对既成事实的反事实愿望，不能简单译成曾经有过的愿望。',
    },
    'kg-p2-l01-g02': {
        'connection': '動詞辞書形・ない形＋ように（と）／動詞て形＋ほしいと・動詞ない形＋でほしいと',
        'reason': '补充否定请求ないでほしいと；PDF117页明确列出。',
    },
    'kg-p2-l01-g03': {
        'connection': '普通形＋かどうか；疑問詞を含む普通形＋か（名詞・な形容詞の現在肯定形はだを付けない）',
        'reason': '嵌入式疑问句必须说明名词、な形容词的だ省略，例如学生かどうか。',
    },
    'kg-p2-l02-g01': {
        'connection': '動詞・い形容詞の普通形／な形容詞＋な／名詞＋の＋名詞',
        'reason': 'PDF119页同时列出な形容词和名词的例外，现说明漏了名词＋の。',
    },
    'kg-p3-l01-g01': {
        'translation': '世界上有许多拥有不同文化的国家。',
        'reason': '消除中文译文“有着拥有”的重复。',
    },
    'kg-p3-l05-g03': {
        'translation': '我被老师要求重写了作文。',
        'reason': '突出使役受身的被要求视点，与单纯使役的“老师让我……”区分。',
    },
    'kg-p3-l09-g02': {
        'grammarMeaning': 'そのため说明原因导致的结果；したがって引出结论；そこで说明针对前项采取的行动；すると说明随后出现的结果或发现。它们有关联，但不能任意互换。',
        'reason': '此项合并四种连接词，需提示各自作用，以免把そこで等同于一般因果。',
    },
    'kg-p3-l10-g04': {
        'connection': '動詞ない形去ない＋ず（する→せず、来る→来ず〔こず〕）／い形容詞去い＋く等',
        'reason': '补出する→せず和くる→こず，原先语干＋ず容易产生しず；PDF155页含使用せず。',
    },
}


def read_rows(name):
    path = ROOT / 'scripts/data' / name
    return [(i, line.split('|')) for i, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1)
            if line.strip() and not line.startswith('#')]


def locate_rows():
    locations = {}
    main_name = 'kanzen-grammar-main-units.tsv'
    example_name = 'kanzen-grammar-main-reviewed-examples.tsv'
    example_rows = {row[0]: (line, row) for line, row in read_rows(example_name)}
    for line, row in read_rows(main_name):
        key = f'kg-p1-l{int(row[0]):02}-g{int(row[1]):02}'
        example_line, example = example_rows[f'{int(row[0])}-{int(row[1])}']
        locations[key] = {
            'connection': (main_name, line, 5, row[5]),
            'grammarMeaning': (main_name, line, 6, row[6]),
            'translation': (example_name, example_line, 2, example[2]),
        }
    for filename, prefix in [
        ('kanzen-grammar-organized-reviewed.tsv', 'kg-p1-'),
        ('kanzen-grammar-composition-reviewed.tsv', 'kg-'),
    ]:
        for line, row in read_rows(filename):
            locations[prefix + row[0].lower()] = {
                'connection': (filename, line, 4, row[4]),
                'grammarMeaning': (filename, line, 5, row[5]),
                'translation': (filename, line, 7, row[7]),
            }
    return locations


raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == BASE_SHA, 'Shared book changed: rebase this proposal first'
book = json.loads(raw)
proposal = copy.deepcopy(book)
locations = locate_rows()
changes = []
for entry in proposal['entries']:
    edit = PROPOSALS.get(entry['id'])
    if not edit:
        continue
    title, connection, meaning = entry['usage'].split('\n')
    for field, value in edit.items():
        if field == 'reason':
            continue
        filename, line, column, before = locations[entry['id']][field]
        assert value != before
        if field == 'connection':
            assert connection == '接续：' + before
            connection = '接续：' + value
        elif field == 'grammarMeaning':
            assert meaning == '用法：' + before
            meaning = '用法：' + value
            entry['senses'][0]['meaning'] = value
        elif field == 'translation':
            assert entry['meaning'] == before
            entry['meaning'] = value
            entry['example']['meaning'] = value
            for example in entry['examples']:
                example['meaning'] = value
        changes.append({'id': entry['id'], 'field': field, 'before': before, 'after': value,
                        'sourceTsv': 'scripts/data/' + filename, 'line': line,
                        'columnIndex': column, 'sourcePdfPage': entry['source']['page'],
                        'reason': edit['reason']})
    entry['usage'] = '\n'.join([title, connection, meaning])

assert len(proposal['entries']) == 211
assert len({e['id'] for e in proposal['entries']}) == 211
for before, after in zip(book['entries'], proposal['entries']):
    assert before['id'] == after['id'] and before['source'] == after['source']
    assert before['text'] == after['text'] and before['reading'] == after['reading']
    assert re.fullmatch('[ぁ-ゖー、。「」！？!?・…]+', after['reading'])
    assert after['example'] == after['examples'][0]
    assert after['meaning'] == after['example']['meaning']
    assert after['usage'].split('\n')[2] == '用法：' + after['senses'][0]['meaning']

OUT.mkdir(parents=True, exist_ok=True)
candidate = OUT / 'round2-proposed-book.json'
candidate.write_text(json.dumps(proposal, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
report = {
    'status': 'isolated-editorial-proposal; peer-review-required; not-applied',
    'baseFile': str(SOURCE), 'baseSha256': BASE_SHA,
    'candidateFile': str(candidate),
    'candidateSha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
    'entries': 211, 'changedEntries': len(PROPOSALS), 'changedFields': len(changes),
    'reviewScope': [
        'Second language pass over all 211 example texts, kana readings and Chinese translations',
        'Second pass over all 211 connection/use notes; proposed clarifications listed individually',
        'Focused comparison with cached source OCR; visual checks of selected source sections only',
        'No fresh audio listening or complete page-by-page image verification in this pass',
    ],
    'unchanged': ['stable app JSON', 'shared TSV inputs', 'reading correction ledger',
                  'Japanese example texts', 'kana readings', 'IDs and source pages',
                  'runtime/UI/audio and deployment files'],
    'changes': changes,
    'mergeInstructions': [
        'Review each before/after correction; edit only the named TSV cell after checking its old value',
        'Run scripts/build-kanzen-grammar-review.py without --apply, then compare the preview to this candidate',
        'Apply only after peer review; keep grammar local until the human approves publication',
    ],
    'remaining': ['Peer calibration and final UI/playback verification', 'User review before public deployment'],
}
(OUT / 'round2-editorial-review.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
lines = ['新完全掌握 N3 语法：第二轮独立复核建议',
         f'211项中建议修订{len(PROPOSALS)}项、{len(changes)}个字段。未修改共享主文件。',
         '重点：第11课「つもりだ」是“自认”，须与“打算”的接续区别。',
         '例句日文、假名读音、ID、来源页码保持不变；本轮不是听音验收。', '']
for c in changes:
    lines.extend([f"{c['id']} / {c['field']} / PDF {c['sourcePdfPage']}",
                  '原：' + c['before'], '建议：' + c['after'], '原因：' + c['reason'], ''])
(OUT / 'round2-editorial-review.txt').write_text('\n'.join(lines), encoding='utf-8')
assert SOURCE.read_bytes() == raw
print(json.dumps({k: report[k] for k in ['status', 'entries', 'changedEntries', 'changedFields', 'candidateSha256']}, ensure_ascii=False))
