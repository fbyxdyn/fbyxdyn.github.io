"""Isolate standard-row examples for a second local Japanese/Chinese OCR pass."""
import json
from pathlib import Path
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
TMP=ROOT/'tmp/pdfs'
out=TMP/'kanzen-example-crops'
out.mkdir(exist_ok=True)
jobs={'ja':[],'zh-Hans-CN-v2':[]}
layout={}
for f in sorted((TMP/'recognized-cells-v4').glob('b0-*.json')):
    cells=[c for c in json.loads(f.read_text(encoding='utf-8'))
           if c['bottom']-c['top']>=310 and c['wordBox'][0]<350]
    if not cells:continue
    page=cells[0]['page'];name=f'b0-p{page:03}'
    meta=json.loads((TMP/'ja'/f'{name}-1.json').read_text(encoding='utf-8'))
    im=Image.new('RGB',(meta['width'],meta['fullHeight']),'white')
    im.paste(Image.open(TMP/'tiles'/f'{name}-0.png'),(0,0))
    im.paste(Image.open(TMP/'tiles'/f'{name}-1.png'),(0,meta['offsetY']))
    for c in cells:
        left=690;top=int(c['top']-10);bottom=int(c['top']+285)
        rgb=np.array(im.crop((left,top,1755,bottom)))
        crop=np.array(Image.fromarray(rgb).convert('L'))
        crop=Image.fromarray(np.where(crop<180,crop,255).astype('uint8'))
        crop=crop.resize((crop.width*2,crop.height*2))
        path=out/f"n{c['number']:04}.png"
        if not path.exists():crop.save(path)
        # Chinese translations use pale blue ink. A black-ink threshold erases
        # them; isolate the blue channel difference and increase its contrast.
        blue=rgb[:,:,2].astype(int)-rgb[:,:,0].astype(int)>10
        cn_gray=np.where(blue,np.clip((rgb[:,:,0].astype(float)-100)*1.7,0,255),255).astype('uint8')
        cn_crop=Image.fromarray(cn_gray).resize((rgb.shape[1]*2,rgb.shape[0]*2))
        cn_path=out/f"cn-n{c['number']:04}.png"
        if not cn_path.exists():cn_crop.save(cn_path)
        layout[str(c['number'])]={'left':left,'top':top,'scale':2}
        for lang in jobs:
            folder=out/lang;folder.mkdir(exist_ok=True)
            jobs[lang].append({'book':0,'page':page,'image':str(path if lang=='ja' else cn_path),'output':str(folder/f"n{c['number']:04}.json"),
                               'offsetY':0,'fullHeight':crop.height})
for lang,items in jobs.items():
    (out/f'jobs-{lang}.json').write_text(json.dumps(items,ensure_ascii=False),encoding='utf-8')
(out/'layout.json').write_text(json.dumps(layout),encoding='utf-8')
print(len(layout),'standard-row crops')
