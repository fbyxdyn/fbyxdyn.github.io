"""Read the example / reference column of the provided core vocabulary scans locally."""
import json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];TMP=ROOT/'tmp/pdfs'
sys.path.insert(0,str(ROOT/'.cache/ocr-tools'))
import numpy as np
import cv2
from PIL import Image
from rapidocr import RapidOCR,OCRVersion,ModelType
from rapidocr.ch_ppocr_rec.typings import TextRecInput
engines={}
for language in ['japan','ch']:
 e=RapidOCR(params={'Global.use_det':False,'Global.use_cls':False,'Global.model_root_dir':str(ROOT/'.cache/ocr-models'),'Rec.lang_type':language,'Rec.ocr_version':OCRVersion.PPOCRV4,'Rec.model_type':ModelType.MOBILE,'Rec.rec_img_shape':[3,48,320],'Rec.rec_batch_num':32,'EngineConfig.onnxruntime.intra_op_num_threads':6,'EngineConfig.onnxruntime.inter_op_num_threads':1})
 engines[language]=e._load_rec_model()
out=TMP/'n3-core-details-lines-v2';out.mkdir(exist_ok=True)
for page in range(18,306):
 destination=out/f'p{page:03}.json'
 if destination.exists():continue
 name=f'b1-p{page:03}';meta=json.loads((TMP/'ja'/f'{name}-1.json').read_text(encoding='utf-8'))
 image=Image.new('RGB',(meta['width'],meta['fullHeight']),'white');image.paste(Image.open(TMP/'tiles'/f'{name}-0.png'),(0,0));image.paste(Image.open(TMP/'tiles'/f'{name}-1.png'),(0,meta['offsetY']))
 rows=[]
 for lang in ['ja','zh-Hans-CN']:
  for tile in [0,1]:
   data=json.loads((TMP/lang/f'{name}-{tile}.json').read_text(encoding='utf-8'))
   for line in data['lines']:
    words=[w for w in line['words'] if w['x']>=680 and w['height']>=27]
    if len(words)<2:continue
    top=min(w['y'] for w in words)+data['offsetY'];bottom=max(w['y']+w['height'] for w in words)+data['offsetY']
    if top<280 or bottom>meta['fullHeight']-60 or bottom-top>65:continue
    right=max(w['x']+w['width'] for w in words)+35
    old=next((r for r in rows if abs(r['top']-top)<13 or abs(r['bottom']-bottom)<12),None)
    if old:
     old['top']=max(old['top'],top) if abs(old['bottom']-bottom)<12 else min(old['top'],top)
     old['bottom']=max(old['bottom'],bottom);old['right']=max(old['right'],right)
    else:rows.append({'top':top,'bottom':bottom,'right':right})
 rows.sort(key=lambda r:r['top'])
 crops=[]
 for r in rows:
  top=int(r['top'])-3;bottom=int(r['bottom'])+3
  right=min(1740,int(r['right']))
  crop=np.array(image.crop((700,top,right,bottom)))
  gray=cv2.cvtColor(crop,cv2.COLOR_RGB2GRAY)
  # Faint print from the reverse page otherwise becomes invented trailing glyphs.
  gray=np.where(gray<180,gray,255).astype('uint8')
  crops.append(cv2.cvtColor(gray,cv2.COLOR_GRAY2RGB))
  r['box']=[700,top,right,bottom]
 if crops:
  for lang,engine in engines.items():
   result=engine(TextRecInput(img=crops))
   for row,text,score in zip(rows,result.txts,result.scores):row[lang]={'text':re.sub(r'\s+','',text),'score':round(float(score),5)}
 destination.write_text(json.dumps({'page':page,'rows':rows},ensure_ascii=False,indent=2),encoding='utf-8')
 if (page-17)%20==0:print(f'Core vocabulary detail OCR {page-17}/288 pages',flush=True)
print('Core vocabulary detail OCR complete.',flush=True)
