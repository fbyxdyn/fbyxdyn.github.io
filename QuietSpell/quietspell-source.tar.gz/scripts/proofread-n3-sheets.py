import argparse,json
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1];TMP=ROOT/'tmp/pdfs'
p=argparse.ArgumentParser();p.add_argument('--group',default='spelling');a=p.parse_args()
queue=json.loads((ROOT/'output/n3-books/proofreading-queue.json').read_text(encoding='utf-8'))
if a.group=='spelling':selected=[q for q in queue if q['rawWord'] and any(r in q['reasons'] for r in ['missing','unknown-spelling','bad-reading'])]
elif a.group=='changed':selected=[q for q in queue if 'changed-head' in q['reasons'] and not q['rawWord'].endswith('する')]
elif a.group=='suspect':
 corrections=json.loads((ROOT/'scripts/n3-proofreading-corrections.json').read_text(encoding='utf-8'))
 selected=[]
 for q in queue:
  if str(q['number']) in corrections['books'][str(q['book'])]:continue
  raw=q['rawWord'];chosen=(q.get('chosen') or {}).get('text','')
  if 'changed-head' not in q['reasons']:continue
  if raw.startswith(chosen) and raw[len(chosen):].strip('する（）()。、：:「」!！0１12-_=（')=='':continue
  if '/' in raw or '、' in raw or '・' in raw or ('(' in raw and not raw.startswith('(')):continue
  selected.append(q)
elif a.group=='diagnostic':
 numbers=json.loads((ROOT/'scripts/n3-proofreading-diagnostics.json').read_text(encoding='utf-8'))
 selected=[]
 books={bid:{e['source']['number']:e for e in json.loads((ROOT/f'app/core/japanese/books/n3-pdf-{bid}.json').read_text(encoding='utf-8'))['entries']} for bid in [0,1]}
 for f in (TMP/'recognized-cells-v4').glob('*.json'):
  for c in json.loads(f.read_text(encoding='utf-8')):
   if c['number'] in numbers[str(c['book'])]:selected.append({'book':c['book'],'number':c['number'],'page':c['page'],'chosen':books[c['book']].get(c['number']),'cell':c})
else:selected=[q for q in queue if a.group in q['reasons']]
selected.sort(key=lambda c:(c['book'],c['number']))
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',17)
for batch in range(0,len(selected),24):
 canvas=Image.new('RGB',(2000,6*250),'#ddd');draw=ImageDraw.Draw(canvas)
 for i,q in enumerate(selected[batch:batch+24]):
  c=q['cell'];name=f"b{c['book']}-p{c['page']:03}"
  meta=json.loads((TMP/'ja'/f'{name}-1.json').read_text(encoding='utf-8'))
  im=Image.new('RGB',(meta['width'],meta['fullHeight']),'white');im.paste(Image.open(TMP/'tiles'/f'{name}-0.png'),(0,0));im.paste(Image.open(TMP/'tiles'/f'{name}-1.png'),(0,meta['offsetY']))
  b=c['wordBox'];top=c['readingBox'][1]-8;bottom=c['bottom'] if c['book']==0 else c['posY']+156
  crop=im.crop((b[0]-10,top,b[2],max(top+240,min(bottom,top+460))));crop.thumbnail((485,210))
  x=(i%4)*500;y=(i//4)*250
  chosen=(q.get('chosen') or {}).get('text','MISSING')
  draw.text((x+5,y+3),f"{c['book']}:{c['number']} p{c['page']} -> {chosen}",fill='black',font=font)
  canvas.paste(crop,(x+5,y+30))
 canvas.save(TMP/f'proof-{a.group}-{batch//24}.png')
print(len(selected),'cells', (len(selected)+23)//24,'sheets')
