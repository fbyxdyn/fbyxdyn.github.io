$ErrorActionPreference = 'Stop'
$taskWorkspace = Split-Path -Parent $PSScriptRoot
$taskSource = Join-Path $taskWorkspace 'services\quietspell-unicloud'
$taskOutput = Join-Path $taskWorkspace 'output\unicloud-sync'
$taskManifest = @()
foreach ($taskFunction in @('health', 'sync')) {
    $taskName = 'quietspell-' + $taskFunction
    $taskDestination = Join-Path $taskOutput $taskName
    New-Item -ItemType Directory -Path $taskDestination -Force | Out-Null
    foreach ($taskFile in @('index.js', 'package.json')) {
        Copy-Item -LiteralPath (Join-Path $taskSource "$taskFunction\$taskFile") -Destination (Join-Path $taskDestination $taskFile) -Force
    }
    $taskFiles = @((Join-Path $taskDestination 'index.js'), (Join-Path $taskDestination 'package.json'))
    if ($taskFunction -eq 'sync') {
        $taskWorker = Join-Path $taskDestination 'worker.mjs'
        Copy-Item -LiteralPath (Join-Path $taskWorkspace 'services\quietspell-sync\worker\index.mjs') -Destination $taskWorker -Force
        $taskFiles += $taskWorker
        $taskQuota = Join-Path $taskDestination 'quota.js'
        Copy-Item -LiteralPath (Join-Path $taskSource 'quota\index.js') -Destination $taskQuota -Force
        $taskFiles += $taskQuota
    }
    $taskZip = Join-Path $taskOutput ($taskName + '-alipay.zip')
    Compress-Archive -LiteralPath $taskFiles -DestinationPath $taskZip -Force
    $taskManifest += [ordered]@{ function = $taskName; archive = $taskZip; sha256 = (Get-FileHash -LiteralPath $taskZip -Algorithm SHA256).Hash.ToLowerInvariant(); bytes = (Get-Item -LiteralPath $taskZip).Length; deployed = $false }
}
[ordered]@{ provider = 'unicloud-alipay'; runtime = 'Nodejs18'; packages = $taskManifest; includesCredentials = $false } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskOutput 'release.json') -Encoding UTF8
Write-Host 'Prepared local Alipay health and sync function packages. No deployment performed.'
