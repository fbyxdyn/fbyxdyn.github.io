# Interactive local setup only. Never prints the token or contacts a server.
# Windows DPAPI encrypts the token for the current Windows account.
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$taskRoot = Split-Path -Parent $PSScriptRoot
$taskSecretDirectory = Join-Path $taskRoot '.cache\quietspell-sync-setup'
$taskSecretPath = Join-Path $taskSecretDirectory 'github-token.dpapi'
$taskSecret = $null

try {
    Write-Host 'QuietSpell private learning-data sync setup'
    Write-Host 'Repository: fbyxdyn/QuietSpell-user-data (Private)'
    Write-Host 'Use a fine-grained GitHub token for ONLY this repository, Contents: Read and write.'
    Write-Host 'The token will be encrypted locally for this Windows account.'
    Write-Host 'Codex will configure it as the GITHUB_TOKEN secret of the QuietSpell sync service.'
    Write-Host 'Do not paste the token into chat, a source file, or a command argument.'
    $taskSecret = Read-Host 'Paste the repository token here (input hidden)' -AsSecureString
    if ($taskSecret.Length -eq 0) { throw 'No token entered; nothing was saved.' }
    $taskEncrypted = ConvertFrom-SecureString -SecureString $taskSecret
    New-Item -ItemType Directory -Path $taskSecretDirectory -Force | Out-Null
    [System.IO.File]::WriteAllText($taskSecretPath, $taskEncrypted, [System.Text.UTF8Encoding]::new($false))
    Write-Host 'Encrypted setup saved. Return to Codex and confirm that setup is complete.'
    Write-Host 'The encrypted setup file will be removed after successful server-secret configuration.'
} finally {
    if ($null -ne $taskSecret) { $taskSecret.Dispose() }
    Remove-Variable taskEncrypted -ErrorAction SilentlyContinue
}
