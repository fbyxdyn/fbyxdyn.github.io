import { createHash } from 'node:crypto'
import { mkdir, writeFile } from 'node:fs/promises'
import { JAPANESE_LESSONS } from '../app/core/japanese/content.ts'

const output = new URL('../public/audio/japanese/', import.meta.url)
await mkdir(output, { recursive: true })
const recordings = new Map()
for (const lesson of JAPANESE_LESSONS) {
  for (const entry of lesson.entries) {
    for (const text of [entry.text, entry.example?.text].filter(Boolean)) {
      // One pronunciation for each distinct text, shared by all lessons.
      recordings.set(text, { text, file: `${createHash('sha256').update(text).digest('hex').slice(0, 20)}.mp3` })
    }
  }
}
await writeFile(new URL('recordings.json', output), JSON.stringify([...recordings.values()], null, 2) + '\n')
await writeFile(
  new URL('../app/core/japanese/audio-manifest.json', import.meta.url),
  JSON.stringify(Object.fromEntries([...recordings.values()].map(item => [item.text, item.file])), null, 2) + '\n'
)
console.log(`Prepared ${recordings.size} Japanese recordings.`)
