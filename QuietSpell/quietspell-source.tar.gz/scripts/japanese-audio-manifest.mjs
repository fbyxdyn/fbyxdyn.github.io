import { createHash } from 'node:crypto'
import { mkdir, readFile, writeFile, stat } from 'node:fs/promises'
import { JAPANESE_LESSONS } from '../app/core/japanese/content.ts'
import { createJapaneseDetailsIndex, enrichJapaneseEntry, getJapaneseExamples } from '../app/core/japanese/details.ts'

const root = new URL('../', import.meta.url)
const readJson = async name => JSON.parse(await readFile(new URL(name, root), 'utf8'))
const legacy = await readJson('public/audio/japanese/recordings.json')
const legacyByText = new Map(legacy.filter(item => !item.key || !item.key.includes('\0')).map(item => [item.text, item]))
const legacyPairs = new Set()
for (const lesson of JAPANESE_LESSONS) for (const entry of lesson.entries) {
  legacyPairs.add(`${entry.text}\0${entry.reading}`)
  if (entry.example) legacyPairs.add(`${entry.example.text}\0${entry.example.reading}`)
}
const coreIndex = createJapaneseDetailsIndex(await readJson('app/core/japanese/books/n3-enrichment.json'))
const kanzenIndex = createJapaneseDetailsIndex(await readJson('app/core/japanese/books/n3-kanzen-enrichment.json'))
const lessons = [...JAPANESE_LESSONS]
for (let book = 0; book < 4; book++) {
  const lesson = await readJson(`app/core/japanese/books/n3-pdf-${book}.json`)
  lessons.push({ ...lesson, entries: lesson.entries.map(entry => enrichJapaneseEntry(entry, book === 0 ? kanzenIndex : coreIndex)) })
}
const recordings = new Map(legacy.map(item => [item.file, { ...item, speechText: item.speechText || item.text }]))
const manifest = Object.fromEntries(legacy.filter(item => !item.key || !item.key.includes('\0')).map(item => [item.text, item.file]))
let utterances = 0
function add(text, reading = '') {
  text = text?.normalize('NFC').trim()
  reading = reading?.normalize('NFC').trim() || ''
  if (!text) return
  const key = reading ? `${text}\0${reading}` : text
  const previous = legacyByText.get(text)
  const reuse = previous && (!reading || legacyPairs.has(key))
  const speechText = (reading || text).replace(/[～〜~]/g, '')
  if (!speechText.trim()) return
  const file = reuse ? previous.file : `n3/${createHash('sha256').update(key).digest('hex').slice(0, 20)}.mp3`
  manifest[key] = file
  if (!manifest[text]) manifest[text] = file
  if (!recordings.has(file)) recordings.set(file, { key, text, reading, speechText, file })
  utterances++
}
for (const lesson of lessons) for (const entry of lesson.entries) {
  add(entry.text, entry.reading)
  for (const example of getJapaneseExamples(entry)) add(example.text, example.reading)
  for (const group of [entry.phrases, entry.synonyms, entry.similarSounds]) for (const item of group ?? []) add(item.text, item.reading)
}
const output = new URL('output/audio/japanese/', root)
await mkdir(output, { recursive: true })
await writeFile(new URL('recordings.json', output), JSON.stringify([...recordings.values()], null, 2) + '\n')
await writeFile(new URL('manifest.json', output), JSON.stringify(manifest, null, 2) + '\n')
let existing = 0
for (const item of recordings.values()) {
  try { if ((await stat(new URL(`public/audio/japanese/${item.file}`, root))).size > 1000) existing++ } catch {}
}
const report = { lessons: lessons.length, utterances, uniqueFiles: recordings.size, existingFiles: existing, pendingFiles: recordings.size - existing, manifestKeys: Object.keys(manifest).length }
await writeFile(new URL('coverage-report.json', output), JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report))
console.log('Prepared a staging plan; the active manifest is replaced only after every MP3 is verified.')
