"""Extract source-backed standard-row examples from the local Kanzen N3 OCR.

No invented examples or cross-book inference. Grid/illustration rows without a
reliable sentence and Chinese translation remain in the review report.
"""
import argparse
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import unicodedata

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('n3_source', ROOT / 'scripts/build-n3-wordbooks.py')
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
from sudachipy import dictionary, tokenizer

morph = dictionary.Dictionary().create()
parser = argparse.ArgumentParser()
parser.add_argument('--debug', type=int)
args = parser.parse_args()
book_path = ROOT / 'app/core/japanese/books/n3-pdf-0.json'
book = json.loads(book_path.read_text(encoding='utf-8'))
ja = source.read_ocr(0, 'ja')
zh = source.read_ocr(0, 'zh-Hans-CN')
cells = {}
for path in (ROOT / 'tmp/pdfs/recognized-cells-v4').glob('b0-*.json'):
    for cell in json.loads(path.read_text(encoding='utf-8')):
        cells[cell['number']] = cell
crop_dir = ROOT / 'tmp/pdfs/kanzen-example-crops'
layout_path = crop_dir / 'layout.json'
crop_layout = json.loads(layout_path.read_text(encoding='utf-8')) if layout_path.exists() else {}


def cropped_rows(number, language):
    # The first black-ink crop deliberately suppresses the pale-blue translations.
    # Only use the Chinese pass made from the separate blue-ink contrast image.
    folder = 'zh-Hans-CN-v2' if language == 'zh-Hans-CN' else language
    path = crop_dir / folder / f'n{number:04}.json'
    bounds = crop_layout.get(str(number))
    if not bounds or not path.exists():
        return []
    rows = []
    for line in json.loads(path.read_text(encoding='utf-8'))['lines']:
        main = [w for w in line['words'] if w['height'] >= 58]
        if not main:
            continue
        top = min(w['y'] for w in main)
        # Include punctuation, small kana, 一 and ー on the main baseline,
        # excluding the small furigana above it.
        words = [w for w in line['words'] if w['height'] >= 50 or w['y'] >= top - 8]
        rows.append({'text': ''.join(w['text'] for w in words),
                     'x': bounds['left'] + min(w['x'] for w in words) / 2,
                     'y': bounds['top'] + min(w['y'] for w in words) / 2,
                     'h': max(w['height'] for w in words) / 2,
                     'bottom': bounds['top'] + max(w['y'] + w['height'] for w in words) / 2})
    return rows


def normalize(text):
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', text)).replace('テ二ス', 'テニス')


def contains_target(text, entry):
    if entry['text'] in text:
        return True
    # Inflected verbs/adjectives need lemma comparison, not arbitrary truncation.
    lemmas = {t.dictionary_form() for t in morph.tokenize(text, tokenizer.Tokenizer.SplitMode.C)}
    if entry['text'] in lemmas:
        return True
    tokens = morph.tokenize(entry['text'], tokenizer.Tokenizer.SplitMode.C)
    if len(tokens) == 1 and tokens[0].part_of_speech()[0] in ('動詞', '形容詞'):
        return tokens[0].dictionary_form() in lemmas
    return False


def reading(text, entry):
    return ''.join(entry['reading'] if t.surface() == entry['text'] else source.hiragana(t.reading_form())
                   for t in morph.tokenize(text, tokenizer.Tokenizer.SplitMode.C))


def sentence(text):
    text = normalize(text).strip('_`/／ ')
    # Remove OCR line-start bullets; keep actual dialogue punctuation.
    text = re.sub(r'^[◆◇●○◎・*★]+', '', text)
    if not 5 <= len(text) <= 170 or not re.search('[ぁ-ゖァ-ヺ]', text):
        return ''
    if re.search(r'[这们请从对为并个尓么]|[{}\[\]<>~]', text):
        return ''
    if not re.search('[。！？!?][」”"]?$', text):
        return ''
    if text.count('「') != text.count('」'):
        return ''
    return text


def joined_rows(rows):
    # read_ocr already reconciles overlapping image tiles. Join split baseline
    # fragments once in x order, preserving an isolated long-vowel mark.
    groups = []
    for row in sorted(rows, key=lambda l: (l['y'], l['x'])):
        found = next((g for g in groups if abs(g[0]['y'] - row['y']) < 19), None)
        if found is None:
            groups.append([row])
        else:
            found.append(row)
    return [''.join(r['text'] for r in sorted(group, key=lambda l: l['x'])) for group in groups]


results, issues = [], []
for entry in book['entries']:
    number = entry['source']['number']
    cell = cells.get(number)
    if not cell:
        issues.append({'id': entry['id'], 'reason': 'No standard-row source cell'})
        continue
    page, top = cell['page'], cell['top']
    # Standard book rows have examples right of the word column. Compact grids
    # can occupy that region too; target/terminator/translation checks reject them.
    jp_data = cropped_rows(number, 'ja') or ja[page]
    cn_data = cropped_rows(number, 'zh-Hans-CN') or zh[page]
    jp_candidates = [l for l in jp_data if 690 <= l['x'] < 1720 and top - 8 <= l['y'] < top + 145 and 32 <= l['h'] < 58 and re.search('[ぁ-ゖァ-ヺ]', l['text'])]
    jp_rows = []
    for line in sorted(jp_candidates, key=lambda l:(l['y'],l['x'])):
        jp_rows.append(line)
        if sentence(''.join(joined_rows(jp_rows))):
            break
    jp_end = max((l['y'] for l in jp_rows), default=top + 20)
    cn_rows = [l for l in cn_data if 690 <= l['x'] < 1720 and jp_end + 65 <= l['y'] < jp_end + 195 and 30 <= l['h'] < 53]
    jp = ''.join(joined_rows(jp_rows))
    cn = ''.join(joined_rows(cn_rows))
    text = sentence(jp)
    meaning = normalize(cn).strip('，,。')
    reasons = []
    if not text:
        reasons.append('No complete Japanese sentence')
    elif not contains_target(text, entry):
        reasons.append('Sentence does not contain the target word/lemma')
    if not source.HAN.search(meaning) or re.search('[ぁ-ゖァ-ヺ]', meaning) or not 3 <= len(meaning) <= 200:
        reasons.append('No reliable Chinese translation')
    if args.debug == number:
        print(json.dumps({'entry': entry, 'cell': cell, 'jpRows': jp_rows, 'cnRows': cn_rows,
                          'text': text, 'meaning': meaning, 'reasons': reasons}, ensure_ascii=False, indent=2))
    if reasons:
        issues.append({'id': entry['id'], 'number': number, 'text': entry['text'], 'page': page,
                       'reasons': reasons, 'japaneseCandidate': jp, 'chineseCandidate': cn})
        continue
    results.append({'id': entry['id'], 'text': entry['text'], 'reading': entry['reading'],
                    'examples': [{'text': text, 'reading': reading(text, entry), 'meaning': meaning}],
                    'detailsSource': f'新完全原书例句 OCR（PDF 第 {page} 页，待逐条精校）'})

folder = ROOT / 'output/n3-books/kanzen'
folder.mkdir(parents=True, exist_ok=True)
(folder / 'source-examples-ocr-draft.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(folder / 'source-example-review.json').write_text(json.dumps(issues, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
report = {'bookSha256': hashlib.sha256(book_path.read_bytes()).hexdigest(), 'entries': len(book['entries']),
          'sourceExamples': len(results), 'unaccepted': len(issues), 'reviewRequired': True,
          'issueCounts': dict(collections.Counter(reason for issue in issues for reason in issue.get('reasons', [issue.get('reason')]))) }
(folder / 'source-example-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
