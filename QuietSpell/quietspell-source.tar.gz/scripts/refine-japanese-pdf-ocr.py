"""Second-pass recognition of tightly cropped text lines, with confidence scores."""
import argparse
import json
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / '.cache/ocr-tools'))
import numpy as np
from PIL import Image
from rapidocr import RapidOCR, OCRVersion, ModelType
from rapidocr.ch_ppocr_rec.typings import TextRecInput

parser=argparse.ArgumentParser();parser.add_argument('--language',choices=['ja','ch'],default='ja');args=parser.parse_args()
language=args.language
source_language='ja' if language=='ja' else 'zh-Hans-CN'
output=root/f'tmp/pdfs/refined-{language}';output.mkdir(exist_ok=True)
engine=RapidOCR(params={'Global.use_det':False,'Global.use_cls':False,'Global.model_root_dir':str(root/'.cache/ocr-models'), 'Rec.lang_type':'japan' if language=='ja' else 'ch', 'Rec.ocr_version':OCRVersion.PPOCRV4,'Rec.model_type':ModelType.MOBILE,'Rec.rec_batch_num':32,'Rec.rec_img_shape':[3,48,160],'EngineConfig.onnxruntime.intra_op_num_threads':6,'EngineConfig.onnxruntime.inter_op_num_threads':1})
recognizer=engine._load_rec_model()
files=sorted((root/f'tmp/pdfs/{source_language}').glob('*.json'))
for counter,file in enumerate(files):
    destination=output/file.name
    if destination.exists(): continue
    data=json.loads(file.read_text(encoding='utf-8'))
    if (data['book']==0 and not 9<=data['page']<=244) or (data['book']==1 and not 18<=data['page']<=305):
        destination.write_text('{}',encoding='utf-8');continue
    image=Image.open(root/'tmp/pdfs/tiles'/file.with_suffix('.png').name).convert('RGB')
    crops=[];indices=[]
    for index,line in enumerate(data['lines']):
        words=line['words']
        left=min(word['x'] for word in words);top=min(word['y'] for word in words)
        right=max(word['x']+word['width'] for word in words);bottom=max(word['y']+word['height'] for word in words)
        height=max(word['height'] for word in words)
        kana=bool(re.search('[ぁ-ヿ]',line['text']))
        cjk=bool(re.search('[一-鿿ぁ-ヿ]',line['text']))
        if not cjk or height<24 or left>image.width*.38: continue
        if language=='ja' and data['book']==0 and height<48: continue
        if language=='ja' and data['book']==1 and 35<=height<46: continue
        if language=='ch' and not 27<=height<49: continue
        crop=image.crop((max(0,int(left)-3),max(0,int(top)-3),min(image.width,int(right)+4),min(image.height,int(bottom)+4)))
        if not crop.width or not crop.height: continue
        crops.append(np.array(crop));indices.append(index)
    refined={}
    if crops:
        result=recognizer(TextRecInput(img=crops))
        refined={str(index):{'text':text,'score':round(float(score),5)} for index,text,score in zip(indices,result.txts,result.scores)}
    destination.write_text(json.dumps(refined,ensure_ascii=False),encoding='utf-8')
    if (counter+1)%50==0: print(f'Second-pass {language}: {counter+1}/{len(files)} tiles',flush=True)
print(f'Second-pass {language} complete.',flush=True)
