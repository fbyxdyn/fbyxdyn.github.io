"""Apply peer-reviewed grammar notes to exact TSV cells, then rebuild a local-only review edition."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/n3-books/kanzen-grammar'
BOOK = ROOT / 'app/core/japanese/books/n3-kanzen-grammar.json'
REVIEW = OUT / 'round2-editorial-review.json'
BASE_SHA = 'b3d0cdeb66faa78705f7850e550268e12b8a0329184fe39cd92a9487a1bca93c'
FILES = {'kanzen-grammar-main-units.tsv', 'kanzen-grammar-main-reviewed-examples.tsv',
         'kanzen-grammar-organized-reviewed.tsv', 'kanzen-grammar-composition-reviewed.tsv'}
SELF_RECOGNITION = '自認の用法：普通形（な形容詞の現在肯定形はな／名詞の現在肯定形はの）＋つもりだ。動詞辞書形・ない形はこの用法では使わない（これらは別の「打算」の用法）。'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    original_book = BOOK.read_bytes()
    assert sha(original_book) == BASE_SHA, 'Shared grammar changed; review the new snapshot first.'
    review = json.loads(REVIEW.read_text(encoding='utf-8'))
    assert review['baseSha256'] == BASE_SHA
    candidate = Path(review['candidateFile']).read_bytes()
    assert sha(candidate) == review['candidateSha256']
    expected = json.loads(candidate)
    changes = copy.deepcopy(review['changes'])
    assert len(changes) == 30 and len({item['id'] for item in changes}) == 29
    originals, rows, accepted = {}, {}, []
    for change in changes:
        path = (ROOT / change['sourceTsv']).resolve()
        assert path.parent == (ROOT / 'scripts/data').resolve() and path.name in FILES
        if path not in originals:
            originals[path] = path.read_bytes()
            rows[path] = originals[path].decode('utf-8').splitlines()
        line, column = change['line'] - 1, change['columnIndex']
        cells = rows[path][line].split('|')
        assert cells[column] == change['before'], 'TSV value changed: ' + change['id']
        value = change['after']
        if change['id'] == 'kg-p1-l11-g04' and change['field'] == 'connection':
            # PDF58 states plain forms, with dictionary/ない excluded in this use.
            # Retain its broader tense/negative coverage instead of listing only two verb forms.
            value = SELF_RECOGNITION
            target = next(item for item in expected['entries'] if item['id'] == change['id'])
            target['usage'] = target['usage'].replace('接续：' + change['after'], '接续：' + value)
            change['peerRefinement'] = 'Visually checked PDF58; preserve the source plain-form rule and its explicit exclusions.'
        assert not any(separator in value for separator in ['|', '\r', '\n'])
        cells[column] = value
        rows[path][line] = '|'.join(cells)
        accepted.append({**change, 'acceptedAfter': value})
    backup = OUT / 'calibration/baseline-b3d0cdeb'
    backup.mkdir(parents=True, exist_ok=True)
    snapshots = {BOOK: original_book, **originals}
    for path, data in snapshots.items():
        destination = backup / path.name
        if destination.exists():
            assert destination.read_bytes() == data, 'Existing baseline backup differs.'
        else:
            destination.write_bytes(data)
    written = {path: ('\n'.join(lines) + '\n').encode('utf-8') for path, lines in rows.items()}
    try:
        for path, data in written.items():
            assert path.read_bytes() == originals[path], 'Concurrent source edit detected.'
            path.write_bytes(data)
        built = subprocess.run([sys.executable, '-X', 'utf8', str(ROOT / 'scripts/build-kanzen-grammar-review.py'), '--apply'],
                               cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        (OUT / 'calibration/rebuild.stdout.log').write_bytes(built.stdout)
        (OUT / 'calibration/rebuild.stderr.log').write_bytes(built.stderr)
        if built.returncode:
            raise RuntimeError('Grammar rebuild failed; inspect the calibration logs.')
        actual = json.loads(BOOK.read_text(encoding='utf-8'))
        assert actual == expected, 'Rebuild contains changes outside the reviewed proposal.'
        before = json.loads(original_book)
        assert len(actual['entries']) == 211
        for old, new in zip(before['entries'], actual['entries']):
            for field in ['id', 'text', 'reading', 'label', 'source']:
                assert old[field] == new[field], 'Source identity or pronunciation changed.'
        result = {'status': 'local-review-ready; publication-not-authorized', 'entries': 211,
                  'changedEntries': 29, 'changedFields': 30, 'peerRefinements': 1,
                  'baseSha256': BASE_SHA, 'resultSha256': sha(BOOK.read_bytes()),
                  'sourceExamples': 196, 'authoredExamples': 15, 'teachingUnits': 36,
                  'visualSpotChecksPdfPages': [46, 58, 77, 78, 87],
                  'unchanged': ['Japanese example texts', 'kana readings', 'entry IDs', 'source pages'],
                  'limitations': ['Selected teaching content, not a complete transcription.',
                                  'Not all pages visually rechecked or all recordings listened to.',
                                  'User review is still required before publication.'],
                  'sourceFiles': {str(path.relative_to(ROOT)): {'before': sha(originals[path]), 'after': sha(data)} for path, data in written.items()},
                  'changes': accepted}
        (OUT / 'calibration/accepted-review.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({key: value for key, value in result.items() if key not in ['sourceFiles', 'changes']}, ensure_ascii=False))
    except Exception:
        for path, data in originals.items():
            if path.read_bytes() == written[path]:
                path.write_bytes(data)
        BOOK.write_bytes(original_book)
        raise


if __name__ == '__main__':
    main()
