"""Create compact, font-embedded Japanese study PDFs from reviewed local data."""
from collections import OrderedDict
from pathlib import Path
import hashlib
import html
import json
import re

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import BaseDocTemplate, SimpleDocTemplate, PageTemplate, Frame, Paragraph, Spacer, KeepTogether, Table, TableStyle, PageBreak
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/pdf'
OUT.mkdir(parents=True, exist_ok=True)
TEMP = ROOT / 'tmp/pdfs'
TEMP.mkdir(parents=True, exist_ok=True)
for name, file in [('ZH', 'msyh.ttc'), ('ZHB', 'msyhbd.ttc'), ('JP', 'YuGothR.ttc'), ('JPB', 'YuGothB.ttc')]:
    pdfmetrics.registerFont(TTFont(name, 'C:/Windows/Fonts/' + file, subfontIndex=0))

INK = colors.HexColor('#1F3048')
MUTED = colors.HexColor('#65758A')
BLUE = colors.HexColor('#2C5D91')
LINE = colors.HexColor('#C7D2DF')
PALE = colors.HexColor('#EDF3F9')
PINK = '#F9E5EA'
YELLOW = '#FFF3CC'
CYAN = '#E0F3F4'
ORANGE = '#FCE9DB'
GREEN = '#E9F3DE'
PURPLE = '#EDE7F7'

def style(name, size=9.4, leading=13, font='ZH', **kwargs):
    return ParagraphStyle(name, fontName=font, fontSize=size, leading=leading, textColor=INK,
                          wordWrap='CJK', spaceAfter=0, **kwargs)

BODY = style('body')
SMALL = style('small', 8.5, 11.8)
NOTE = style('note', 8.5, 12, textColor=MUTED) if False else style('note', 8.5, 12)
HEAD = style('heading', 17, 23, 'ZHB', spaceBefore=0)
SUB = style('subheading', 10.2, 15, 'ZHB')
CELL = style('cell', 9.2, 12.5)
CELLJP = style('cell-jp', 9.4, 13, 'JP')
CELLHEAD = style('cell-heading', 9.2, 12, 'ZHB', alignment=TA_CENTER)

def esc(value): return html.escape(str(value), quote=False).replace('\n', '<br/>')
def jp(value): return '<font name="JP">' + esc(value) + '</font>'
def p(value, kind=BODY, markup=False):
    text = value if markup else esc(value)
    if not markup and kind.fontName in ('JP', 'JPB'):
        glyphs = pdfmetrics.getFont(kind.fontName).face.charToGlyph
        fallback = 'ZHB' if kind.fontName == 'JPB' else 'ZH'
        text = ''.join(esc(char) if ord(char) in glyphs or char.isspace()
                       else '<font name="' + fallback + '">' + esc(char) + '</font>' for char in str(value))
    return Paragraph(text, kind)

def table(headers, rows, widths, jpcols=(), backgrounds=None, font_size=9.2, padding=5):
    cellstyle = style('table-body', font_size, font_size * 1.37)
    jstyle = style('table-jp', font_size, font_size * 1.37, 'JP')
    data = [[p(text, CELLHEAD) for text in headers]]
    for row in rows:
        data.append([p(text, jstyle if i in jpcols else cellstyle) for i, text in enumerate(row)])
    result = Table(data, colWidths=widths, repeatRows=1, hAlign='LEFT')
    commands = [('GRID', (0, 0), (-1, -1), .45, LINE), ('BACKGROUND', (0, 0), (-1, 0), PALE),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('LEFTPADDING', (0, 0), (-1, -1), padding),
                ('RIGHTPADDING', (0, 0), (-1, -1), padding), ('TOPPADDING', (0, 0), (-1, -1), padding),
                ('BOTTOMPADDING', (0, 0), (-1, -1), padding)]
    if backgrounds:
        commands.extend(('BACKGROUND', (0, row), (-1, row), colors.HexColor(color)) for row, color in enumerate(backgrounds, 1))
    result.setStyle(TableStyle(commands))
    return result

def footer(canvas, doc, label):
    canvas.saveState()
    w, h = doc.pagesize
    canvas.setStrokeColor(LINE)
    canvas.line(30, 27, w - 30, 27)
    canvas.setFont('ZH', 7.7)
    canvas.setFillColor(MUTED)
    canvas.drawString(30, 15, label)
    canvas.drawRightString(w - 30, 15, str(doc.page))
    canvas.restoreState()

UNIT_TOPICS = [
    '时间与动作阶段', '按照／差异／反复／顺便', '程度与最佳选择', '对比与两面性',
    '原因与理由', '假设与条件', '传闻与引用', '否定判断与保留', '愿望与许可',
    '命令、义务与建议', '决定、努力与自认', '敬语', '助词的强调与限定',
    '复合助词', 'こと与の的名词化', 'よう的用法', 'わけ的用法', 'ばかり的用法',
    'する与なる', '条件的特殊用法', '副词与句末呼应', '扩展词义的后缀',
    '引用内容与嵌入疑问', '名词修饰', 'という与といった', '固定搭配',
    '句首与句末的对应', '时制与ている', '自动词与他动词', 'てくる与ていく',
    '被动、使役与使役被动', '授受与叙述视点', 'こ・そ・あ的指代', 'は与が',
    '连接词', '书面语与文体统一',
]

REPLACEMENTS = [
    ('動詞使役形のて形', 'V使役て'), ('動詞ます形語幹', 'Vます干'), ('動詞辞書形', 'V辞书'),
    ('動詞ない形', 'Vない'), ('動詞て形', 'Vて'), ('動詞た形', 'Vた'), ('動詞意向形', 'V意向'),
    ('動詞可能形', 'V可能'), ('動詞命令形', 'V命令'), ('動詞ば形', 'Vば'),
    ('動詞', 'V'), ('い形容詞', 'Aい'), ('な形容詞', 'Aな'), ('名詞', 'N'),
    ('語幹', '词干'), ('連体形', '连体形'), ('現在肯定形', '现在肯定'), ('否定表現', '否定式'),
    ('条件形', '条件式'), ('普通形の', '普通形的'), ('修飾', '修饰'), ('＋', ' + '),
]

def compact_connection(text):
    for before, after in REPLACEMENTS: text = text.replace(before, after)
    return text

class GrammarDoc(BaseDocTemplate):
    def afterFlowable(self, flowable):
        if hasattr(flowable, 'bookmark'):
            key, title = flowable.bookmark
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(title, key, level=0, closed=False)

def grammar_pdf():
    raw = (ROOT / 'app/core/japanese/books/n3-kanzen-grammar.json').read_bytes()
    book = json.loads(raw)
    assert len(book['entries']) == 211
    groups = OrderedDict()
    for entry in book['entries']: groups.setdefault(entry['label'].split('｜')[0], []).append(entry)
    assert len(groups) == 36
    path = OUT / '新完全掌握N3语法_精炼速记.pdf'
    width, height = A4
    margin, gap = 34, 18
    col = (width - 2 * margin - gap) / 2
    def draw(canvas, doc):
        canvas.saveState()
        if doc.page == 1:
            canvas.setFillColor(BLUE); canvas.setFont('ZHB', 19)
            canvas.drawString(margin, height - 40, '新完全掌握 N3 语法精炼速记')
            canvas.setFillColor(MUTED); canvas.setFont('ZH', 9)
            canvas.drawString(margin, height - 59, '211 项语法与用法  /  36 个单元  /  接续 + 核心用法 + 短例句')
            legend = p('V＝动词；N＝名词；Aい＝い形容词；Aな＝な形容词；Vます干＝去掉ます。<br/>'
                       '普通形含肯定／否定、非过去／过去；名词、Aな接续时的だ／な／の须按各条处理。', SMALL, True)
            _, ph = legend.wrap(width - 2 * margin, 42)
            legend.drawOn(canvas, margin, height - 73 - ph)
        else:
            canvas.setFont('ZH', 8.5); canvas.setFillColor(MUTED)
            canvas.drawString(margin, height - 25, 'N3 语法速记  |  按书内教学顺序；同形不同义分别保留')
            canvas.setStrokeColor(LINE); canvas.line(margin, height - 33, width - margin, height - 33)
        canvas.restoreState()
        footer(canvas, doc, '学习整理版 · 接续先看形式，用法再看语境')
    def frames(top):
        return [Frame(x, 38, col, top - 38, leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
                for x in (margin, margin + col + gap)]
    doc = GrammarDoc(str(path), pagesize=A4, title='新完全掌握N3语法 - 精炼速记', author='QuietSpell 学习整理')
    doc.addPageTemplates([PageTemplate(id='first', frames=frames(height - 121), onPage=draw, autoNextPageTemplate='body'),
                          PageTemplate(id='body', frames=frames(height - 45), onPage=draw)])
    heading_style = style('grammar-heading', 9.7, 13.3, 'JPB')
    connection_style = style('grammar-connection', 8.45, 11.4)
    meaning_style = style('grammar-meaning', 8.9, 12)
    example_style = style('grammar-example', 8.8, 12, 'JP')
    story, number = [], 0
    for unit_index, (unit, entries) in enumerate(groups.items()):
        heading = p(f'{unit_index + 1:02d}  {UNIT_TOPICS[unit_index]}', SUB)
        heading.bookmark = ('unit-' + str(unit_index), f'{unit_index + 1:02d} {UNIT_TOPICS[unit_index]}')
        unit_line = Table([[heading]], colWidths=[col])
        unit_line.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), PALE), ('LEFTPADDING', (0, 0), (-1, -1), 5),
                                      ('TOPPADDING', (0, 0), (-1, -1), 4), ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]))
        # Use a standalone heading paragraph to provide PDF bookmarks.
        heading.spaceBefore, heading.spaceAfter = 7, 4
        story.append(heading)
        for entry in entries:
            number += 1
            name = entry['label'].split('｜', 1)[1]
            connection = entry['usage'].splitlines()[1].removeprefix('接续：')
            meaning = entry['usage'].splitlines()[2].removeprefix('用法：')
            block = [p(f'{number:03d}  {name}', heading_style),
                     p('<font color="#2C5D91">接续</font>  ' + esc(compact_connection(connection)), connection_style, True),
                     p('<font color="#2C5D91">要点</font>  ' + esc(meaning), meaning_style, True),
                     p('例  ' + entry['text'], example_style), Spacer(1, 6)]
            if len(story) and story[-1] is heading:
                story.pop(); story.append(KeepTogether([heading] + block))
            else: story.append(KeepTogether(block))
    story.extend([Spacer(1, 6), p('整理依据：本地已校订的《新完全掌握日语N3语法》学习词书。按教学顺序保留211项；练习题、模拟题未收入。中文说明为学习整理，少量例句为自编。', SMALL)])
    doc.build(story)
    return path, {'entries': number, 'units': len(groups), 'dataSha256': hashlib.sha256(raw).hexdigest()}

def verb_pdf():
    path = OUT / '日语动词变形_彩色对照全览.pdf'
    size = landscape(A4)
    width = size[0] - 60
    doc = SimpleDocTemplate(str(path), pagesize=size, leftMargin=30, rightMargin=30, topMargin=27,
                            bottomMargin=38, title='日语动词变形 - 彩色对照全览', author='QuietSpell 学习整理')
    story = []
    def title(text, sub):
        story.extend([p(text, HEAD), p(sub, SMALL), Spacer(1, 9)])
    def note(text): story.extend([Spacer(1, 6), p(text, SMALL)])
    def section(text): story.extend([Spacer(1, 8), p(text, SUB), Spacer(1, 5)])
    def newpage(): story.append(PageBreak())

    # 1: The user's reference matrix, recreated as a legible complete table.
    title('01  时态 × 肯否 × 简体／敬体', '参照所给彩色表格重排。非过去可表示现在、习惯或将来；敬体以标准「ます／ません」系列为主。')
    header = [
        ['类别／例词', '非过去（现在／将来）', '', '', '', '过去', '', '', ''],
        ['', '肯定', '', '否定', '', '肯定', '', '否定', ''],
        ['', '简体', '敬体', '简体', '敬体', '简体', '敬体', '简体', '敬体'],
    ]
    forms = [
        ['一类／五段\n書く', '書く', '書きます', '書かない', '書きません', '書いた', '書きました', '書かなかった', '書きませんでした'],
        ['二类／一段\n食べる', '食べる', '食べます', '食べない', '食べません', '食べた', '食べました', '食べなかった', '食べませんでした'],
        ['三类\nする', 'する', 'します', 'しない', 'しません', 'した', 'しました', 'しなかった', 'しませんでした'],
        ['三类\n来る', '来る（くる）', '来ます（きます）', '来ない（こない）', '来ません', '来た（きた）', '来ました', '来なかった', '来ませんでした'],
    ]
    data = [[p(x, CELLHEAD) for x in row] for row in header]
    data += [[p(x, CELL if col == 0 else CELLJP) for col, x in enumerate(row)] for row in forms]
    widths = [91] + [(width - 91) / 8] * 8
    matrix = Table(data, colWidths=widths, hAlign='LEFT')
    cmds = [('SPAN', (0, 0), (0, 2)), ('SPAN', (1, 0), (4, 0)), ('SPAN', (5, 0), (8, 0)),
            ('GRID', (0, 0), (-1, -1), .5, LINE), ('BACKGROUND', (0, 0), (-1, 2), PALE),
            ('BACKGROUND', (0, 3), (-1, -1), colors.HexColor(YELLOW)), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('LEFTPADDING', (0, 0), (-1, -1), 5), ('RIGHTPADDING', (0, 0), (-1, -1), 5),
            ('TOPPADDING', (0, 0), (-1, -1), 5), ('BOTTOMPADDING', (0, 0), (-1, -1), 5)]
    for a, b in [(1, 2), (3, 4), (5, 6), (7, 8)]: cmds.append(('SPAN', (a, 1), (b, 1)))
    matrix.setStyle(TableStyle(cmds)); story.append(matrix)
    section('补充：图片中的形容词／名词也一起对照')
    extra = [
        ['い形容词\n高い', '高い', '高いです', '高くない', '高くありません', '高かった', '高かったです', '高くなかった', '高くありませんでした'],
        ['な形容词\n静か', '静かだ', '静かです', '静かではない', '静かではありません', '静かだった', '静かでした', '静かではなかった', '静かではありませんでした'],
        ['名词\n学生', '学生だ', '学生です', '学生ではない', '学生ではありません', '学生だった', '学生でした', '学生ではなかった', '学生ではありませんでした'],
    ]
    story.append(table(['类别／例词', '非过去肯定\n简体', '非过去肯定\n敬体', '非过去否定\n简体', '非过去否定\n敬体', '过去肯定\n简体', '过去肯定\n敬体', '过去否定\n简体', '过去否定\n敬体'], extra, widths, jpcols=range(1, 9), backgrounds=[PINK] * 3, font_size=8.5, padding=4))
    note('口语常用：高くないです／高くなかったです；静かじゃないです／学生じゃなかったです。い形容词肯定式不加だ。いい的活用用よい词干：よくない、よかった。')

    # 2: Base transformations.
    newpage(); title('02  基础变形规则', '先判动词组，再套规则。「去る」只用于二类动词；「ます干」指去掉ます后剩下的部分。')
    rows = [
        ['ます干', 'う段 → い段\n書く → 書き', '去る\n食べる → 食べ', 'し', 'き', '接ます、たい、ながら、なさい等。'],
        ['ない形', 'う段 → あ段 + ない\n書かない；買う → 買わない', '去る + ない\n食べない', 'しない', 'こない', 'う结尾改わ；ある → ない。'],
        ['て形', 'く→いて；ぐ→いで；す→して\nう・つ・る→って\nぬ・ぶ・む→んで', '去る + て\n食べて', 'して', 'きて', '行く → 行って。用于连接、请求、复合表达。'],
        ['た形', 'て→た；で→だ\n書いた・泳いだ・読んだ', '去る + た\n食べた', 'した', 'きた', '与て形音便同组；行く → 行った。'],
        ['ば形', 'う段 → え段 + ば\n書けば', '去る + れば\n食べれば', 'すれば', 'くれば', '否定：ない→なければ。过去否定条件：なかったら。'],
        ['たら形', 'た形 + ら\n書いたら', '食べたら', 'したら', 'きたら', '过去形式可表示尚未发生的假设：着いたら電話して。'],
        ['たり形', 'た形 + り\n書いたり', '食べたり', 'したり', 'きたり', '列举代表动作：読んだり書いたりする。'],
    ]
    story.append(table(['变形', '一类／五段', '二类／一段', 'する', '来る（读音）', '关键点'], rows,
                       [60, 225, 115, 64, 86, width - 550], backgrounds=[YELLOW, CYAN, ORANGE, GREEN, '#E5EDF8', '#E5EDF8', GREEN], font_size=9.1, padding=6))
    note('判组：一类含所有不以る结尾的普通动词，以及帰る・入る・走る・切る・知る・要る等。二类多为「い／え段 + る」：見る、起きる、食べる、寝る；不能只看结尾猜组。する、来る为三类。')
    note('五段换段速记：う→わ／い／え／お；く→か／き／け／こ；ぐ→が／ぎ／げ／ご；す→さ／し／せ／そ；つ→た／ち／て／と；ぬ→な／に／ね／の；ぶ→ば／び／べ／ぼ；む→ま／み／め／も；る→ら／り／れ／ろ。')
    note('学校语法六活用以書く为例：未然「書か／書こ」、连用「書き／書い」、终止「書く」、连体「書く」、假定「書け」、命令「書け」。学习型名称「て形・た形」是教学上的组合形式。')

    # 3: Voice, mood, agency.
    newpage(); title('03  意向、命令、可能与声态', '可能、被动、使役、使役被动生成的新动词按二类再活用：書ける → 書けない／書けた／書けます。意向、命令、禁止不套此规则。')
    rows = [
        ['意向形', 'う段→お段 + う\n書こう', '去る + よう\n食べよう', 'しよう', 'こよう', '自己打算、提议；敬体统一用ます干 + ましょう。'],
        ['命令形', 'う段→え段\n書け', '去る + ろ／よ\n食べろ／食べよ', 'しろ／せよ', 'こい', '语气强；较缓和指示：ます干 + なさい。'],
        ['禁止形', '辞书形 + な\n書くな', '食べるな', 'するな', 'くるな', '「食べるな」禁止；「食べなさい」指示，不能混淆。'],
        ['可能形', 'う段→え段 + る\n書ける', '去る + られる\n食べられる', 'できる', 'こられる', '二类口语有ら抜き，但正式学习用られる。'],
        ['被动形', 'う段→あ段 + れる\n書かれる；買われる', '去る + られる\n食べられる', 'される', 'こられる', '受影响者为主语；与可能形同形时靠语境判断。'],
        ['使役形', 'う段→あ段 + せる\n書かせる；買わせる', '去る + させる\n食べさせる', 'させる', 'こさせる', '让、允许或要求别人做。'],
        ['使役被动', 'う段→あ段 + せられる\n書かせられる', '去る + させられる\n食べさせられる', 'させられる', 'こさせられる', '被迫／被要求做；也可表达受到影响后不由自主的感受。'],
    ]
    story.append(table(['变形', '一类／五段', '二类／一段', 'する', '来る（读音）', '关键点'], rows,
                       [65, 194, 130, 78, 85, width - 552], backgrounds=[PURPLE, PINK, PINK, '#E5EDF8', PURPLE, '#F5E8D9', '#F5E8D9'], font_size=9.1, padding=6))
    note('使役被动缩约：大多数五段「あ段 + せられる」可缩成「あ段 + される」：書かせられる → 書かされる，飲ませられる → 飲まされる。す结尾不用这条缩约：話させられる；二类也不套用。')
    note('视点对照：先生が私をほめた → 私は先生にほめられた。／先生が学生に本を読ませた → 学生は先生に本を読まされた。自发用法如「昔のことが思い出される」，并非每个动词都能自由套用。')

    # 4: Negation and common endings.
    newpage(); title('04  否定、希望、请求与义务', '把基本形接成常用表达；这一页以書く为主例。句末需礼貌时，使用对应的です／ます形式。')
    rows = [
        ['过去否定', 'ない → なかった', '書かなかった', 'ない按い形容词式变化。'],
        ['否定连接：不做而…', 'ない + で', '書かないで寝た', '没有做前项就做后项；也能接请求。'],
        ['否定原因／并列', 'ない → なくて', '書けなくて困った', '说明原因或并列状态；不能替代ないでください。'],
        ['否定条件／让步', 'ない → なければ／なくても', '書かなければ／書かなくても', '如果不写／即使不写。'],
        ['书面否定', 'ない去ない + ず（に）', '書かずに；する → せずに', '来る → 来ず（こず）；ず不是去掉ない后直接接で。'],
        ['其他否定', 'ない去ない + ぬ／ん', '知らぬ；わからん；せぬ', 'ぬ、ん多见书面或口语；来る → こぬ／こん。'],
        ['否定意志／推量', '辞书形 + まい', '書くまい；食べるまい；するまい', '书面：不打算做／大概不会。二类也见去る + まい；する也见すまい。'],
        ['想做', 'ます干 + たい', '書きたい／書きたくない／書きたかった', 'たい按い形容词变化；描述他人愿望常用たがる。'],
        ['肯定／否定请求', 'て + ください／ない + でください', '書いてください／書かないでください', '礼貌请求。禁止是辞书形 + な。'],
        ['许可／禁止', 'て + もいい／て + はいけない', '書いてもいい／書いてはいけない', 'で结尾的て形相应为でも／では。'],
        ['不必做', 'ない → なくてもいい', '書かなくてもいい', '无须写，不等于「不可以写」。'],
        ['必须做', 'ない → なければならない／なくてはいけない', '書かなければならない', '口语也用書かないといけない。'],
        ['较婉转的请求', 'て + もらえますか／いただけますか', '書いていただけますか', '请求对方为自己一方做。'],
        ['希望别人做', 'て + ほしい／ない + でほしい', '書いてほしい／書かないでほしい', '与「自分が書きたい」的主语视点不同。'],
        ['否定普通体接敬体', 'ないです／なかったです', '書かないです／書かなかったです', '口语常见；正式统一体可优先ません／ませんでした。'],
    ]
    story.append(table(['用途', '接法', '例', '辨析'], rows, [102, 224, 214, width - 540], jpcols=(2,), font_size=9, padding=4))
    note('否定变形也适用于可能、被动、使役等：書けない → 書けなかった；書かされない → 書かされなかった。礼貌否定：書けません／書かされませんでした。')

    # 5: Compound endings and spoken contractions.
    newpage(); title('05  复合变形与口语缩约', '变形次序看最后一个词：読んでいる按いる活用，読んでおく按おく活用，読みやすい按い形容词活用。')
    rows = [
        ['进行／习惯／结果状态', 'て + いる', '読んでいる → 読んでいた／読んでいない', '不是所有ている都表示正在做。'],
        ['人为留下的结果', 'て + ある', '書いてある → 書いてあった', '多接有意志的他动词。'],
        ['提前做／保持原状', 'て + おく', '書いておく → 書いておいた', '末尾おく是一类动词。'],
        ['完成／遗憾', 'て + しまう', '書いてしまう → 書いてしまった', '意义由语境判断。'],
        ['尝试', 'て + みる', '書いてみる → 書いてみた', '此处みる是二类。'],
        ['趋近／发展至今', 'て + くる', '寒くなってきた', 'くる：きます・こない・きた。'],
        ['远去／继续发展', 'て + いく', '増えていく → 増えていった', 'いく：いきます・いかない・いった。'],
        ['给予／接受帮助', 'て + あげる／くれる／もらう', '手伝ってあげた／くれた／もらった', '按最后的动词活用，并注意谁受益。'],
    ]
    story.append(table(['用途', '接法', '活用例', '关键点'], rows, [145, 193, 260, width - 598], jpcols=(2,), backgrounds=[ORANGE] * 8, font_size=9, padding=4))
    section('ます干后再接词：由最后的词决定活用')
    story.append(p('开始：読み始める／突然开始：降り出す／持续：読み続ける／结束：読み終わる／做完：読み切る／重做：書き直す／做到一半：読みかける。<br/>容易：読みやすい／困难：読みにくい・読みづらい／过度：読みすぎる／边…边…：読みながら／书面并行：読みつつ。', SMALL, True))
    section('常见缩约（非正式场合）')
    contractions = [
        ['ている → てる', '読んでいる → 読んでる', 'てしまう → ちゃう／でしまう → じゃう', '書いちゃう／読んじゃう'],
        ['ておく → とく／でおく → どく', '書いておく → 書いとく；読んどく', 'なければ → なきゃ／なくては → なくちゃ', '書かなきゃ／書かなくちゃ'],
        ['ては → ちゃ／では → じゃ', '書いちゃだめ／読んじゃだめ', 'ていない → てない', '読んでいない → 読んでない'],
    ]
    story.append(table(['原形 → 缩约', '例', '原形 → 缩约', '例'], contractions, [206, 190, 215, width - 611], jpcols=(1, 3), font_size=8.7, padding=4))

    # 6: Honorifics, exceptions and generative rules.
    newpage(); title('06  敬语、特殊变化与组合顺序', '敬体「です／ます」不等于尊敬语或谦让语。尊敬语抬高对方；谦让语／郑重语用于自己一方。')
    rows = [
        ['する', 'なさる', 'いたす', 'なさいます／いたします'],
        ['行く・来る・いる', 'いらっしゃる', '参る（行く・来る）／おる（いる）', 'いらっしゃいます／参ります／おります'],
        ['言う', 'おっしゃる', '申す／申し上げる', 'おっしゃいます／申します'],
        ['食べる・飲む', '召し上がる', 'いただく', '召し上がります／いただきます'],
        ['見る', 'ご覧になる', '拝見する', 'ご覧になります／拝見します'],
        ['くれる／もらう', 'くださる（くれる）', 'いただく（もらう）', 'くださいます／いただきます'],
        ['一般规则', 'お + ます干 + になる', 'お + ます干 + する／ご + 汉语词 + する', 'お読みになる／お読みする／ご案内する'],
    ]
    story.append(table(['普通表达', '尊敬表达', '自己一方的谦让／郑重表达', 'ます形示例'], rows, [128, 175, 248, width - 551], jpcols=(0, 1, 3), backgrounds=[PURPLE] * 7, font_size=9, padding=4))
    section('易错例外')
    exceptions = [
        ['行く', '行って／行った；行かない／行けば／行こう'],
        ['ある', '否定为ない；礼貌否定ありません；过去否定なかった／ありませんでした'],
        ['来る', 'くる／きます／こない／きて／きた／くれば／こよう／こい／こられる／こさせる'],
        ['五个ます形特殊词', 'なさる→なさいます；くださる→くださいます；いらっしゃる→いらっしゃいます；おっしゃる→おっしゃいます；ござる→ございます'],
    ]
    story.append(table(['项目', '记住这些形式'], exceptions, [128, width - 128], font_size=8.8, padding=4))
    section('用一条链生成更长形式')
    story.append(p('書く → 書かせる（让写）→ 書かせられる（被要求写）→ 書かせられない（否定）→ 書かせられなかった（过去）。<br/>敬体链：書かせられる → 書かせられます → 書かせられませんでした。缩约链：書かされる → 書かされませんでした。', SMALL, True))
    note('有专用敬语时优先使用专用表达；お／ご的一般规则不能无条件套用于所有动词。')
    note('四条件速辨：と偏自然结果／习惯；ば偏条件成立；たら适合先后与广泛假设；なら承接对方信息或提出话题。后项能否使用意志、请求须结合语境，不能机械互换。')
    note('范围：现代标准日语核心活用及常用复合、敬语、书面否定与口语缩约。复合形式可继续组合，以最后一个词的活用规则生成。整理参校：国際交流基金《いろどり》文法说明（自主编排、例句另作整理）。')
    links = '<link href="https://www.irodori.jpf.go.jp/assets/data/Grammar_all.pdf" color="#2C5D91">参考：いろどり文法说明</link>　' \
            '<link href="https://www.irodori.jpf.go.jp/assets/data/pre-intermediate/pdf/ZZ_L16.pdf" color="#2C5D91">使役被动说明：初中级第16课</link>'
    story.append(p(links, SMALL, True))
    doc.build(story, onFirstPage=lambda c, d: footer(c, d, '动词变形彩色对照  |  按形式查规则，按语境定意义'),
              onLaterPages=lambda c, d: footer(c, d, '动词变形彩色对照  |  按形式查规则，按语境定意义'))
    return path

if __name__ == '__main__':
    grammar, data = grammar_pdf()
    verbs = verb_pdf()
    report = {'grammar': {'path': str(grammar), 'pages': len(PdfReader(grammar).pages), **data},
              'verbs': {'path': str(verbs), 'pages': len(PdfReader(verbs).pages)}}
    for kind, info in report.items():
        reader = PdfReader(info['path'])
        info['bytes'] = Path(info['path']).stat().st_size
        info['sha256'] = hashlib.sha256(Path(info['path']).read_bytes()).hexdigest()
        text = '\n'.join(page.extract_text() or '' for page in reader.pages)
        (TEMP / (kind + '-text.txt')).write_text(text, encoding='utf-8')
        assert '\ufffd' not in text
    grammar_text = (TEMP / 'grammar-text.txt').read_text(encoding='utf-8')
    assert all(f'{number:03d}' in grammar_text for number in range(1, 212))
    assert all(text in (TEMP / 'verbs-text.txt').read_text(encoding='utf-8') for text in ['書かない', '食べられる', '書かされる', '書かせられませんでした', 'ございます'])
    (OUT / 'study-pdf-checks.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False))
