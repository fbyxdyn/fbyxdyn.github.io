"""Release-data checks for the reviewed, local-only grammar edition."""
import hashlib
import json
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/n3-books/kanzen-grammar'


class GrammarReviewTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (ROOT / 'app/core/japanese/books/n3-kanzen-grammar.json').read_bytes()
        cls.book = json.loads(cls.raw)
        cls.before = json.loads((OUT / 'calibration/baseline-b3d0cdeb/n3-kanzen-grammar.json').read_text(encoding='utf-8'))
        cls.review = json.loads((OUT / 'calibration/accepted-review.json').read_text(encoding='utf-8'))
        cls.entries = {entry['id']: entry for entry in cls.book['entries']}

    def test_identity_and_japanese_pronunciation_are_unchanged(self):
        self.assertEqual(len(self.entries), 211)
        for before, after in zip(self.before['entries'], self.book['entries']):
            with self.subTest(id=before['id']):
                for field in ['id', 'text', 'reading', 'source', 'label']:
                    self.assertEqual(before[field], after[field])
                self.assertRegex(after['reading'], r'^[ぁ-ゖー、。「」！？!?・…]+$')
                self.assertEqual(after['example'], after['examples'][0])

    def test_critical_self_recognition_rule_and_exceptions(self):
        entry = self.entries['kg-p1-l11-g04']
        self.assertIn('自認の用法', entry['usage'])
        self.assertIn('動詞辞書形・ない形はこの用法では使わない', entry['usage'])
        self.assertIn('若いつもり', entry['text'])
        self.assertIn('自认为', entry['senses'][0]['meaning'])
        self.assertIn('する→せず', self.entries['kg-p3-l10-g04']['usage'])
        self.assertIn('だを付けない', self.entries['kg-p2-l01-g03']['usage'])

    def test_translations_remain_consistent_with_examples(self):
        changed = 0
        for before, after in zip(self.before['entries'], self.book['entries']):
            changed += before['meaning'] != after['meaning']
            self.assertEqual(after['meaning'], after['example']['meaning'])
            self.assertEqual(after['usage'].splitlines()[2], '用法：' + after['senses'][0]['meaning'])
        self.assertEqual(changed, 3)

    def test_authored_sentences_and_source_units_stay_explicit(self):
        entries = self.book['entries']
        self.assertEqual(sum('自编学习例句' in entry['detailsSource'] for entry in entries), 15)
        self.assertEqual(sum('原书例句经' in entry['detailsSource'] for entry in entries), 196)
        self.assertEqual(len({entry['label'].split('｜')[0] for entry in entries}), 36)
        self.assertIn('图像截断', self.entries['kg-p1-l06-g02']['detailsSource'])

    def test_only_reviewed_entries_changed_and_release_is_not_authorized(self):
        changed = {a['id'] for a, b in zip(self.before['entries'], self.book['entries']) if a != b}
        self.assertEqual(changed, {change['id'] for change in self.review['changes']})
        self.assertEqual(len(changed), 29)
        self.assertEqual(len(self.review['changes']), 30)
        self.assertEqual(hashlib.sha256(self.raw).hexdigest(), self.review['resultSha256'])
        self.assertIn('publication-not-authorized', self.review['status'])
        self.assertEqual(self.book['sourceType'], 'grammar')


if __name__ == '__main__':
    unittest.main()
