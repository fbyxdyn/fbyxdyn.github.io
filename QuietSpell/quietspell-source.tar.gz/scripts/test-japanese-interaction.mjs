import assert from 'node:assert/strict'
import test from 'node:test'
import { fileURLToPath } from 'node:url'
import { readFile } from 'node:fs/promises'
import { createRenderer, nextTick } from 'vue'
import { createServer } from 'vite'

const root = fileURLToPath(new URL('../', import.meta.url))
const vite = await createServer({
  configFile: false,
  root,
  cacheDir: `${root}.cache/vite-interaction-tests`,
  server: { middlewareMode: true },
  resolve: { alias: { '@': `${root}app` } },
  logLevel: 'error',
})
const { useJapanesePractice } = await vite.ssrLoadModule('/app/composables/useJapanesePractice.ts')

async function fixture(touch, mode = 'system', repeatCount = 1, saved) {
  const storage = new Map(saved ? [['typewords-japanese-practice-v1', JSON.stringify(saved)]] : [])
  globalThis.localStorage = {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => storage.set(key, value),
  }
  globalThis.document = { activeElement: null, querySelector: () => null }
  globalThis.window = { matchMedia: () => ({ matches: touch }), location: { protocol: 'http:' } }
  globalThis.fetch = () => Promise.resolve(new Response(new Uint8Array(1024), { headers: { 'Content-Type': 'audio/mpeg' } }))
  globalThis.Audio = class {
    play() {
      return Promise.resolve()
    }
    pause() {}
    load() {}
    removeAttribute() {}
  }
  let focusCalls = 0,
    blurCalls = 0,
    practice
  const renderer = createRenderer({
    createElement: () => ({}),
    createComment: () => ({}),
    createText: () => ({}),
    insert() {},
    remove() {},
    setText() {},
    setElementText() {},
    patchProp() {},
    parentNode: () => null,
    nextSibling: () => null,
  })
  const app = renderer.createApp({
    setup() {
      practice = useJapanesePractice({
        sharedSettings: {
          wordSound: false,
          wordSoundVolume: 100,
          wordSoundSpeed: 1,
          wordReviewRatio: 3,
          repeatCount,
          autoNextWord: false,
          waitTimeForChangeWord: 300,
          translate: true,
        },
      })
      practice.practiceMode.value = mode
      practice.inputRef.value = {
        focus() {
          focusCalls++
          document.activeElement = this
        },
        blur() {
          blurCalls++
          document.activeElement = null
        },
      }
      return () => null
    },
  })
  app.mount({})
  await nextTick()
  await nextTick()
  return { practice, app, storage, focusCalls: () => focusCalls, blurCalls: () => blurCalls }
}

try {
  await test('local Kanzen grammar is registered independently without vocabulary enrichment overwriting its content', async () => {
    const { N3_BOOKS } = await vite.ssrLoadModule('/app/core/japanese/n3-books.ts')
    const source = JSON.parse(await readFile(new URL('../app/core/japanese/books/n3-kanzen-grammar.json', import.meta.url), 'utf8'))
    const grammar = N3_BOOKS.find(book => book.id === 'n3-kanzen-grammar')
    assert.equal(grammar.sourceType, 'grammar')
    assert.deepEqual(grammar.entries, source.entries)
    assert.match(grammar.description, /在线试用/)
  })
  await test('both touch and PC retain Nanami/Keita selection across reloads without refocusing the input', async () => {
    for (const touch of [true, false]) {
      const f = await fixture(touch)
      assert.equal(f.practice.voice.value, 'ja-JP-NanamiNeural')
      const focused = f.focusCalls()
      f.practice.voice.value = 'ja-JP-KeitaNeural'
      await nextTick(); await nextTick()
      assert.equal(f.focusCalls(), focused)
      const saved = JSON.parse(f.storage.get('typewords-japanese-practice-v1'))
      assert.equal(saved.voice, 'ja-JP-KeitaNeural')
      f.app.unmount()
      const restored = await fixture(touch, 'system', 1, saved)
      assert.equal(restored.practice.voice.value, 'ja-JP-KeitaNeural')
      restored.app.unmount()
      saved.voice = 'invalid voice'
      const invalid = await fixture(touch, 'system', 1, saved)
      assert.equal(invalid.practice.voice.value, 'ja-JP-NanamiNeural')
      invalid.app.unmount()
    }
  })
  await test('switching to original voice cancels loading immediately and keeps that choice after reload', async () => {
    const f = await fixture(true)
    let signal
    globalThis.fetch = (_url, init) => {
      signal = init.signal
      return new Promise((_, reject) => signal.addEventListener('abort', () => reject(new DOMException('Canceled', 'AbortError')), { once: true }))
    }
    f.practice.speak()
    assert.equal(f.practice.playback.value.status, 'loading')
    f.practice.voice.value = 'original'
    assert.equal(signal.aborted, true)
    assert.equal(f.practice.playback.value.status, 'idle', 'voice watch must cancel synchronously')
    await nextTick(); await nextTick()
    const saved = JSON.parse(f.storage.get('typewords-japanese-practice-v1'))
    assert.equal(saved.voice, 'original')
    f.app.unmount()
    const restored = await fixture(true, 'system', 1, saved)
    assert.equal(restored.practice.voice.value, 'original')
    restored.app.unmount()
  })
  await test('Kanzen has an independent detail channel and neither channel overwrites source identity or meanings', async () => {
    const { N3_BOOKS } = await vite.ssrLoadModule('/app/core/japanese/n3-books.ts')
    const raw = await Promise.all(
      [0, 1].map(async i =>
        JSON.parse(await readFile(new URL(`../app/core/japanese/books/n3-pdf-${i}.json`, import.meta.url), 'utf8'))
      )
    )
    const kanzen = JSON.parse(
      await readFile(new URL('../app/core/japanese/books/n3-kanzen-enrichment.json', import.meta.url), 'utf8')
    )
    const kanzenIndex = new Map(kanzen.map(item => [`${item.text}\0${item.reading}`, item]))
    for (let i = 0; i < 2; i++) {
      const sourceById = new Map(raw[i].entries.map(item => [item.id, item]))
      for (const entry of N3_BOOKS[i].entries) {
        const source = sourceById.get(entry.id)
        assert.equal(entry.meaning, source.meaning)
        assert.deepEqual(entry.source, source.source)
        if (i === 1) assert.ok(!entry.detailsSource?.startsWith('复用已发布新东方'), entry.text)
        if (i === 0 && kanzenIndex.get(`${entry.text}\0${entry.reading}`)?.examples?.length)
          assert.ok(entry.examples?.length || entry.example, entry.text)
      }
    }
    assert.ok(N3_BOOKS[0].entries.some(entry => entry.detailsSource?.startsWith('复用已发布新东方')))
  })
  await test('touch devices never auto-focus on entry, book selection, skip or next; tapping the input still focuses', async () => {
    const { practice: p, app, focusCalls, blurCalls } = await fixture(true)
    assert.equal(focusCalls(), 0)
    p.selectLesson('everyday')
    await nextTick()
    assert.equal(focusCalls(), 0)
    p.inputRef.value.focus() // Represents an explicit tap, not programmatic application focus.
    assert.equal(focusCalls(), 1)
    const position = p.index.value
    p.skipSpelling()
    await nextTick()
    assert.equal(focusCalls(), 1)
    assert.equal(blurCalls(), 1)
    assert.equal(p.result.value, 'correct')
    assert.equal(p.showAnswer.value, true)
    assert.equal(p.index.value, position)
    assert.equal(p.stats.value.correct, 1)
    assert.equal(p.stats.value.mistakes.length, 0)
    p.next()
    await nextTick()
    assert.equal(p.index.value, position + 1)
    assert.equal(focusCalls(), 1)
    app.unmount()
  })
  await test('listening and recall reveal details after skip or a correct answer, and hide them for the next item', async () => {
    for (const mode of ['listen', 'recall']) {
      const { practice: p, app } = await fixture(true, mode)
      assert.equal(p.showAnswer.value, false)
      p.skipSpelling()
      assert.equal(p.showAnswer.value, true)
      p.next()
      await nextTick()
      assert.equal(p.showAnswer.value, false)
      p.input.value = p.entry.value.text
      p.submit()
      assert.equal(p.showAnswer.value, true)
      assert.equal(p.stats.value.correct, 2)
      app.unmount()
    }
  })
  await test('desktop retains keyboard focus and skipped follow-writing bypasses repeated spelling', async () => {
    const { practice: p, app, focusCalls } = await fixture(false, 'free', 3)
    assert.ok(focusCalls() > 0)
    const position = p.index.value
    p.skipSpelling()
    assert.equal(p.index.value, position)
    p.next()
    await nextTick()
    assert.equal(p.index.value, position + 1)
    app.unmount()
  })
} finally {
  await vite.close()
}
