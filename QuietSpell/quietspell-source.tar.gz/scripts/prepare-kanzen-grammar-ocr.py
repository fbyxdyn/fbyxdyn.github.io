"""Render the user-provided grammar PDF into local overlapping OCR tiles."""
import json
from pathlib import Path
import pypdfium2 as pdfium

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'tmp/pdfs/kanzen-grammar'
source=list(Path('E:/迅雷下载').glob('*友松悦子*.pdf'))
assert len(source)==1
document=pdfium.PdfDocument(source[0])
jobs={'ja':[],'zh-Hans-CN':[]}
(OUT/'tiles').mkdir(parents=True,exist_ok=True)
for index in range(len(document)):
    page=document[index]
    image=page.render(scale=1900/page.get_width()).to_pil().convert('RGB')
    width,height=image.size
    positions=[0] if height<=1850 else [0,height-1850]
    for tile,y in enumerate(positions):
        path=OUT/'tiles'/f'p{index+1:03}-{tile}.png'
        if not path.exists():image.crop((0,y,width,min(y+1850,height))).save(path)
        for lang in jobs:
            folder=OUT/lang;folder.mkdir(exist_ok=True)
            jobs[lang].append({'book':4,'page':index+1,'image':str(path),
                               'output':str(folder/f'p{index+1:03}-{tile}.json'),'offsetY':y,'fullHeight':height})
    page.close()
    if (index+1)%25==0:print('Rendered',index+1,'/',len(document),flush=True)
for lang,items in jobs.items():
    (OUT/f'jobs-{lang}.json').write_text(json.dumps(items,ensure_ascii=False),encoding='utf-8')
print('Prepared',len(document),'pages;',len(jobs['ja']),'tiles per OCR language',flush=True)
