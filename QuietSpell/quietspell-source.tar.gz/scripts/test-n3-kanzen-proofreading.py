"""Data invariants and scan-verified regressions for the local Kanzen preview."""
import hashlib
import json
from pathlib import Path
import re
import unittest

ROOT=Path(__file__).resolve().parents[1]
BOOKS=ROOT/'app/core/japanese/books'


class KanzenProofreadingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.book=json.loads((BOOKS/'n3-pdf-0.json').read_text(encoding='utf-8'))
        cls.by_number={e['source']['number']:e for e in cls.book['entries']}
        cls.ledger=json.loads((ROOT/'scripts/n3-proofreading-corrections.json').read_text(encoding='utf-8'))['books']['0']

    def test_full_book_and_stable_ids(self):
        self.assertEqual(set(self.by_number),set(range(1,1801)))
        self.assertEqual(len(self.book['entries']),1800)
        for number,e in self.by_number.items():
            self.assertEqual(e['id'],f'n3-0-{number}')
            self.assertEqual(e['source']['book'],0)
            self.assertTrue(9<=e['source']['page']<=244)
            self.assertRegex(e['reading'],r'^[ぁ-ゖー]+$')
            self.assertTrue(e['text'] and e['meaning'])

    def test_all_scan_verified_corrections_survive_regeneration(self):
        for number,correction in self.ledger.items():
            if not correction.get('verified'):continue
            entry=self.by_number[int(number)]
            for field in correction.get('reviewedFields',[]):
                with self.subTest(number=number,field=field):
                    self.assertEqual(entry[field],correction[field])

    def test_meaningful_ocr_regressions(self):
        expected={
            533:('非常口','ひじょうぐち','安全出口'),
            680:('皮膚科','ひふか','皮肤科'),
            715:('係り','かかり','负责人'),
            1097:('当日','とうじつ','当天'),
            1150:('ファスナー','ふぁすなー','拉链'),
            1194:('小麦粉','こむぎこ','小麦粉'),
            1692:('じっと','じっと','一动不动'),
            1695:('少しも','すこしも','一点也不'),
        }
        for n,values in expected.items():
            self.assertEqual(tuple(self.by_number[n][f] for f in ['text','reading','meaning']),values)
        # Printed alternative readings must not be silently replaced by the dictionary.
        self.assertEqual(self.by_number[473]['reading'],'わるくち')
        self.assertEqual(self.by_number[609]['reading'],'ゆき')
        self.assertEqual(self.by_number[885]['reading'],'ほいくしょ')

    def test_published_shared_input_is_reproducible(self):
        # This is the immutable shared input used for the Kanzen merge. Later
        # authorized pronunciation corrections may update the live app data.
        snapshot=ROOT/'.cache/releases/quietspell-20261121-preview/app/core/japanese/books'
        for name,expected in {
            'n3-pdf-1.json':'e24ebafc7dd4ef31096b350eaccdb9261452764c8c52b84211f471de1bf08c42',
            'n3-enrichment.json':'604ddd5e12a8138ac41d49af6ed8410b4be8848e3f0b923262fe705e5262bd1a',
        }.items():
            self.assertEqual(hashlib.sha256((snapshot/name).read_bytes()).hexdigest(),expected)

    def test_reviewed_examples_match_the_current_book(self):
        data=json.loads((ROOT/'output/n3-books/kanzen/source-examples.json').read_text(encoding='utf-8'))
        self.assertEqual(data['sourceBookSha256'],hashlib.sha256((BOOKS/'n3-pdf-0.json').read_bytes()).hexdigest())
        self.assertEqual(len(data['entries']),103)
        self.assertEqual(len({e['id'] for e in data['entries']}),103)
        for e in data['entries']:
            n=int(e['id'].split('-')[-1])
            self.assertEqual((e['text'],e['reading']),(self.by_number[n]['text'],self.by_number[n]['reading']))
            example=e['examples'][0]
            self.assertRegex(example['reading'],r'^[ぁ-ゖー、。！？!?]+$')
            self.assertTrue(example['text'].endswith('。'))
            self.assertTrue(example['meaning'].endswith(('。','？')))
        by_id={e['id']:e['examples'][0] for e in data['entries']}
        self.assertIn('はちじゅうまんえん',by_id['n3-0-938']['reading'])
        self.assertIn('せんきゅうひゃくろくじゅうねんだい',by_id['n3-0-248']['reading'])
        self.assertIn('くじに',by_id['n3-0-1066']['reading'])
        self.assertIn('しゅうにみっか',by_id['n3-0-1083']['reading'])
        self.assertTrue(by_id['n3-0-278']['text'].startswith('泳ぐまえに、'))


if __name__=='__main__':unittest.main()
