"""Hand-reviewed numeric reading replacements; never edits shared app/audio files."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
path=ROOT/'app/core/japanese/books/n3-enrichment.json'
details=json.loads(path.read_text(encoding='utf-8'))
# Only the numeric/counter fragment is changed. Existing OCR sentence issues
# remain visible in the separate review list instead of being guessed here.
rules='''虎|いちひき|いっぴき
大会|はちかいめ|はっかいめ
物忘れ|ごれいさい|ごじゅっさい
面会|いちいちじ|じゅういちじ
休憩|にれいふんかん|にじゅっぷんかん
休養|いちしゅうかん|いっしゅうかん
遅刻|さんれいふん|さんじゅっぷん
発電|にれいねん|にじゅうねん
部品|いちはちれいえん|ひゃくはちじゅうえん
往復|きゅうはちえん|きゅうじゅうはちえん
遅れ|ごぶん|ごふん
貸し|いちれいまんえん|じゅうまんえん
会合|らいげついちにち|らいげつついたち
締め切り|さんれいにち|さんじゅうにち
期間|ろくがついちいちにち|ろくがつじゅういちにち
世紀|いちごせいき|じゅうごせいき
発車|さんれいふん|さんじゅっぷん
無理|いちはちぺーし|じゅうはちぺーし
制限|いちれいふん|じゅっぷん
階段|さんかい|さんがい
対象|にいつかに|にじゅうごにちに
配達|ごぜんきゅうじ|ごぜんくじ
以後|いちいちじ|じゅういちじ
以上|ろくれいさい|ろくじゅっさい
数|さんれいれいれいにん|さんぜんにん
教科書|はちさつ|はっさつ
郵送|いちにがついちいちにち|じゅうにがつじゅういちにち
事情|いちれいねん|じゅうねん
住居|にれいれいれいけん|にせんけん
食後|さんれいふん|さんじゅっぷん
水準|いちれいねん|じゅうねん
針|いちれいじ|じゅうじ
帯|はちによんれいえん|はっせんにひゃくよんじゅうえん
座席|あさきゅうじ|あさくじ
体温|さんきゅうど|さんじゅうきゅうど
休業|いちれいがついちにち|じゅうがつついたち
時速|にれいれいきろめーとる|にひゃくきろめーとる
左折|いちれいめーとる|じゅうめーとる
宿泊|はちせんにん|はっせんにん
定員|にれいめい|にじゅうめい
徒歩|にれいふん|にじゅっぷん
昼寝|さんれいふん|さんじゅっぷん
開く|あさきゅうじ|あさくじ
開ける|にれいれいぺーじ|にひゃくぺーじ
倒す|さんついに|さんたいに
起きる|いちにじ|じゅうにじ
飼う|はちひき|はっぴき
経つ|にれいねん|にじゅうねん
ぶつかる|ふつつ|ふたつ
変える|いちいちじ|じゅういちじ
返す|いちしゅうかん|いっしゅうかん
行う|よんがつ|しがつ
覚ます|いちいちじ|じゅういちじ
下る|はちれいれいまんえん|はっぴゃくまんえん
進める|いちれいふん|じゅっぷん
越える|はちごてん|はちじゅうごてん
移る|さんかい|さんがい
済む|さんごれいえん|さんびゃくごじゅうえん
延ばす|いちごふん|じゅうごふん
載る|にれいとん|にじゅっとん
纏める|いちごれいじ|ひゃくごじゅうじ
打つ|にぽん|にほん
注ぐ|さんふん|さんぷん
加わる|いちれいまんえん|じゅうまんえん
加える|いちににはちをくわえるとにれい|じゅうににはちをくわえるとにじゅう
不可能|いちかげつ|いっかげつ
無駄|いちふん|いっぷん
確か|にごにち|にじゅうごにち
大体|ななれいまんえん|ななじゅうまんえん
唯|いちぶん|いっぷん
かなり|さんれいふん|さんじゅっぷん
勿論|いちれいねん|じゅうねん
インターネット|いちにちちゅう|いちにちじゅう
パーセント|さんれいぱーせんと|さんじゅうぱーせんと
ロビー|いちかい|いっかい
ブラシ|いちかげつにいちかい|いっかげつにいっかい'''
suggestions=[];unmatched=[]
for line in rules.splitlines():
    head,old,new=line.split('|')
    matches=[]
    for entry in details:
        if entry['text']!=head:continue
        for example in entry.get('examples',[]):
            if old not in example['reading']:continue
            matches.append({'text':entry['text'],'reading':entry['reading'],'exampleText':example['text'],
                            'oldReading':example['reading'],'newReading':example['reading'].replace(old,new),
                            'replacement':{'old':old,'new':new},'note':'只校正数字/量词读音；未在此修改日文 OCR 句文。'})
    if not matches:unmatched.append(line)
    suggestions.extend(matches)
out=ROOT/'output/n3-books/kanzen/numeric-reading-suggestions.json'
result={'sourceSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'suggestions':suggestions,'unmatchedRules':unmatched,
        'stillNeedsSentenceReview':['虎：こ虎が 的开头可能漏字','後輩：借リたままた','往復：往復の賃 可能漏字','期間：乃日 数字未识清','本部：0やIUCN 机构名未识清','無理：ニ日/ペーシ','以後：長11時 的開頭','住居：2000件 是否应为2000軒需对图','経つ：ドイツへ棄てから','備える：中文译文混入日文','すっかり：衄に落ちて','グループ：でラした','セット：目見まし時計']}
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(suggestions),'numeric/counter corrections;',len(unmatched),'unmatched rules')
