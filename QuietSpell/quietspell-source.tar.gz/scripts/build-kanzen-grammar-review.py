"""Build only curated grammar records. Raw OCR drafts are never app inputs."""
import argparse
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/n3-books/kanzen-grammar';OUT.mkdir(parents=True,exist_ok=True)
p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');args=p.parse_args()
spec=importlib.util.spec_from_file_location('n3_source',ROOT/'scripts/build-n3-wordbooks.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)


def read_tsv(name,count):
    rows=[]
    for line in (ROOT/'scripts/data'/name).read_text(encoding='utf-8').splitlines():
        if not line.strip() or line.startswith('#'):continue
        row=line.split('|');assert len(row)==count,(name,row)
        rows.append(row)
    return rows


def reading(text):
    result=''.join(s.hiragana(t['read'] if t['pos']!='記号' else t['string']) for t in s.pyopenjtalk.run_frontend(text))
    result=result.replace('あづけ','あずけ')
    return result


main={f'{int(r[0])}-{int(r[1])}':r for r in read_tsv('kanzen-grammar-main-units.tsv',7)}
records=[]
for key,text,translation,origin in read_tsv('kanzen-grammar-main-reviewed-examples.tsv',4):
    lesson,point,page,top,title,connection,meaning=main[key]
    if key=='12-2':page='60'
    if key=='5-3':page='38'
    records.append({'id':f'kg-p1-l{int(lesson):02}-g{int(point):02}','chapter':f'第1部・第{lesson}課',
                    'page':int(page),'title':title,'connection':connection,'meaning':meaning,
                    'text':text,'translation':translation,'origin':origin})
for key,chapter,page,title,connection,meaning,text,translation,origin in read_tsv('kanzen-grammar-organized-reviewed.tsv',9):
    records.append({'id':f'kg-p1-{key.lower()}','chapter':f'第1部・{chapter}','page':int(page),'title':title,
                    'connection':connection,'meaning':meaning,'text':text,'translation':translation,'origin':origin})
extra=ROOT/'scripts/data/kanzen-grammar-composition-reviewed.tsv'
if extra.exists():
    for key,chapter,page,title,connection,meaning,text,translation,origin in read_tsv(extra.name,9):
        records.append({'id':f'kg-{key.lower()}','chapter':chapter,'page':int(page),'title':title,'connection':connection,
                        'meaning':meaning,'text':text,'translation':translation,'origin':origin})
assert len({r['id'] for r in records})==len(records)
entries=[];issues=[]
corrections=json.loads((ROOT/'scripts/data/kanzen-grammar-reading-corrections.json').read_text(encoding='utf-8'))
for number,r in enumerate(records,1):
    kana=reading(r['text'])
    for correction in corrections.get(r['id'],[]):
        assert correction['old'] in kana, f"Reading correction drift: {r['id']}"
        kana=kana.replace(correction['old'],correction['new'])
    if not re.fullmatch('[ぁ-ゖー、。「」！？!?・…]+',kana):issues.append({'id':r['id'],'text':r['text'],'reading':kana,'reason':'non-kana reading'})
    source_note='原书例句经 OCR 与语言校订，中文译文重新整理' if r['origin']=='source' else '自编学习例句（与原书语法点对应）'
    if r['id'] in ('kg-p1-l06-g02','kg-p1-l06-g03'):
        source_note+='；原 PDF 第39页下半页图像截断，不能恢复该处原书例句'
    example={'text':r['text'],'reading':kana,'meaning':r['translation']}
    entries.append({'id':r['id'],'text':r['text'],'reading':kana,'meaning':r['translation'],
                    'label':f"{r['chapter']}｜{r['title']}",'partOfSpeech':'语法',
                    'senses':[{'partOfSpeech':'语法','meaning':r['meaning']}],
                    'usage':f"语法：{r['title']}\n接续：{r['connection']}\n用法：{r['meaning']}",
                    'example':example,'examples':[example],
                    'detailsSource':f"《新完全掌握日语N3语法》友松悦子等；PDF 第{r['page']}页。{source_note}。",
                    'source':{'book':4,'page':r['page'],'number':number}})
chapter_counts=dict(collections.Counter(r['chapter'] for r in records))
book={'id':'n3-kanzen-grammar','title':'新完全掌握 N3 · 语法',
      'description':f'本地审核稿（整理中）：当前{len(entries)}项语法与用法，含接续、中文说明及可朗读例句；保留PDF页码，少量自编例句明确标注。尚未发布。',
      'kind':'words','sourceType':'grammar','entries':entries}
preview=OUT/'n3-kanzen-grammar-preview.json';preview.write_text(json.dumps(book,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report={'status':'local-review-only; work-in-progress','entries':len(entries),'chapters':chapter_counts,
        'sourceExamples':sum(r['origin']=='source' for r in records),'authoredExamples':sum(r['origin']=='authored' for r in records),
        'readingIssues':issues,'previewSha256':hashlib.sha256(preview.read_bytes()).hexdigest(),
        'sourceImageDefects':[39,42],'rawOcrIsAppInput':False}
(OUT/'grammar-review-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if args.apply:
    assert not issues,'Resolve reading issues before writing app data'
    (ROOT/'app/core/japanese/books/n3-kanzen-grammar.json').write_bytes(preview.read_bytes())
print(json.dumps(report,ensure_ascii=False))
