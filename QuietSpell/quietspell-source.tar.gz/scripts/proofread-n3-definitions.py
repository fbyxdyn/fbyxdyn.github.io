"""Recover printed Chinese definitions using isolated line crops, without uploading PDFs."""
import json
from pathlib import Path
import re
import sys
ROOT=Path(__file__).resolve().parents[1];TMP=ROOT/'tmp/pdfs'
sys.path.insert(0,str(ROOT/'.cache/ocr-tools'))
import cv2
import numpy as np
from PIL import Image
from rapidocr import RapidOCR,OCRVersion,ModelType
from rapidocr.ch_ppocr_rec.typings import TextRecInput
engine=RapidOCR(params={'Global.use_det':False,'Global.use_cls':False,'Global.model_root_dir':str(ROOT/'.cache/ocr-models'),'Rec.lang_type':'ch','Rec.ocr_version':OCRVersion.PPOCRV4,'Rec.model_type':ModelType.MOBILE,'Rec.rec_img_shape':[3,48,320],'Rec.rec_batch_num':64,'EngineConfig.onnxruntime.intra_op_num_threads':6,'EngineConfig.onnxruntime.inter_op_num_threads':1})
rec=engine._load_rec_model()
out=TMP/'proofread-definitions-v3';out.mkdir(exist_ok=True)
files=sorted((TMP/'recognized-cells-v4').glob('*.json'))
for counter,f in enumerate(files):
 if (out/f.name).exists():continue
 cells=json.loads(f.read_text(encoding='utf-8'));bid=cells[0]['book'];p=cells[0]['page'];name=f'b{bid}-p{p:03}'
 if bid==1:
  (out/f.name).write_bytes((TMP/'proofread-definitions'/f.name).read_bytes());continue
 meta=json.loads((TMP/'ja'/f'{name}-1.json').read_text(encoding='utf-8'))
 im=Image.new('RGB',(meta['width'],meta['fullHeight']),'white');im.paste(Image.open(TMP/'tiles'/f'{name}-0.png'),(0,0));im.paste(Image.open(TMP/'tiles'/f'{name}-1.png'),(0,meta['offsetY']))
 crops=[];keys=[];result={}
 for c in cells:
  left,_,right,_=map(int,c['wordBox']);left=max(0,left-5)
  top=int(c['top']+115 if bid==0 else c['posY']+43)
  bottom=int(min(c['top']+365,c['bottom']-8) if bid==0 else c['posY']+156)
  if bottom-top<20:continue
  crop=np.array(im.crop((left,top,right,bottom)))
  # The blue definitions in book 0 have better contrast in the red channel.
  gray=crop[:,:,0] if bid==0 else cv2.cvtColor(crop,cv2.COLOR_RGB2GRAY)
  mask=np.uint8(((crop[:,:,2].astype(int)-crop[:,:,0].astype(int)>12)&(gray<180)) if bid==0 else gray<165)*255
  h,w=mask.shape
  columns=np.where(np.sum(mask>0,axis=0)>h*.88)[0]
  columns=columns[columns>min(220,w*.65)]
  if len(columns):
   gray=gray[:,:max(10,int(columns[0])-3)];mask=mask[:,:gray.shape[1]]
  horiz=cv2.morphologyEx(mask,cv2.MORPH_OPEN,np.ones((1,max(50,int(mask.shape[1]*.75))),np.uint8))
  mask=cv2.subtract(mask,horiz)
  rows=np.sum(mask>0,axis=1)>3
  spans=[];start=None
  for y,v in enumerate([*rows,False]):
   if v and start is None:start=y
   elif not v and start is not None:
    if y-start>=11:spans.append((max(0,start-2),min(h,y+2)))
    start=None
  result[str(c['number'])]=[]
  for a,b in spans:
   xs=np.where(np.any(mask[a:b]>0,axis=0))[0]
   if len(xs)<5:continue
   line=gray[a:b,max(0,xs.min()-3):min(gray.shape[1],xs.max()+4)]
   line=cv2.copyMakeBorder(line,4,4,4,4,cv2.BORDER_CONSTANT,value=255)
   crops.append(cv2.cvtColor(line,cv2.COLOR_GRAY2RGB));keys.append((c['number'],top+a,b-a))
 if crops:
  cached=TMP/'proofread-definitions-v2'/f.name
  old=json.loads(cached.read_text(encoding='utf-8')) if cached.exists() else {}
  if cached.exists() and sum(len(v) for v in old.values())==len(keys):
   found_text=[];found_scores=[];offsets={}
   for n,_,_ in keys:
    offset=offsets.get(n,0);v=old[str(n)][offset];offsets[n]=offset+1
    found_text.append(v['text']);found_scores.append(v['score'])
  else:
   found=rec(TextRecInput(img=crops));found_text=found.txts;found_scores=found.scores
  for (n,y,h),t,score in zip(keys,found_text,found_scores):result[str(n)].append({'text':re.sub(r'\s+','',t),'score':round(float(score),5),'top':y,'height':h})
 (out/f.name).write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
 if (counter+1)%25==0:print(f'Chinese definitions {counter+1}/{len(files)} pages',flush=True)
print('Chinese definition crops complete.',flush=True)
