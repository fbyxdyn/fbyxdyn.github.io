"""Reconstruct N3 study books from local PDF OCR. Raw scans remain in tmp/pdfs, never in public."""
import collections
from difflib import SequenceMatcher
from functools import lru_cache
import json
from pathlib import Path
import re
import sys
import unicodedata

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'.cache/japanese-audio-tools'))
import pyopenjtalk
TMP=ROOT/'tmp/pdfs'
OUT=ROOT/'app/core/japanese/books';OUT.mkdir(exist_ok=True)
REPORT=ROOT/'output/n3-books';REPORT.mkdir(parents=True,exist_ok=True)
KANA=re.compile('[ぁ-ヿ]')
HAN=re.compile('[一-鿿]')

def compact(value): return re.sub(r'\s+','',value).replace('\x07','')
def hiragana(value): return ''.join(chr(ord(c)-0x60) if 'ァ'<=c<='ヶ' else c for c in unicodedata.normalize('NFKC',value))
def loose_kana(value):
    value=unicodedata.normalize('NFD',hiragana(value)); value=''.join(c for c in value if unicodedata.category(c)!='Mn')
    return value.translate(str.maketrans('ぁぃぅぇぉゃゅょっ','あいうえおやゆよつ'))

@lru_cache(maxsize=20000)
def dictionary_reading(value):
    if not HAN.search(value): return hiragana(value)
    try: return hiragana(''.join(item['read'] if item['pos']!='記号' else item['string'] for item in pyopenjtalk.run_frontend(value)))
    except Exception: return ''

def read_ocr(book,language):
    pages=collections.defaultdict(list)
    refined_language='ja' if language=='ja' else 'ch'
    for file in sorted((TMP/language).glob(f'b{book}-*.json')):
        data=json.loads(file.read_text(encoding='utf-8'))
        refined_file=TMP/f'refined-{refined_language}'/file.name
        refined=json.loads(refined_file.read_text(encoding='utf-8')) if refined_file.exists() else {}
        for index,line in enumerate(data['lines']):
            words=line['words']; correction=refined.get(str(index),{})
            raw=compact(line['text']); text=compact(correction.get('text',raw))
            score=correction.get('score',None)
            if score is not None and score<.65: text=raw
            record={'text':text,'raw':raw,'score':score,'x':min(w['x'] for w in words),'y':min(w['y'] for w in words)+data['offsetY'],'right':max(w['x']+w['width'] for w in words),'bottom':max(w['y']+w['height'] for w in words)+data['offsetY'],'h':max(w['height'] for w in words),'width':data['width'],'fullHeight':data['fullHeight'],'words':words}
            # Dominant glyphs exclude tiny part-of-speech badges beside headwords.
            record['dominant']=compact(''.join(w['text'] for w in words if w['height']>=record['h']*.72))
            current=pages[data['page']]
            old=next((item for item in current if abs(item['x']-record['x'])<10 and abs(item['y']-record['y'])<5 and abs(item['h']-record['h'])<8),None)
            if old:
                if (record['score'] or 0)>(old['score'] or 0) or len(record['text'])>len(old['text'])+3:
                    current.remove(old);current.append(record)
            else: current.append(record)
    for records in pages.values(): records.sort(key=lambda item:(item['y'],item['x']))
    return pages

def clean_head(value):
    value=value.replace('／','/').strip('□■●○◯・*✳★0123456789:：()（） ,，')
    value=re.sub(r'[①-⑳⓪]','',value)
    return value

def chinese_lines(lines,top,bottom,left=True):
    selected=[]
    for line in lines:
        if not top<=line['y']<bottom:continue
        if left and line['x']>=line['width']*.35:continue
        if not left and line['x']<line['width']*.35:continue
        text=line['text']
        if not HAN.search(text) or re.search('[A-Za-zぁ-ヿ]',text):continue
        if line['h']>=49:continue
        if re.search('^.[、,，]?名[、,，]|^(?:名|ナ形|イ形|副|動)[、,，]',text):continue
        text=text.strip('，,、。ー一- ·')
        if text:selected.append((line['y'],text))
    return selected

def make_entry(book,page,number,head,reading,meaning,example=None,score=None,label=None):
    head=clean_head(head)
    if not head or not re.search('[ぁ-ヿ一-鿿]',head):return None
    head=head.split('/')[0].strip()
    reading=hiragana(clean_head(reading)).replace('/','')
    if not reading or re.search('[^ぁ-ゖー・。、]',reading): reading=dictionary_reading(head)
    expected=dictionary_reading(head)
    # Correct common small-kana/voicing OCR errors when the written form agrees.
    if expected and loose_kana(reading)==loose_kana(expected):reading=expected
    entry={'id':f'n3-{book}-{number}','text':head,'reading':reading,'meaning':meaning or head,'source':{'book':book,'page':page,'number':number}}
    if score is not None:entry['source']['confidence']=score
    if label:entry['label']=label
    if example and example.get('text'):entry['example']=example
    return entry

def scanned_books():
    books=[];issues=[]
    for book in [0,1]:
        ja=read_ocr(book,'ja');zh=read_ocr(book,'zh-Hans-CN');entries=[]
        for page,lines in ja.items():
            if (book==0 and not 9<=page<=244) or (book==1 and not 18<=page<=305):continue
            width=lines[0]['width'] if lines else 1900
            left=[l for l in lines if l['x']<width*.33]
            if book==0:
                anchors=[]
                for l in left:
                    candidate=re.sub('[□■口ロ\[\]()]','',l['raw']).translate(str.maketrans('OoODIl|ZSBgq','000011125899'))
                    if re.fullmatch(r'\d{3,5}',candidate) and width*.07<l['x']<width*.18 and 22<l['h']<45 and l['y']>180:
                        candidate=candidate[-4:]
                        if 0<int(candidate)<=1800: anchors.append({**l,'raw':candidate})
            else:
                heights=sorted(l['h'] for l in left if l['h']>35 and re.search('[ぁ-ヿ一-鿿]',l['text']))
                threshold=heights[int(len(heights)*.85)]*.83 if heights else 46
                anchors=[l for l in left if l['h']>=threshold and re.search('[ぁ-ヿ一-鿿]',l['text']) and l['y']>180 and l['y']<l['fullHeight']-100]
                # A wrapped headword is part of its preceding anchor.
                grouped=[]
                for item in anchors:
                    if grouped and item['y']-grouped[-1]['y']<75:
                        grouped[-1]['text']+=item['text'];grouped[-1]['bottom']=item['bottom']
                    else:grouped.append(dict(item))
                anchors=grouped
            anchors.sort(key=lambda l:l['y'])
            for i,anchor in enumerate(anchors):
                top=anchor['y'];bottom=anchors[i+1]['y'] if i+1<len(anchors) else anchor['fullHeight']-70
                if book==0:
                    number=int(anchor['raw'])
                    heads=[l for l in left if top+30<l['y']<bottom-15 and l['h']>=46 and re.search('[ぁ-ヿ一-鿿]',l['text'])]
                    if not heads:
                        issues.append({'book':book,'page':page,'number':number,'reason':'missing headword'});continue
                    first=heads[0]
                    if len(heads)>1 and KANA.search(first['text']) and not HAN.search(first['text']) and HAN.search(heads[1]['text']):
                        wordline=heads[1];reading=first['text']
                    else:wordline=first;reading=first['text'] if not HAN.search(first['text']) else ''
                else:
                    number=len(entries)+1;wordline=anchor
                    ruby=[l for l in left if top-70<l['y']<top-4 and l['h']<38 and KANA.search(l['text']) and not HAN.search(l['text'])]
                    reading=''.join(l['text'] for l in ruby)
                head=wordline['text']
                if head.endswith('する') and not wordline['dominant'].endswith('する'):head=head[:-2]
                meaning_rows=chinese_lines(zh.get(page,[]),wordline['bottom']+8,bottom)
                meaning='；'.join(text for _,text in meaning_rows[:2])
                # Original examples are optional; keep only complete Japanese sentence lines.
                right=[l for l in lines if l['x']>width*.35 and top-40<l['y']<bottom and l['h']>=30 and KANA.search(l['text']) and not l['text'].startswith(('*','＊','米','十','0'))]
                example=None
                if right:
                    sentence=right[0]['text']
                    if len(right)>1 and not re.search('[。！？]$',sentence) and right[1]['y']-right[0]['bottom']<55:sentence+=right[1]['text']
                    if 5<len(sentence)<200 and re.search('[。！？]$',sentence):
                        translations=chinese_lines(zh.get(page,[]),right[0]['bottom']+5,min(bottom,right[0]['bottom']+180),left=False)
                        example={'text':sentence,'reading':dictionary_reading(sentence),'meaning':''.join(t for _,t in translations[:2])}
                entry=make_entry(book,page,number,head,reading,meaning,example,wordline['score'])
                if entry:entries.append(entry)
        if book==0:
            best={}
            for entry in entries:
                old=best.get(entry['id'])
                if not old or entry['source'].get('confidence',0)>old['source'].get('confidence',0):best[entry['id']]=entry
            entries=sorted(best.values(),key=lambda e:e['source']['number'])
            missing=sorted(set(range(1,1801))-{e['source']['number'] for e in entries})
            issues.append({'book':0,'missingNumbers':missing})
        title=['新完全掌握 N3 · 高频词汇','新东方 N3 · 核心词汇'][book]
        books.append({'id':f'n3-pdf-{book}','title':title,'description':'从本地扫描 PDF 识别整理，附原书页码；释义及例句可对照原书核对。','kind':'words','entries':entries,'sourceType':'vocabulary'})
        print(f'Book {book}: {len(entries)} entries',flush=True)
    return books,issues

def grammar_book():
    pages=json.loads((TMP/'text-book-2.json').read_text(encoding='utf-8'))
    entries=[];pending=None;collecting=None
    def flush():
        nonlocal pending
        if not pending or not pending.get('example'):return
        example=pending['example'];sentence=compact(example['text']).lstrip('･・')
        if not sentence or not KANA.search(sentence):return
        meaning=compact(example.get('meaning',''))
        label=pending['label']
        item=make_entry(2,pending['page'],len(entries)+1,sentence,dictionary_reading(sentence),meaning, label=label)
        if item:entries.append(item)
    for page in pages:
        if not 22<=page['page']<=220:continue
        for line in page['lines']:
            text=compact(line['text'])
            if line['heading'] and re.match(r'^\d{1,3}',text):
                flush();pending={'page':page['page'],'label':compact(line['heading'])};collecting=None
            elif pending and text.startswith(('･','・')) and not pending.get('example'):
                pending['example']={'text':text[1:],'meaning':''};collecting='ja'
            elif pending and pending.get('example') and collecting:
                if KANA.search(text) and not text.startswith(('接续','解说','考题','解析','译文')) and collecting=='ja':pending['example']['text']+=text
                elif not KANA.search(text) and HAN.search(text) and not re.match(r'^(新日语|无敌|第\d|考题|解析|译文|接续|解说)',text):
                    pending['example']['meaning']+=text;collecting='zh'
                else:collecting=None
    flush()
    print(f'Book 2: {len(entries)} grammar examples',flush=True)
    return {'id':'n3-pdf-2','title':'绿宝书 N3 · 语法例句','description':'本书是语法书：按句型提取首个例句，逐句练习；上方显示对应语法点。','kind':'words','sourceType':'grammar','entries':entries}

def listening_book():
    # These bilingual pages contain explicit everyday expressions and usage explanations.
    import pdfplumber
    manifest=json.loads((TMP/'manifest.json').read_text(encoding='utf-8'))
    entries=[];seen=set()
    with pdfplumber.open(manifest[3]['path']) as document:
        pending=None
        table_started=False
        pairs=[]
        for page_number in [51,52,53]:
            page=document.pages[page_number-1]
            filtered=page.filter(lambda obj:obj['object_type']!='char' or obj['size']>=8)
            for line in filtered.extract_text_lines():
                chars=line['chars']
                if compact(line['text']).startswith('例1'):break
                japanese=compact(''.join(c['text'] for c in chars if 'MS-Mincho' in c['fontname']))
                chinese=compact(''.join(c['text'] for c in chars if 'FZSSK' in c['fontname']))
                if japanese.startswith('行ってきます'):table_started=True
                if not table_started:continue
                if japanese and chinese:
                    if pending:pairs.append(pending)
                    pending={'ja':japanese,'zh':chinese,'page':page_number}
                elif pending and japanese and KANA.search(japanese) and not pending['ja'].endswith('。'):
                    pending['ja']+=japanese
                elif pending and not japanese and chinese and not chinese.startswith(('常见','续表')):
                    pending['zh']+=chinese
        if pending:pairs.append(pending)
        for pair in pairs:
                japanese=pair['ja'];chinese=pair['zh'];page_number=pair['page']
                # Expand slash-separated alternatives into independently usable expressions.
                for term in japanese.split('/'):
                    term=re.sub(r'（([^）]*)）',r'\1',term).strip('。')
                    if not term or term in seen:continue
                    seen.add(term)
                    item=make_entry(3,page_number,len(entries)+1,term,dictionary_reading(term),chinese)
                    if item:entries.append(item)
    print(f'Book 3: {len(entries)} listening expressions',flush=True)
    return {'id':'n3-pdf-3','title':'非凡 N3 · 听解常用表达','description':'本书是听解书：提取常用寒暄与应答表达，释义说明使用场景。','kind':'words','sourceType':'listening','entries':entries}

if __name__=='__main__':
    books,issues=scanned_books();books.extend([grammar_book(),listening_book()])
    for book in books:(OUT/f"{book['id']}.json").write_text(json.dumps(book,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (REPORT/'recognition-report.json').write_text(json.dumps({'books':[{'id':b['id'],'title':b['title'],'entries':len(b['entries'])} for b in books],'issues':issues},ensure_ascii=False,indent=2),encoding='utf-8')
