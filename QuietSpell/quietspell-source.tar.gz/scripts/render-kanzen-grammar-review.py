"""Render source snippets for manual verification of the grammar review draft."""
import json
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from kanzen_grammar_ocr import ROOT,TMP

units=json.loads((ROOT/'output/n3-books/kanzen-grammar/main-draft.json').read_text(encoding='utf-8'))
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',18)
page=None
for start in range(0,len(units),12):
    canvas=Image.new('RGB',(2400,4*205),'#ddd');draw=ImageDraw.Draw(canvas)
    for i,u in enumerate(units[start:start+12]):
        example=u['examples'][0] if u['examples'] else {'page':u['page'],'top':u['top']+100,'bottom':u['top']+350}
        if page!=example['page']:
            page=example['page'];name=f'p{page:03}'
            meta=json.loads((TMP/'ja'/f'{name}-1.json').read_text(encoding='utf-8'))
            im=Image.new('RGB',(meta['width'],meta['fullHeight']),'white')
            im.paste(Image.open(TMP/'tiles'/f'{name}-0.png'),(0,0))
            im.paste(Image.open(TMP/'tiles'/f'{name}-1.png'),(0,meta['offsetY']))
        top=max(0,example['top']-40);bottom=max(example['bottom']+5,top+200)
        crop=im.crop((130,top,1820,bottom));crop.thumbnail((790,170))
        x=i%3*800;y=i//3*205
        draw.text((x+4,y+1),f"{u['lesson']}-{u['point']} {u['title']} p{page}",font=font,fill='black')
        canvas.paste(crop,(x+4,y+30))
    canvas.save(TMP/f'proof-main-{start//12}.png')
print(len(units),'units rendered')
