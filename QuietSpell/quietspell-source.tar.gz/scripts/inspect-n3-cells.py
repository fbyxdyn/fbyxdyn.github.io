import json
from pathlib import Path
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parents[1];TMP=ROOT/'tmp/pdfs'
cells=[]
for file in (TMP/'recognized-cells-v4').glob('*.json'):cells.extend(json.loads(file.read_text(encoding='utf-8')))
report=json.loads((ROOT/'output/n3-books/needs-review.json').read_text(encoding='utf-8'))
selected=[c for c in report if c['reason']=='word requires visual review']
for bid,nums in [(0,[1,3,20,28]),(1,[1,2])]:
    selected.extend(c for c in cells if c['book']==bid and c['number'] in nums)
selected.sort(key=lambda c:(c['book'],c['number']))
for batch in range(0,len(selected),18):
    canvas=Image.new('RGB',(1800,6*270),'#ddd');draw=ImageDraw.Draw(canvas)
    for i,c in enumerate(selected[batch:batch+18]):
        name=f"b{c['book']}-p{c['page']:03}"
        meta=json.loads((TMP/'ja'/f'{name}-1.json').read_text(encoding='utf-8'))
        im=Image.new('RGB',(meta['width'],meta['fullHeight']),'white')
        im.paste(Image.open(TMP/'tiles'/f'{name}-0.png'),(0,0));im.paste(Image.open(TMP/'tiles'/f'{name}-1.png'),(0,meta['offsetY']))
        b=c['wordBox'];top=c['readingBox'][1]-8;bottom=c['bottom'] if c['book']==0 else c['posY']+150
        crop=im.crop((b[0]-10,top,b[2],min(bottom,top+550)))
        crop.thumbnail((580,230))
        x=(i%3)*600;y=(i//3)*270
        draw.text((x+5,y+3),f"book {c['book']} page {c['page']} number {c['number']}",fill='black')
        canvas.paste(crop,(x+5,y+25))
    canvas.save(TMP/f'review-sheet-{batch//18}.png')
print(len(selected),'cells')
