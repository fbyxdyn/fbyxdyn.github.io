"""Verify the separately reviewed batch and its source/pronunciation contract."""
import hashlib
import json
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]


class KanzenBatch2Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base_path=ROOT/'app/core/japanese/books/n3-pdf-0.json'
        cls.base={e['id']:e for e in json.loads(cls.base_path.read_text(encoding='utf-8'))['entries']}
        cls.data=json.loads((ROOT/'output/n3-books/kanzen/batch2/source-examples.json').read_text(encoding='utf-8'))
        cls.entries={e['id']:e for e in cls.data['entries']}

    def test_exact_word_association_and_source_hash(self):
        self.assertEqual(self.data['sourceBookSha256'],hashlib.sha256(self.base_path.read_bytes()).hexdigest())
        numbers=json.loads((ROOT/'output/n3-books/kanzen/batch2-numbers.json').read_text(encoding='utf-8'))
        self.assertEqual(set(self.entries),{f'n3-0-{n}' for n in numbers})
        self.assertEqual(len(self.data['entries']),120)
        for key,e in self.entries.items():
            with self.subTest(id=key):
                self.assertEqual((e['text'],e['reading']),(self.base[key]['text'],self.base[key]['reading']))
                example=e['examples'][0]
                self.assertIn(e['text'],example['text'])
                self.assertRegex(example['reading'],r'^[ぁ-ゖー、。「」！？!?]+$')
                self.assertTrue(example['meaning'])

    def test_reviewed_numbers_counters_and_context(self):
        expected={2:'えーせんせい',25:'ふたつ',26:'みっか',85:'あずけた',
                  103:'きんのねっくれす',127:'さんかげつ',165:'びわこ',198:'ほいくしょ',
                  200:'あすはじゅうじ',210:'にしゅうかん',256:'いちまんえん',264:'ひゃくめーとる',
                  271:'ふいたら',272:'そのた',274:'さんたいいちでえーちーむ',291:'じゅうじ',
                  301:'ふたりぶん',302:'ふたり',305:'さんじゅうびょうごとにじゅうえん',322:'みっつ'}
        for n,part in expected.items():
            with self.subTest(number=n):self.assertIn(part,self.entries[f'n3-0-{n}']['examples'][0]['reading'])
        self.assertNotIn('ぬぐいたら',self.entries['n3-0-271']['examples'][0]['reading'])

    def test_no_overlap_with_first_reviewed_batch(self):
        original=ROOT/'output/n3-books/kanzen/source-examples.json'
        data=json.loads(original.read_text(encoding='utf-8'))
        self.assertFalse(set(self.entries)&{e['id'] for e in data['entries']})
        self.assertEqual(hashlib.sha256(original.read_bytes()).hexdigest(),
                         'a02d77d474b80e25ab5257533a6efca98f620ce871262f24e3996c7878b9d027')


if __name__=='__main__':unittest.main()
