"""Shared local OCR geometry helpers for the scanned Kanzen grammar book."""
import json
from pathlib import Path
import re
import unicodedata

ROOT=Path(__file__).resolve().parents[1]
TMP=ROOT/'tmp/pdfs/kanzen-grammar'


def compact(value):
    return re.sub(r'\s+','',unicodedata.normalize('NFKC',value))


def pages(language='ja',minimum_height=32):
    result={}
    for path in sorted((TMP/language).glob('p*.json')):
        data=json.loads(path.read_text(encoding='utf-8'))
        page=result.setdefault(data['page'],[])
        for line in data['lines']:
            words=line['words']
            if not words:continue
            main=[w for w in words if w['height']>=minimum_height]
            if not main:continue
            top=min(w['y'] for w in main)
            selected=[w for w in words if w['height']>=minimum_height-3 or w['y']>=top-7]
            if not selected:continue
            row={'text':compact(''.join(w['text'] for w in selected)),'raw':compact(line['text']),
                 'x':min(w['x'] for w in selected),'y':min(w['y'] for w in selected)+data['offsetY'],
                 'right':max(w['x']+w['width'] for w in selected),
                 'bottom':max(w['y']+w['height'] for w in selected)+data['offsetY'],
                 'h':max(w['height'] for w in selected)}
            old=next((r for r in page if abs(r['x']-row['x'])<12 and abs(r['y']-row['y'])<8),None)
            if old:
                if len(row['text'])>len(old['text']):page.remove(old)
                else:continue
            page.append(row)
    for rows in result.values():rows.sort(key=lambda r:(r['y'],r['x']))
    return result


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('page',type=int);p.add_argument('--language',default='ja');args=p.parse_args()
    for row in pages(args.language).get(args.page,[]):
        print(round(row['x']),round(row['y']),round(row['h']),row['text'])
