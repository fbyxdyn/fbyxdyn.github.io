"""Check the full-book handoff contract and regressions found during proofreading."""
import hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
book_path=ROOT/'app/core/japanese/books/n3-pdf-1.json'
detail_path=ROOT/'output/n3-books/n3-enrichment-preview.json'
book=json.loads(book_path.read_text(encoding='utf-8'))
details=json.loads(detail_path.read_text(encoding='utf-8'))
assert len(book['entries'])==2000
assert len({e['id'] for e in book['entries']})==2000
index={(e['text'],e['reading']):e for e in details}
assert len(index)==len(details),'Duplicate enrichment keys overwrite examples or senses.'
by_number={e['source']['number']:e for e in book['entries']}
for number,text,reading in [(5,'間','あいだ'),(1149,'開く','あく'),(1354,'開く','ひらく'),(1898,'パート','ぱーと'),(1981,'ハート','はーと'),(1990,'ビル','びる'),(2003,'スーツ','すーつ')]:
 e=by_number[number];assert (e['text'],e['reading'])==(text,reading),(number,e)
issues=[];coverage={k:0 for k in ['examples','multipleExamples','phrases','synonyms','similarSounds']}
for e in book['entries']:
 assert re.fullmatch('[ぁ-ゖー]+',e['reading']),(e['id'],e['reading'])
 d=index.get((e['text'],e['reading']));assert d,e['id']
 assert d.get('partOfSpeech') and d.get('senses') and d.get('detailsSource'),e['id']
 if not d.get('examples'):issues.append((e['id'],'missing examples'))
 for example in d.get('examples',[]):
  if not example.get('meaning') or not re.search('[一-鿿]',example['meaning']):issues.append((e['id'],'missing example translation',example))
  if not re.search('[ぁ-ヺ]',example.get('text','')) or re.search(r'[{}\[\]<>~]',example['text']):issues.append((e['id'],'unusable example',example))
  if not re.search('[ぁ-ゖァ-ヺ]',example.get('reading','')):issues.append((e['id'],'missing example reading',example))
 for field in ['phrases','synonyms','similarSounds']:
  for related in d.get(field,[]):
   if not all(related.get(k) for k in ['text','reading','meaning']):issues.append((e['id'],'incomplete '+field,related))
   if field in ['synonyms','similarSounds'] and not related.get('note'):issues.append((e['id'],'missing distinction '+field,related))
 for field in ['examples','phrases','synonyms','similarSounds']:
  if d.get(field):coverage[field]+=1
 if len(d.get('examples',[]))>1:coverage['multipleExamples']+=1
old=ROOT/'.cache/releases/quietspell-20261121-preview/app/core/japanese/books/n3-pdf-1.json'
if old.exists():
 previous=json.loads(old.read_text(encoding='utf-8'))
 assert {e['id'] for e in previous['entries']}<={e['id'] for e in book['entries']},'Existing progress IDs removed'
report={'coreEntries':2000,'enrichmentRecords':len(details),'coverage':coverage,'contractIssues':issues,'status':'passed' if not issues else 'failed','limitation':'OCR examples, translations and collocations have not all been manually proofread. This is a learning preview.'}
out=ROOT/'output/n3-books/core-handoff-validation.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
assert not issues,f'{len(issues)} contract issues'
from n3_similar_sounds import contrast
assert contrast('かみ','かみ')[0]==0
assert contrast('ぱーと','はーと')[0]==1
assert contrast('びる','びーる')[0]==1
assert contrast('おばさん','おばあさん')[0] in [1,2]
assert contrast('びょういん','びよういん')[0]==1
assert contrast('さくら','でんしゃ') is None
print('Vocabulary contracts, preserved IDs and listening-contrast regressions passed.')
