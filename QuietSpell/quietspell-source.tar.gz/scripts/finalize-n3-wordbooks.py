import argparse
import importlib.util
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--book',type=int,choices=[0,1,2,3]);args=parser.parse_args()
spec=importlib.util.spec_from_file_location('n3_source',ROOT/'scripts/build-n3-wordbooks.py')
source=importlib.util.module_from_spec(spec);spec.loader.exec_module(source)
from sudachipy import dictionary, tokenizer
TMP=ROOT/'tmp/pdfs';OUT=ROOT/'app/core/japanese/books';REPORT=ROOT/'output/n3-books'
cells=[]
for file in sorted((TMP/'recognized-cells-v4').glob('*.json')):cells.extend(json.loads(file.read_text(encoding='utf-8')))
corrections=json.loads((ROOT/'scripts/n3-proofreading-corrections.json').read_text(encoding='utf-8'))

def kana(value):return source.hiragana(re.sub('[^ぁ-ヿ]','',value))
def head(value):
    value=source.clean_head(value).split('/')[0].split('、')[0].split('・')[0].strip('_`.:;「」。！!?？-')
    value=re.sub(r'[（(].*','',value)
    return value

morphology=dictionary.Dictionary().create()
def lexical(value):
    if not value:return False
    tokens=morphology.tokenize(value,tokenizer.Tokenizer.SplitMode.C)
    return len(tokens)==1 and not tokens[0].is_oov()

def normalized_cell(cell):
    written=head(cell.get('word',''))
    reading=kana(cell.get('reading',''))
    if cell['book']==0 and written.endswith('する') and len(written)>2 and not reading.endswith('する'):written=written[:-2]
    return written,reading

books=[];review=[]
for bid in [0,1]:
    ja=source.read_ocr(bid,'ja');zh=source.read_ocr(bid,'zh-Hans-CN');entries=[];seen=set()
    isolated={}
    definition_dir=TMP/('proofread-definitions-v4' if bid==1 else 'proofread-definitions-v3')
    if not definition_dir.exists():definition_dir=TMP/'proofread-definitions-v3'
    for file in definition_dir.glob(f'b{bid}-*.json'):
        isolated.update(json.loads(file.read_text(encoding='utf-8')))
    for cell in [v for v in cells if v['book']==bid]:
        written,printed=normalized_cell(cell)
        ruby_box=cell['readingBox']
        source_readings=[line for line in ja.get(cell['page'],[]) if ruby_box[0]-20<line['x']<ruby_box[0]+150 and ruby_box[1]-8<line['y']<ruby_box[3] and re.fullmatch('[ぁ-ヿ]+',line['text']) and line['h']>23]
        if source_readings:
            source_readings.sort(key=lambda line:(line.get('score') or .90),reverse=True)
            printed=kana(source_readings[0]['text']);cell['readingScore']=max(cell.get('readingScore',0),source_readings[0].get('score') or .96)
        # Shortening unknown words to dictionary prefixes corrupts words such as アイデア.
        # Resolve uncertain spellings against the scanned page, using the correction ledger.
        expected=source.dictionary_reading(written) if written else ''
        # Dictionary spelling restores furigana that covers only the kanji part of an inflected word.
        if printed and source.loose_kana(expected).startswith(source.loose_kana(printed)):printed=expected
        bad_head=not written or bool(re.search('[^ぁ-ヿ一-鿿々ヶ]',written)) or (cell.get('wordScore',0)<.82 and not lexical(written))
        # A ruby fragment or a word with a similar reading is not evidence for a
        # replacement headword. Unknown cells require an explicit visual correction.
        correction=corrections['books'][str(bid)].get(str(cell['number']))
        if correction:
            written=correction['text'];printed=correction['reading'];expected=printed;bad_head=False
        if bad_head or not re.search('[ぁ-ヿ一-鿿]',written):
            review.append({**cell,'reason':'word requires visual review'});continue
        reading=expected
        # Ruby OCR can contain neighboring text or only the kanji prefix. Never turn
        # that fragment into the word itself. Verified alternative readings live in the ledger.
        box=cell['wordBox']
        meaning_top=cell['top']+213 if bid==0 else cell['posY']+45
        meaning_bottom=cell['bottom'] if bid==0 else cell['posY']+160
        meanings=[]
        for line in zh.get(cell['page'],[]):
            if not (box[0]-20<line['x']<box[0]+150 and meaning_top<line['y']<meaning_bottom and line['h']<52):continue
            value=line['text'].strip('，,、。·一ー-_')
            if source.HAN.search(value) and not re.search('[A-Za-zぁ-ヿ]',value):meanings.append(value)
        meaning='；'.join(dict.fromkeys(meanings)) or written
        candidates=isolated.get(str(cell['number']),[])
        if bid==0 and candidates:
            # The final blue text is the definition. Earlier rows may be the
            # Japanese headword. Join only adjacent lines of the same small font.
            last=candidates[-1];selected=[last]
            for previous in reversed(candidates[:-1]):
                if selected[0].get('top',0)-previous.get('top',0)>65 or previous.get('height',99)>53:break
                selected.insert(0,previous)
            candidates=selected
        recovered=[line['text'] for line in candidates if line['score']>=.75 and source.HAN.search(line['text']) and not re.search('[A-Za-zぁ-ヿ]',line['text'])]
        if recovered:meaning=''.join(recovered).strip('，,；;。·一ー-_')
        if correction:
            reading=correction['reading'];meaning=correction.get('meaning') or meaning
        number=cell['number']
        if (bid,number) in seen:continue
        seen.add((bid,number))
        item=source.make_entry(bid,cell['page'],number,written,reading,meaning,score=cell.get('wordScore'))
        if not item:continue
        entries.append(item)
        if cell.get('wordScore',0)<.94 or (cell.get('readingScore',0)<.8 and not source.HAN.search(written)):
            review.append({**cell,'chosenWord':written,'chosenReading':reading,'reason':'low recognition confidence'})
    entries.sort(key=lambda e:e['source']['number'])
    existing={e['source']['number'] for e in entries}
    for key,value in corrections['books'][str(bid)].items():
        if int(key) not in existing:
            item=source.make_entry(bid,value['page'],int(key),value['text'],value['reading'],value['meaning'])
            entries.append(item)
    entries.sort(key=lambda e:e['source']['number'])
    title=['新完全掌握 N3 · 高频词汇','新东方 N3 · 核心词汇'][bid]
    description='按原书顺序整理的 N3 词汇；保留来源页码，可对照原书学习。'
    if bid==1:description='扫描词书学习先行版，包含全书词目、例句和学习补充。原书 OCR 释义、例句与搭配仍待逐条精校，请结合来源页码核对。'
    books.append({'id':f'n3-pdf-{bid}','title':title,'description':description,'kind':'words','sourceType':'vocabulary','entries':entries})
    print(title,len(entries),flush=True)
books.extend([source.grammar_book(),source.listening_book()])
for book in books:
    if args.book is None or book['id']==f'n3-pdf-{args.book}':
        (OUT/f"{book['id']}.json").write_text(json.dumps(book,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(REPORT/'needs-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(REPORT/'recognition-report.json').write_text(json.dumps({'books':[{'id':b['id'],'title':b['title'],'entries':len(b['entries'])} for b in books],'reviewItems':len(review),'missingHighFrequencyNumbers':sorted(set(range(1,1801))-{e['source']['number'] for e in books[0]['entries']})},ensure_ascii=False,indent=2),encoding='utf-8')
