"""Build local-review details without rewriting the Kanzen source wordbook.

Only exact written-word + reading matches reuse published teaching material.
Missing examples stay missing. Listening contrasts use the shared conservative
comparator, excluding its looser rank-3 matches and any pitch-accent inference.
"""
import argparse
import copy
import hashlib
import json
import re
import unicodedata
from pathlib import Path

from n3_similar_sounds import build_similar_sounds, contrast

ROOT = Path(__file__).resolve().parents[1]
FIELDS = ('partOfSpeech', 'senses', 'examples', 'phrases', 'synonyms', 'usage')
KANA = re.compile(r'[ぁ-ゖァ-ヺー]+')


def stable_json(path):
    raw = path.read_bytes()
    data = json.loads(raw.decode('utf-8'))
    if raw != path.read_bytes():
        raise RuntimeError(f'Source changed during reading; rerun after saving: {path.name}')
    return data, hashlib.sha256(raw).hexdigest()


def source_examples_index(entries, payload):
    rows = payload.get('entries') if isinstance(payload, dict) else payload
    if not isinstance(rows, list):
        raise ValueError('Source examples must be an array or an object with an entries array.')
    by_id = {entry['id']: entry for entry in entries}
    seen_ids = set()
    result = {}
    for row in rows:
        if not isinstance(row, dict) or row.get('id') not in by_id:
            raise ValueError('Source example has an unknown entry ID.')
        entry = by_id[row['id']]
        if row['id'] in seen_ids:
            raise ValueError(f'Duplicate source-example ID: {row["id"]}')
        seen_ids.add(row['id'])
        if (row.get('text'), row.get('reading')) != (entry['text'], entry['reading']):
            raise ValueError(f'Source example word/reading mismatch: {row["id"]}')
        examples = row.get('examples')
        if not isinstance(examples, list):
            raise ValueError(f'Source example list is missing: {row["id"]}')
        for example in examples:
            if not isinstance(example, dict) or not all(isinstance(example.get(field), str) and example[field].strip() for field in ('text', 'reading', 'meaning')):
                raise ValueError(f'Incomplete source example: {row["id"]}')
            if any(len(example[field]) > 2000 for field in ('text', 'reading', 'meaning')):
                raise ValueError(f'Source example exceeds import limits: {row["id"]}')
        if examples:
            key = (entry['text'], entry['reading'])
            result.setdefault(key, []).extend(copy.deepcopy(examples))
    return result


def deduplicate_examples(examples):
    seen = set()
    result = []
    for example in examples:
        key = re.sub(r'\s+', '', unicodedata.normalize('NFKC', example['text']))
        if key not in seen:
            seen.add(key)
            result.append(example)
    return result


def build_details(entries, shared, source_examples=None):
    original_examples = source_examples_index(entries, source_examples) if source_examples is not None else {}
    shared_index = {}
    for item in shared:
        key = (item['text'], item['reading'])
        if key in shared_index:
            raise ValueError(f'Duplicate shared-detail key: {key}')
        shared_index[key] = item
    valid_entries = [e for e in entries if KANA.fullmatch(e['reading'])]
    neighbors = build_similar_sounds(valid_entries)
    records = {}
    shared_keys = set()
    for entry in entries:
        key = (entry['text'], entry['reading'])
        if key in records:
            continue
        record = {'text': key[0], 'reading': key[1]}
        sources = []
        original = shared_index.get(key)
        if original:
            for field in FIELDS:
                if original.get(field):
                    record[field] = copy.deepcopy(original[field])
            if any(record.get(field) for field in FIELDS):
                shared_keys.add(key)
                sources.append('复用已发布新东方 N3 的相同字形及读音词条；' + original.get('detailsSource', '已有学习补充'))
        if key in original_examples:
            record['examples'] = deduplicate_examples([*original_examples[key], *record.get('examples', [])])
            sources.append('包含新完全掌握 N3 原书 OCR 例句，按条目 ID、字形及读音核验；仍待逐句校对。')
        matches = []
        for candidate in neighbors.get(key, []):
            match = contrast(entry['reading'], candidate['reading'])
            if not match or match[0] > 2:
                continue
            item = copy.deepcopy(candidate)
            if match[0] == 0:
                item['note'] += '此处未判断音调。'
            matches.append(item)
        if matches:
            record['similarSounds'] = matches
            sources.append('近音对照来自当前新完全词表及基础对照组；按假名音拍保守筛选，未判断音调。')
        if len(record) > 2:
            record['detailsSource'] = ' '.join(sources)
            records[key] = record
    coverage = {
        field: sum(bool(records.get((e['text'], e['reading']), {}).get(field)) for e in entries)
        for field in ('partOfSpeech', 'senses', 'examples', 'phrases', 'synonyms', 'similarSounds', 'usage')
    }
    missing = [
        {'id': e['id'], 'text': e['text'], 'reading': e['reading'], 'page': e.get('source', {}).get('page')}
        for e in entries if not records.get((e['text'], e['reading']), {}).get('examples')
    ]
    report = {
        'stage': 'local-review-only; rebuild after source proofreading',
        'sourceEntries': len(entries), 'uniqueSourceKeys': len({(e['text'], e['reading']) for e in entries}),
        'supplementRecords': len(records), 'sharedPublishedKeys': len(shared_keys),
        'sourceExampleKeys': len(original_examples),
        'sourceExampleEntries': sum((e['text'], e['reading']) in original_examples for e in entries),
        'coverageBySourceEntry': coverage, 'missingExampleEntries': len(missing),
        'invalidKanaEntries': [e['id'] for e in entries if not KANA.fullmatch(e['reading'])],
        'policy': 'Exact text+reading reuse only; no invented filler examples; no rank-3 or pitch-accent matches.',
    }
    return list(records.values()), report, missing


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-book', type=Path, default=ROOT / 'app/core/japanese/books/n3-pdf-0.json')
    parser.add_argument('--shared-details', type=Path, default=ROOT / 'app/core/japanese/books/n3-enrichment.json')
    parser.add_argument('--expected-shared-sha256')
    parser.add_argument('--source-examples', type=Path, help='Approved source-examples input; omitted until OCR extraction is handed off.')
    parser.add_argument('--output', type=Path, default=ROOT / 'app/core/japanese/books/n3-kanzen-enrichment.json')
    parser.add_argument('--report-dir', type=Path, default=ROOT / 'output/n3-books/kanzen')
    args = parser.parse_args()
    book, source_sha = stable_json(args.source_book)
    shared, shared_sha = stable_json(args.shared_details)
    if args.expected_shared_sha256 and shared_sha != args.expected_shared_sha256:
        raise RuntimeError('The shared details do not match the approved published snapshot.')
    source_examples = None
    source_examples_sha = None
    if args.source_examples:
        source_examples, source_examples_sha = stable_json(args.source_examples)
        if isinstance(source_examples, dict) and source_examples.get('sourceBookSha256') not in (None, source_sha):
            raise RuntimeError('Source examples belong to a different source-book snapshot.')
    records, report, missing = build_details(book['entries'], shared, source_examples)
    report['sourceBookSha256'] = source_sha
    report['sharedDetailsSha256'] = shared_sha
    report['sourceExamplesSha256'] = source_examples_sha
    report['bookId'] = book['id']
    write_json(args.output, records)
    report['supplementSha256'] = hashlib.sha256(args.output.read_bytes()).hexdigest()
    write_json(args.report_dir / 'enrichment-report.json', report)
    write_json(args.report_dir / 'missing-examples.json', missing)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
