import copy
import importlib.util
import sys
import unittest
from pathlib import Path

scripts = Path(__file__).resolve().parent
sys.path.insert(0, str(scripts))
spec = importlib.util.spec_from_file_location('kanzen_details', scripts / 'build-n3-kanzen-enrichment.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)


class KanzenDetailsTests(unittest.TestCase):
    def test_exact_readings_only_and_no_source_mutation_or_filler(self):
        entries = [
            {'id': 'a', 'text': '開く', 'reading': 'あく', 'meaning': '打开'},
            {'id': 'b', 'text': '開く', 'reading': 'ひらく', 'meaning': '打开；召开'},
            {'id': 'c', 'text': '不存在', 'reading': 'ふそんざい', 'meaning': '测试'},
        ]
        shared = [{'text': '開く', 'reading': 'あく', 'senses': [{'meaning': '打开'}], 'examples': [{'text': 'ドアが開きます。', 'reading': 'どあがあきます。', 'meaning': '门打开。'}], 'detailsSource': '原书 OCR 先行稿'}]
        original_entries, original_shared = copy.deepcopy(entries), copy.deepcopy(shared)
        records, report, missing = builder.build_details(entries, shared)
        index = {(x['text'], x['reading']): x for x in records}
        self.assertTrue(index['開く', 'あく']['examples'])
        self.assertFalse(index.get(('開く', 'ひらく'), {}).get('examples'))
        self.assertFalse(index.get(('不存在', 'ふそんざい'), {}).get('examples'))
        self.assertEqual(report['missingExampleEntries'], 2)
        self.assertEqual({x['id'] for x in missing}, {'b', 'c'})
        self.assertEqual(entries, original_entries)
        self.assertEqual(shared, original_shared)

    def test_only_conservative_sound_contrasts_and_unique_keys(self):
        entries = [
            {'id': str(i), 'text': word, 'reading': reading, 'meaning': word}
            for i, (word, reading) in enumerate([('紙', 'かみ'), ('髪', 'かみ'), ('ビル', 'びる'), ('ビール', 'びーる'), ('テスト', 'てすと'), ('ベスト', 'べすと'), ('紙', 'かみ')])
        ]
        records, report, _ = builder.build_details(entries, [])
        self.assertEqual(len({(x['text'], x['reading']) for x in records}), len(records))
        for item in records:
            for candidate in item.get('similarSounds', []):
                self.assertLessEqual(builder.contrast(item['reading'], candidate['reading'])[0], 2)
                self.assertTrue(candidate['note'])
                if item['reading'] == candidate['reading']:
                    self.assertIn('未判断音调', candidate['note'])
        self.assertEqual(report['sourceEntries'], 7)
        self.assertEqual(report['uniqueSourceKeys'], 6)

    def test_original_examples_are_id_and_reading_checked_and_deduplicated(self):
        entries = [{'id': 'a', 'text': '学校', 'reading': 'がっこう', 'meaning': '学校'}, {'id': 'b', 'text': '学校', 'reading': 'がっこう', 'meaning': '学校（重复原条目）'}]
        example = {'text': '学校に行きます。', 'reading': 'がっこうにいきます。', 'meaning': '去学校。'}
        shared = [{'text': '学校', 'reading': 'がっこう', 'examples': [example], 'detailsSource': '已有教学例句'}]
        payload = {'entries': [{'id': 'a', 'text': '学校', 'reading': 'がっこう', 'examples': [example]}]}
        original = copy.deepcopy(payload)
        records, report, missing = builder.build_details(entries, shared, payload)
        self.assertEqual(len(records[0]['examples']), 1)
        self.assertEqual(report['sourceExampleEntries'], 2)
        self.assertEqual(missing, [])
        self.assertIn('新完全掌握 N3 原书 OCR', records[0]['detailsSource'])
        self.assertEqual(payload, original)
        bad = copy.deepcopy(payload)
        bad['entries'][0]['reading'] = 'がこう'
        with self.assertRaisesRegex(ValueError, 'mismatch'):
            builder.build_details(entries, shared, bad)
        bad['entries'][0]['reading'] = 'がっこう'
        bad['entries'][0]['id'] = 'unknown'
        with self.assertRaisesRegex(ValueError, 'unknown'):
            builder.build_details(entries, shared, bad)

    def test_source_examples_do_not_accept_missing_translations(self):
        entries = [{'id': 'a', 'text': '学校', 'reading': 'がっこう', 'meaning': '学校'}]
        payload = [{'id': 'a', 'text': '学校', 'reading': 'がっこう', 'examples': [{'text': '学校に行きます。', 'reading': 'がっこうにいきます。', 'meaning': ''}]}]
        with self.assertRaisesRegex(ValueError, 'Incomplete'):
            builder.build_details(entries, [], payload)


if __name__ == '__main__':
    unittest.main()
