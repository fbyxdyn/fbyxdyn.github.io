"""Use printed entry grids to recover single-character headwords skipped by line OCR."""
import json
from pathlib import Path
import re
import statistics

ROOT=Path(__file__).resolve().parents[1];TMP=ROOT/'tmp/pdfs'

def lines_for(book,page):
    result=[]
    for lang in ['ja','zh-Hans-CN']:
        for tile in [0,1]:
            d=json.loads((TMP/lang/f'b{book}-p{page:03}-{tile}.json').read_text(encoding='utf-8'))
            for line in d['lines']:
                ws=line['words'];text=re.sub(r'\s+','',line['text'])
                result.append({'text':text,'x':min(w['x'] for w in ws),'y':min(w['y'] for w in ws)+d['offsetY'],'h':max(w['height'] for w in ws),'width':d['width'],'height':d['fullHeight'],'lang':lang})
    return result

cells=[]
for page in range(9,245):
    lines=lines_for(0,page);width=lines[0]['width'];height=lines[0]['height']
    anchors=[]
    for l in lines:
        candidate=l['text'].strip('□■ロ口[]（）()').translate(str.maketrans('OoODIl|ZSBgq','000011125899'))
        if re.fullmatch(r'\d{4}',candidate) and width*.065<l['x']<width*.95 and 22<l['h']<41 and l['y']>180:
            number=int(candidate[-4:])
            if 0<number<=1800 and not any(abs(l['y']-a['y'])<15 and abs(l['x']-a['x'])<30 for a in anchors):anchors.append({**l,'number':number})
    if not anchors:continue
    anchors.sort(key=lambda a:(round(a['y']/20),a['x']))
    for anchor in anchors:
        row=sorted([a for a in anchors if abs(a['y']-anchor['y'])<20],key=lambda a:a['x'])
        rowindex=row.index(anchor)
        left=anchor['x']-75
        right=min(width*.95, anchor['x']+470)
        if len(row)>1:
            if rowindex+1<len(row):right=row[rowindex+1]['x']-80
            else:right=min(width*.95,anchor['x']+(row[-1]['x']-row[-2]['x'])-80)
        top=anchor['y']
        lower=[a['y'] for a in anchors if a['y']>top+25]
        bottom=min(lower) if lower else min(height-50,top+389)
        cells.append({'book':0,'page':page,'number':anchor['number'],'top':top,'bottom':bottom,'wordBox':[left,top+125,right,top+218],'readingBox':[left,top+48,right,top+125]})

for page in range(18,306):
    lines=lines_for(1,page);width=lines[0]['width'];height=lines[0]['height']
    anchors=[]
    for l in lines:
        t=l['text']
        if l['lang']=='ja' and l['x']<width*.37 and l['h']<46 and l['y']>250 and re.search('[a-zA-Z]{2}',t) and not t.startswith(('(','（')):
            if not any(abs(l['y']-a['y'])<20 for a in anchors):anchors.append(l)
    if len(anchors)<2:continue
    # Romanization lines occur once per entry on a seven-row grid.
    anchors.sort(key=lambda a:a['y']);step=341
    phases=[a['y']-round((a['y']-470)/step)*step for a in anchors]
    base=statistics.median(phases)
    x_candidates=[l['x'] for l in lines if l['lang']=='ja' and width*.09<l['x']<width*.19 and re.search('[ぁ-ヿ一-鿿]',l['text']) and l['h']>24]
    x=statistics.median(x_candidates) if x_candidates else width*.13
    for index in range(7):
        pos=base+index*step
        if pos>height-100:break
        is_katakana=page>=282
        wordtop=pos-(185 if is_katakana else 132)
        wordbottom=pos-(92 if is_katakana else 40)
        cells.append({'book':1,'page':page,'number':len([c for c in cells if c['book']==1])+1,'top':pos-185,'bottom':min(height-55,pos+160),'posY':pos,'wordBox':[x-16,wordtop,width*.385,wordbottom],'readingBox':[x-16,pos-187,width*.385,pos-128]})

(TMP/'cells.json').write_text(json.dumps(cells,ensure_ascii=False),encoding='utf-8')
for bid in [0,1]:print('Prepared book',bid,sum(c['book']==bid for c in cells),'word cells',flush=True)
