"""Create a compact review queue without changing vocabulary data."""
import collections
import importlib.util
import json
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('n3_source',ROOT/'scripts/build-n3-wordbooks.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
from sudachipy import dictionary,tokenizer
m=dictionary.Dictionary().create()
cells=[]
for f in (ROOT/'tmp/pdfs/recognized-cells-v4').glob('*.json'):cells.extend(json.loads(f.read_text(encoding='utf-8')))
index={(c['book'],c['number']):c for c in cells}
review=[];summary=[]
for bid in [0,1]:
 b=json.loads((ROOT/f'app/core/japanese/books/n3-pdf-{bid}.json').read_text(encoding='utf-8'))
 known={e['source']['number']:e for e in b['entries']}
 for c in sorted((c for c in cells if c['book']==bid),key=lambda c:c['number']):
  e=known.get(c['number']);reasons=[]
  if not e: reasons.append('missing')
  else:
   ts=m.tokenize(e['text'],tokenizer.Tokenizer.SplitMode.C)
   if any(t.is_oov() for t in ts): reasons.append('unknown-spelling')
   if e['meaning']==e['text']:reasons.append('no-meaning')
   raw=s.clean_head(c.get('word','')).split('/')[0]
   if e['text']!=raw:reasons.append('changed-head')
   if not re.fullmatch('[ぁ-ゖー]+',e['reading']):reasons.append('bad-reading')
  if reasons:
   review.append({'book':bid,'number':c['number'],'page':c['page'],'rawWord':c.get('word',''),'rawReading':c.get('reading',''),'chosen':e,'reasons':reasons,'cell':c})
 summary.append({'book':bid,'entries':len(b['entries']),'issues':dict(collections.Counter(r for x in review if x['book']==bid for r in x['reasons']))})
(ROOT/'output/n3-books/proofreading-queue.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
for x in review:
 if any(r in x['reasons'] for r in ['missing','unknown-spelling','bad-reading']):
  e=x['chosen'] or {};print(f"{x['book']}:{x['number']} p{x['page']} raw={x['rawWord']} ruby={x['rawReading']} -> {e.get('text','MISSING')} [{e.get('reading','')}] {e.get('meaning','')} {'/'.join(x['reasons'])}")
