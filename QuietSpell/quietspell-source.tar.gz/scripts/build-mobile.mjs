import { spawnSync } from 'node:child_process'
import { cp, mkdir, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const built = spawnSync(
  process.execPath,
  [path.join(root, 'node_modules/vite/bin/vite.js'), 'build', '--config', 'mobile/vite.config.ts'],
  { cwd: root, stdio: 'inherit' }
)
if (built.status !== 0) process.exit(built.status ?? 1)
const target = path.join(root, 'mobile/QuietSpell/hybrid/html')
await writeFile(
  path.join(target, 'index.html'),
  '<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>QuietSpell</title><link rel="stylesheet" href="./quietspell.css"><script defer src="./quietspell.js"></script></head><body><div id="app"></div></body></html>'
)
await mkdir(path.join(target, 'audio/japanese'), { recursive: true })
await cp(path.join(root, 'public/audio/japanese'), path.join(target, 'audio/japanese'), {
  recursive: true,
})
await cp(path.join(root, 'public/templates'), path.join(target, 'templates'), { recursive: true })
console.log('QuietSpell offline study resources ready for HBuilderX.')
