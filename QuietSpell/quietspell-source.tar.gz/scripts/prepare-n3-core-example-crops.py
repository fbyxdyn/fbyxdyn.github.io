import argparse,collections,importlib.util,json
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];TMP=ROOT/'tmp/pdfs'
spec=importlib.util.spec_from_file_location('s',ROOT/'scripts/build-n3-wordbooks.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
ja=s.read_ocr(1,'ja');zh=s.read_ocr(1,'zh-Hans-CN')
p=argparse.ArgumentParser();p.add_argument('--all-details',action='store_true');args=p.parse_args()
missing={r['number'] for r in json.loads((ROOT/'output/n3-books/core-enrichment-review.json').read_text(encoding='utf-8')) if r['field']=='examples'}
if args.all_details:missing={e['source']['number'] for e in json.loads((ROOT/'app/core/japanese/books/n3-pdf-1.json').read_text(encoding='utf-8'))['entries']}
out=TMP/('core-detail-crops' if args.all_details else 'core-example-crops');out.mkdir(exist_ok=True)
jobs={'ja':[],'zh-Hans-CN':[]}
for f in sorted((TMP/'recognized-cells-v4').glob('b1-*.json')):
 cells=[c for c in json.loads(f.read_text(encoding='utf-8')) if c['number'] in missing]
 if not cells:continue
 page=cells[0]['page'];name=f'b1-p{page:03}'
 meta=json.loads((TMP/'ja'/f'{name}-1.json').read_text(encoding='utf-8'))
 image=Image.new('RGB',(meta['width'],meta['fullHeight']),'white');image.paste(Image.open(TMP/'tiles'/f'{name}-0.png'),(0,0));image.paste(Image.open(TMP/'tiles'/f'{name}-1.png'),(0,meta['offsetY']))
 starts=sorted(l['x'] for l in [*ja[page],*zh[page]] if 570<l['x']<850 and l['right']>1000 and 27<l['h']<53)
 left=int(starts[0])-8 if starts else 640
 for c in cells:
  top=int(c['posY']-230);bottom=int(c['posY']+(185 if args.all_details else 30))
  crop=np.array(image.crop((left,top,1740,bottom)).convert('L'));crop=np.where(crop<180,crop,255).astype('uint8')
  crop=Image.fromarray(crop).convert('RGB');crop=crop.resize((crop.width*2,crop.height*2))
  path=out/f"n{c['number']:04}.png";crop.save(path)
  for lang in jobs:
   folder=out/lang;folder.mkdir(exist_ok=True)
   jobs[lang].append({'book':1,'page':page,'image':str(path),'output':str(folder/f"n{c['number']:04}.json"),'offsetY':0,'fullHeight':crop.height})
for lang,items in jobs.items():(out/f'jobs-{lang}.json').write_text(json.dumps(items,ensure_ascii=False),encoding='utf-8')
print(len(missing),'isolated example crops',flush=True)
