"""Prepare the full core book preview from the provided OCR, with explicit provenance.

Unusable sentences are reported, never replaced with generic invented examples.
"""
import argparse,collections,importlib.util,json,re,unicodedata,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];TMP=ROOT/'tmp/pdfs'
spec=importlib.util.spec_from_file_location('n3_source',ROOT/'scripts/build-n3-wordbooks.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
from sudachipy import dictionary,tokenizer
from n3_similar_sounds import build_similar_sounds
morph=dictionary.Dictionary().create()
parser=argparse.ArgumentParser();parser.add_argument('--apply',action='store_true');parser.add_argument('--debug',type=int);args=parser.parse_args()
book=json.loads((ROOT/'app/core/japanese/books/n3-pdf-1.json').read_text(encoding='utf-8'))
sound_neighbors=build_similar_sounds(book['entries'])
manual=json.loads((ROOT/'app/core/japanese/books/n3-enrichment.json').read_text(encoding='utf-8'))
# Keep curated teaching material in an independent, stable input file.
seed=ROOT/'scripts/n3-enrichment-teaching.json'
if not seed.exists():seed.write_text(json.dumps(manual,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
manual=json.loads(seed.read_text(encoding='utf-8'))
manual_index={(e['text'],e['reading']):e for e in manual}
authored=collections.defaultdict(list)
for line in (ROOT/'scripts/n3-core-authored-examples.txt').read_text(encoding='utf-8').splitlines():
 if not line.strip():continue
 number,text,meaning=line.split('|',2);authored[int(number)].append({'text':text,'meaning':meaning})
ja=s.read_ocr(1,'ja');zh=s.read_ocr(1,'zh-Hans-CN')
cells={}
for f in (TMP/'recognized-cells-v4').glob('b1-*.json'):
 for c in json.loads(f.read_text(encoding='utf-8')):cells[c['number']]=c
refined={}
for f in (TMP/'n3-core-details-lines-v2').glob('*.json'):
 d=json.loads(f.read_text(encoding='utf-8'));refined[d['page']]=d['rows']
right_edges={}
for page in ja:
 starts=sorted(l['x'] for l in [*ja[page],*zh[page]] if 570<l['x']<850 and l['right']>1000 and 27<l['h']<53)
 right_edges[page]=starts[0] if starts else 680

def normalize(text):
 text=unicodedata.normalize('NFKC',text)
 return re.sub(r'\s+','',text).replace('ニ人','二人').replace('テ二ス','テニス').strip('_`')
def contains_kana(t):return bool(re.search('[ぁ-ゖァ-ヺ]',t))
def sentence_reading(text,entry=None):
 pieces=[]
 for token in morph.tokenize(text,tokenizer.Tokenizer.SplitMode.C):
  written=token.surface()
  value=entry['reading'] if entry and written==entry['text'] else s.hiragana(token.reading_form())
  pieces.append(value)
 reading=''.join(pieces)
 if '一目で' in text:reading=reading.replace('いちもくで','ひとめで')
 return reading
def jp_sentence(t):
 dialogue='」' in t or (t.count('"')>=2)
 t=normalize(t)
 if '/' in t:
  t=t.split('/',1)[0]
  if contains_kana(t) and not re.search('[。！？!?]$',t):t+='。'
 end=re.search('[。！？!?]',t)
 if end:t=t[:end.end()]
 t=t.strip(' /／-_:;')
 if t.endswith('.'):t=t[:-1]+'。'
 if t.count('「')>t.count('」'):t+='」'
 if not 4<=len(t)<=180 or not contains_kana(t):return ''
 if re.search(r'[{}\[\]<>~()（）]',t):return ''
 if len(re.findall('[ぁ-ヺ]',t))/len(t)<.13:return ''
 if re.search('[这们请从对为并个尓么]',t):return ''
 if not re.search('[。！？!?]$',t) and not dialogue:return ''
 return t
def pos_for(entry,c):
 lines=[l for l in ja[c['page']] if 200<l['x']<650 and abs(l['y']-c['posY'])<35 and 27<l['h']<48]
 raw=''.join(l['text'] for l in lines)
 labels=[]
 if '名' in raw:labels.append('名词')
 if 'イ形' in raw:labels.append('い形容词')
 if 'ナ形' in raw:labels.append('な形容词')
 if '副' in raw:labels.append('副词')
 if '接続' in raw:labels.append('接续词')
 if '連体' in raw:labels.append('连体词')
 if re.search('(?:自|他)[五一サ]',raw):labels.append('动词')
 if labels:return '・'.join(dict.fromkeys(labels))
 tokens=morph.tokenize(entry['text'],tokenizer.Tokenizer.SplitMode.C)
 if len(tokens)==1:
  first=tokens[0].part_of_speech()[0]
  return {'名詞':'名词','動詞':'动词','形容詞':'い形容词','形状詞':'な形容词','副詞':'副词','接続詞':'接续词','感動詞':'感叹词','連体詞':'连体词'}.get(first,'表达')
 return '短语・表达'
def meaning_text(text):
 text=normalize(text)
 if '/' in text:text=text.split('/')[-1]
 text=text.strip('，,。/／「」')
 return text if s.HAN.search(text) and not contains_kana(text) else ''

def cropped_rows(entry,language):
 n=entry['source']['number'];c=cells[n];page=c['page'];top=int(c['posY']-230)
 left=int(right_edges[page])-8
 for folder in ['core-detail-crops','core-example-crops']:
  path=TMP/folder/language/f'n{n:04}.json'
  if not path.exists():continue
  data=json.loads(path.read_text(encoding='utf-8'));rows=[]
  for line in data['lines']:
   if not line['words'] or max(w['height'] for w in line['words'])<50:continue
   main_top=min(w['y'] for w in line['words'] if w['height']>=50)
   # Long vowels, 一 and punctuation have small bounding-box heights. They still
   # belong to the main baseline and must not be mistaken for tiny furigana.
   words=[w for w in line['words'] if (w['height']>=41 or w['y']>=main_top-8) and not (w['height']>=85 and .72<w['width']/w['height']<1.35)]
   if not words:continue
   rows.append({'text':''.join(w['text'] for w in words),'raw':line['text'],'x':left+min(w['x'] for w in words)/2,'right':left+max(w['x']+w['width'] for w in words)/2,'y':top+min(w['y'] for w in words)/2,'h':max(w['height'] for w in words)/2})
  if rows:return sorted(rows,key=lambda r:r['y'])
 return []

details=[];issues=[];stats=collections.Counter()
for entry in book['entries']:
 n=entry['source']['number'];c=cells[n];page=c['page'];pos=c['posY'];edge=right_edges[page]-20
 page_ja=cropped_rows(entry,'ja') or ja[page]
 page_zh=cropped_rows(entry,'zh-Hans-CN') or zh[page]
 item={'text':entry['text'],'reading':entry['reading'],'partOfSpeech':pos_for(entry,c),'senses':[{'meaning':entry['meaning']}],
       'detailsSource':f'新东方 N3 原书 PDF 第 {page} 页学习资料整理（OCR 先行稿，例句和搭配尚需逐条复核）。'}
 if (entry['text'],entry['reading']) in sound_neighbors:item['similarSounds']=sound_neighbors[(entry['text'],entry['reading'])]
 rows=[l for l in page_ja if l['x']>edge and pos-230<l['y']<pos-15 and l['h']>=27]
 rows.sort(key=lambda l:l['y'])
 if args.debug==n:print('DEBUG',n,pos,edge,'rows',rows,flush=True)
 examples=[];parts=[];last_y=None
 for row in rows:
  raw=row['text']
  better=next((r for r in refined.get(page,[]) if abs(r['top']-row['y'])<15 and r['japan']['score']>=.93),None)
  if better and not (entry['text'] in normalize(raw)):
   attempt=jp_sentence(better['japan']['text'])
   if attempt and entry['text'] in attempt:raw=better['japan']['text']
  text=normalize(raw)
  if not contains_kana(text):continue
  # Do not append a Chinese translation that happens to contain one OCR kana.
  if re.search('[这们请从对为并]',text):
   parts=[];continue
  if last_y is not None and row['y']-last_y<12:continue
  if parts and row['y']-last_y>80:parts=[]
  parts.append(text);last_y=row['y']
  sentence=jp_sentence(''.join(parts))
  if args.debug==n:print('CANDIDATE',text,parts,sentence,flush=True)
  if not sentence:continue
  if re.fullmatch('[ァ-ヺー]+',entry['text']) and entry['text'] not in sentence:
   length=len(entry['text'])
   for start in range(len(sentence)-length+1):
    segment=sentence[start:start+length]
    if s.loose_kana(segment)==s.loose_kana(entry['text']):
     sentence=sentence[:start]+entry['text']+sentence[start+length:];break
  stem=entry['text'][:-1] if len(entry['text'])>1 and entry['text'][-1] in 'るいすくぐむぶぬつう' else entry['text']
  if entry['text'] not in sentence and stem not in sentence:
   reading=s.dictionary_reading(sentence)
   reading_stem=entry['reading'][:-1] if entry['text'][-1:] in 'るいすくぐむぶぬつう' and len(entry['reading'])>2 else entry['reading']
   if entry['reading'] not in reading and reading_stem not in reading:
    parts=[];continue
  translation=''
  # Inline bilingual examples put the Chinese translation after a slash.
  same=[l for l in page_zh if l['x']>edge and abs(l['y']-row['y'])<16 and l['h']>=27]
  for line in same:
   if re.search('[/／]',line['text']):translation=meaning_text(re.split('[/／]',line['text'])[-1]);break
  if not translation:
   cn=[l for l in page_zh if l['x']>edge and row['y']+22<l['y']<pos+20 and 27<=l['h']<48]
   translation=''.join(filter(None,(meaning_text(l['text']) for l in sorted(cn,key=lambda l:l['y']))))
  if not translation:issues.append({'number':n,'field':'example.meaning','page':page,'sentence':sentence})
  example={'text':sentence,'reading':sentence_reading(sentence,entry),'meaning':translation}
  if example['text'] not in [e['text'] for e in examples]:examples.append(example)
  parts=[]
 if examples:item['examples']=examples
 else:issues.append({'number':n,'field':'examples','page':page,'word':entry['text']})
 phrases=[];synonyms=[]
 lower=[l for l in page_ja if l['x']>edge and pos+5<l['y']<pos+185 and l['h']>=28]
 for row in lower:
  text=normalize(row['text'])
  cn_row=next((l for l in page_zh if abs(l['y']-row['y'])<18 and l['x']>edge),None)
  translations=re.findall(r'\(([^()]*)\)',normalize(cn_row['text'])) if cn_row else []
  for index,match in enumerate(re.finditer(r'([^()]{1,90}?)\(([^()]*)\)',text)):
   written,meaning=match.groups();written=written.strip('0〇○•・、:，,')
   if not written or re.search(r'[A-Za-z{}<>「」『』/／()\[\]〔〕]',written):continue
   if entry['text'] not in written:continue
   if len(written)>45:continue
   if index<len(translations) and s.HAN.search(translations[index]):meaning=translations[index]
   if not s.HAN.search(meaning) or contains_kana(meaning):continue
   related={'text':written,'reading':sentence_reading(written,entry),'meaning':meaning,'note':'原书例句旁的搭配或复合表达（OCR 先行稿）。'}
   phrases.append(related)
 if phrases:item['phrases']=list({p['text']:p for p in phrases}.values())
 curated=manual_index.get((entry['text'],entry['reading']))
 if curated:
  for field in ['partOfSpeech','senses','phrases','synonyms','usage']: 
   if field in curated:item[field]=curated[field]
  combined=[*curated.get('examples',[]),*item.get('examples',[])]
  item['examples']=list({e['text']:e for e in combined}.values())
  item['detailsSource']=curated['detailsSource']+f' 另含原书 PDF 第 {page} 页 OCR 例句（待复核）。'
 if authored.get(n):
  new=[{**example,'reading':sentence_reading(example['text'],entry)} for example in authored[n]]
  item['examples']=list({e['text']:e for e in [*new,*item.get('examples',[])]}.values())
  item['detailsSource']+=' 例句含学习补充（自编例句），并非原书原句。'
 if item.get('examples'):
  issues=[issue for issue in issues if not (issue['number']==n and issue['field']=='examples')]
 details.append(item)
 for field in ['partOfSpeech','senses','examples','phrases','synonyms','usage','similarSounds']:
  if item.get(field):stats[field]+=1
 if n%200==0:print(f'Core enrichment {n}/2009',flush=True)
keys={(e['text'],e['reading']) for e in details}
details.extend(e for e in manual if (e['text'],e['reading']) not in keys)
merged={}
for item in details:
 key=(item['text'],item['reading'])
 if key not in merged:merged[key]=item;continue
 previous=merged[key]
 for field in ['examples','phrases','synonyms','similarSounds','senses']:
  values=[*previous.get(field,[]),*item.get(field,[])]
  if values:
   def identity(value):return value.get('text') or ','.join(sorted(re.split('[，,；;]',value.get('meaning',''))))
   previous[field]=list({identity(value):value for value in values}.values())
 if item['detailsSource'] not in previous['detailsSource']:previous['detailsSource']+=' '+item['detailsSource']
details=list(merged.values())
out=ROOT/'output/n3-books';out.mkdir(parents=True,exist_ok=True)
(out/'n3-enrichment-preview.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'core-enrichment-review.json').write_text(json.dumps(issues,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report={'coreWords':len(book['entries']),'uniqueMergeKeys':len(keys),'coverage':dict(stats),'reviewItems':len(issues),'refinedPages':len(refined),'totalPages':288,'stage':'OCR preview; not a fully proofread edition'}
(out/'core-enrichment-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if args.apply:(ROOT/'app/core/japanese/books/n3-enrichment.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False),flush=True)
