"""Offline Open JTalk MP3 generation; activate only after full verification."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
CACHED_TOOLS = ROOT / '.cache/japanese-audio-tools'
if CACHED_TOOLS.exists():
    sys.path.insert(0, str(CACHED_TOOLS))
import lameenc
import numpy as np
import pyopenjtalk

OUTPUT = ROOT / 'public/audio/japanese'


def generate(recording):
    destination = OUTPUT / recording['file']
    if destination.exists() and destination.stat().st_size > 1000:
        return False
    samples, sample_rate = pyopenjtalk.tts(recording.get('speechText') or recording['text'], speed=0.9)
    if not len(samples) or np.max(np.abs(samples)) < 1:
        raise RuntimeError('Empty recording: ' + recording['text'])
    pcm = np.clip(samples, -32768, 32767).astype('<i2').tobytes()
    encoder = lameenc.Encoder()
    encoder.set_bit_rate(64)
    encoder.set_in_sample_rate(sample_rate)
    encoder.set_channels(1)
    encoder.set_quality(2)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix('.mp3.tmp')
    temporary.write_bytes(encoder.encode(pcm) + encoder.flush())
    if temporary.stat().st_size <= 1000:
        raise RuntimeError('Recording too short: ' + recording['text'])
    temporary.replace(destination)
    return True


def write_atomic(path, data):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers', type=int, default=min(4, max(1, (os.cpu_count() or 2) // 2)))
    args = parser.parse_args()
    plan = ROOT / 'output/audio/japanese'
    recordings = json.loads((plan / 'recordings.json').read_text(encoding='utf-8'))
    manifest = json.loads((plan / 'manifest.json').read_text(encoding='utf-8'))
    pending = [item for item in recordings if not (OUTPUT / item['file']).exists() or (OUTPUT / item['file']).stat().st_size <= 1000]
    print(f'{len(pending)} pending / {len(recordings)} total files; {args.workers} offline workers.', flush=True)
    failures = []
    with ProcessPoolExecutor(max_workers=max(1, args.workers)) as executor:
        futures = {executor.submit(generate, item): item for item in pending}
        for done, future in enumerate(as_completed(futures), 1):
            try:
                future.result()
            except Exception as error:
                failures.append({'file': futures[future]['file'], 'text': futures[future]['text'], 'error': str(error)})
            if done % 100 == 0 or done == len(pending):
                print(f'Completed {done}/{len(pending)}; failed {len(failures)}.', flush=True)
    write_atomic(plan / 'generation-errors.json', failures)
    if failures:
        raise RuntimeError(f'{len(failures)} recordings failed; active manifest unchanged. Rerun after fixing.')
    for recording in recordings:
        if not (OUTPUT / recording['file']).is_file() or (OUTPUT / recording['file']).stat().st_size <= 1000:
            raise RuntimeError('Incomplete pack: ' + recording['file'])
    license_path = Path(pyopenjtalk.__file__).parent / 'htsvoice/LICENSE_mei_normal.htsvoice'
    shutil.copyfile(license_path, OUTPUT / 'LICENSE-Mei.txt')
    write_atomic(OUTPUT / 'recordings.json', recordings)
    write_atomic(ROOT / 'app/core/japanese/audio-manifest.json', manifest)
    total = sum((OUTPUT / item['file']).stat().st_size for item in recordings)
    print(f'Activated {len(recordings)} MP3s ({total / 1024 / 1024:.1f} MiB); all manifest files verified.', flush=True)


if __name__ == '__main__':
    main()
