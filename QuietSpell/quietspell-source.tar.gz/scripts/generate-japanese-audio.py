"""Generate the bundled MP3s. Only maintainers need these Python dependencies.

pip install pyopenjtalk-plus==0.4.1.post10 lameenc==1.8.1
node --experimental-strip-types scripts/japanese-audio-manifest.mjs
python scripts/generate-japanese-audio.py
"""
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
cached_tools = ROOT / '.cache' / 'japanese-audio-tools'
if cached_tools.exists():
    sys.path.insert(0, str(cached_tools))

import lameenc
import numpy as np
import pyopenjtalk

output = ROOT / 'public' / 'audio' / 'japanese'
recordings = json.loads((output / 'recordings.json').read_text(encoding='utf-8'))
for index, recording in enumerate(recordings):
    destination = output / recording['file']
    if destination.exists():
        continue
    samples, sample_rate = pyopenjtalk.tts(recording['text'], speed=0.9)
    if not len(samples) or np.max(np.abs(samples)) < 1:
        raise RuntimeError(f"Empty recording: {recording['text']}")
    # Open JTalk emits float samples in signed 16-bit amplitude range.
    pcm = np.clip(samples, -32768, 32767).astype('<i2').tobytes()
    encoder = lameenc.Encoder()
    encoder.set_bit_rate(64)
    encoder.set_in_sample_rate(sample_rate)
    encoder.set_channels(1)
    encoder.set_quality(2)
    destination.write_bytes(encoder.encode(pcm) + encoder.flush())
    if (index + 1) % 25 == 0:
        print(f'Generated {index + 1}/{len(recordings)} recordings.', flush=True)

voice_license = Path(pyopenjtalk.__file__).parent / 'htsvoice' / 'LICENSE_mei_normal.htsvoice'
shutil.copyfile(voice_license, output / 'LICENSE-Mei.txt')
total = sum((output / recording['file']).stat().st_size for recording in recordings)
print(f"Japanese audio ready: {len(recordings)} files, {total / 1024 / 1024:.2f} MiB.")
