"""Apply the reviewed reading ledger to an exact source snapshot; quarantine known bad OCR examples."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def prepare(source_bytes, review):
    if hashlib.sha256(source_bytes).hexdigest() != review['sourceSha256']:
        raise ValueError('Reading corrections belong to another source snapshot.')
    rows = json.loads(source_bytes.decode('utf-8'))
    index = {(row['text'], row['reading']): row for row in rows}
    for fix in review['suggestions']:
        row = index[(fix['text'], fix['reading'])]
        matches = [item for item in row.get('examples', []) if item['text'] == fix['exampleText'] and item['reading'] == fix['oldReading']]
        if len(matches) != 1:
            raise ValueError('Reading correction no longer matches exactly: ' + fix['text'])
        matches[0]['reading'] = fix['newReading']
    # 方 refers to people in this sentence, rather than direction.
    above = index[('以上', 'いじょう')]['examples'][0]
    old = 'ろくじゅっさいいじょうのほう'
    if old not in above['reading']:
        raise ValueError('Expected context for 方 is missing.')
    above['reading'] = above['reading'].replace(old, 'ろくじゅっさいいじょうのかた', 1)
    quarantine_heads = {note.split('：', 1)[0] for note in review['stillNeedsSentenceReview']}
    quarantined = []
    for row in rows:
        if row['text'] in quarantine_heads and row.get('examples'):
            quarantined.append({'text': row['text'], 'reading': row['reading'], 'examples': row.pop('examples')})
            row['detailsSource'] = row.get('detailsSource', '') + ' 本条原书 OCR 例句存在待核实的识别问题，暂不展示。'
    if {row['text'] for row in quarantined} != quarantine_heads:
        raise ValueError('A quarantined OCR sentence was not found.')
    return rows, quarantined


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--review', type=Path, default=ROOT / 'scripts/data/japanese-numeric-reading-review.json')
    parser.add_argument('--output', type=Path, default=ROOT / 'app/core/japanese/books/n3-enrichment.json')
    args = parser.parse_args()
    source = args.source.read_bytes()
    review = json.loads(args.review.read_text(encoding='utf-8'))
    rows, quarantined = prepare(source, review)
    output = (json.dumps(rows, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    args.output.write_bytes(output)
    report_dir = ROOT / 'output/n3-books/pronunciation'
    report_dir.mkdir(parents=True, exist_ok=True)
    report = {'numericReadingsCorrected': len(review['suggestions']), 'contextReadingsCorrected': 1,
              'quarantinedExampleEntries': len(quarantined), 'sourceSha256': hashlib.sha256(source).hexdigest(),
              'resultSha256': hashlib.sha256(output).hexdigest(),
              'note': 'Only the reviewed readings are corrected; remaining OCR data is a preview.'}
    (report_dir / 'quarantined-examples.json').write_text(json.dumps(quarantined, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (report_dir / 'review-report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
