import json
from pathlib import Path
import re
import sys
ROOT=Path(__file__).resolve().parents[1];TMP=ROOT/'tmp/pdfs'
sys.path.insert(0,str(ROOT/'.cache/ocr-tools'))
import cv2
import numpy as np
from PIL import Image
from rapidocr import RapidOCR,OCRVersion,ModelType
from rapidocr.ch_ppocr_rec.typings import TextRecInput
engine=RapidOCR(params={'Global.use_det':False,'Global.use_cls':False,'Global.model_root_dir':str(ROOT/'.cache/ocr-models'),'Rec.lang_type':'japan','Rec.ocr_version':OCRVersion.PPOCRV4,'Rec.model_type':ModelType.MOBILE,'Rec.rec_img_shape':[3,48,160],'Rec.rec_batch_num':64,'EngineConfig.onnxruntime.intra_op_num_threads':8,'EngineConfig.onnxruntime.inter_op_num_threads':1})
rec=engine._load_rec_model()
cells=json.loads((TMP/'cells.json').read_text(encoding='utf-8'))
out=TMP/'recognized-cells-v4';out.mkdir(exist_ok=True)
by_page={}
for cell in cells:by_page.setdefault((cell['book'],cell['page']),[]).append(cell)
for counter,((book,page),pagecells) in enumerate(by_page.items()):
    path=out/f'b{book}-p{page:03}.json'
    if path.exists():continue
    if book==0:
        previous=TMP/'recognized-cells-v2'/path.name
        if previous.exists():path.write_bytes(previous.read_bytes());continue
    meta=json.loads((TMP/'ja'/f'b{book}-p{page:03}-1.json').read_text(encoding='utf-8'))
    image=Image.new('RGB',(meta['width'],meta['fullHeight']),'white')
    image.paste(Image.open(TMP/'tiles'/f'b{book}-p{page:03}-0.png'),(0,0))
    image.paste(Image.open(TMP/'tiles'/f'b{book}-p{page:03}-1.png'),(0,meta['offsetY']))
    crops=[];keys=[]
    for cell in pagecells:
        for field in ['word','reading']:
            box=tuple(int(v) for v in cell[field+'Box'])
            crop=np.array(image.crop(box))
            gray=cv2.cvtColor(crop,cv2.COLOR_RGB2GRAY)
            if book==1:
                # This book prints white headwords on gray panels. Isolate and invert the panel.
                medians=np.median(gray,axis=0)
                columns=cv2.morphologyEx(np.uint8(medians<225)[None,:],cv2.MORPH_CLOSE,np.ones((1,21),np.uint8))[0]>0
                spans=[];start=None
                for i,selected in enumerate([*columns,False]):
                    if selected and start is None:start=i
                    elif not selected and start is not None:
                        spans.append((start,i));start=None
                span=max(spans,key=lambda pair:pair[1]-pair[0],default=(0,gray.shape[1]))
                if span[1]-span[0]>gray.shape[1]*.35:
                    gray=gray[:,span[0]:span[1]]
                    foreground=np.uint8(gray>225)*255
                    count,labels,stats,_=cv2.connectedComponentsWithStats(foreground)
                    cleaned=np.zeros_like(foreground)
                    for label in range(1,count):
                        if stats[label,cv2.CC_STAT_AREA]>=9:cleaned[labels==label]=255
                    crop=cv2.cvtColor(255-cleaned,cv2.COLOR_GRAY2RGB)
                    gray=cv2.cvtColor(crop,cv2.COLOR_RGB2GRAY)
            mask=np.uint8(gray<135)*255
            horizontal=cv2.morphologyEx(mask,cv2.MORPH_OPEN,np.ones((1,max(80,int(mask.shape[1]*.7))),np.uint8))
            vertical=cv2.morphologyEx(mask,cv2.MORPH_OPEN,np.ones((max(50,int(mask.shape[0]*.85)),1),np.uint8))
            mask=cv2.subtract(cv2.subtract(mask,horizontal),vertical)
            ys,xs=np.where(mask>0)
            if len(xs)<20:cell[field]='';cell[field+'Score']=0;continue
            left=max(0,xs.min()-3);right=min(crop.shape[1],xs.max()+4);top=max(0,ys.min()-3);bottom=min(crop.shape[0],ys.max()+4)
            crops.append(crop[top:bottom,left:right]);keys.append((cell,field))
    if crops:
        result=rec(TextRecInput(img=crops))
        for (cell,field),text,score in zip(keys,result.txts,result.scores):cell[field]=re.sub(r'\s+','',text);cell[field+'Score']=round(float(score),5)
    path.write_text(json.dumps(pagecells,ensure_ascii=False),encoding='utf-8')
    if (counter+1)%25==0:print(f'Word-cell recognition: {counter+1}/{len(by_page)} pages',flush=True)
print('Word-cell recognition complete.',flush=True)
