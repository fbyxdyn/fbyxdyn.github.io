"""Extract the 12 core lessons into an isolated review draft, never app data."""
import json
from pathlib import Path
import re
from kanzen_grammar_ocr import ROOT,pages,compact

OUT=ROOT/'output/n3-books/kanzen-grammar';OUT.mkdir(parents=True,exist_ok=True)
ja=pages('ja');zh=pages('zh-Hans-CN')
units=[]
for line in (ROOT/'scripts/data/kanzen-grammar-main-units.tsv').read_text(encoding='utf-8').splitlines():
    if not line.strip() or line.startswith('#'):continue
    lesson,point,page,top,title,connection,meaning=line.split('|')
    units.append({'id':f'kg-p1-l{int(lesson):02}-g{int(point):02}','lesson':int(lesson),'point':int(point),
                  'page':int(page),'top':int(top),'title':title,'connection':connection,'meaning':meaning})
end_pages={1:24,2:26,3:30,4:32,5:38,6:40,7:44,8:46,9:52,10:54,11:58,12:60}


def in_span(row,page,unit,end):
    return (unit['page'],unit['top']+70)<=(page,row['y'])<(end['page'],end['top']) and 120<row['x']<1800 and 200<row['y']<2575


def clean_japanese(value):
    value=compact(value)
    value=re.sub(r'^[1-9⑴-⑼①-⑨](?:[.、])?','',value)
    value=value.split('/',1)[0].strip()
    if not re.search('[ぁ-ゖァ-ヺ]',value):return ''
    if re.search(r'[这們请个尓么]|[{}<>]',value):return ''
    return value


def complete(value):return bool(re.search('[。！？!?][」』”"]?$',value))


result=[];issues=[]
for index,unit in enumerate(units):
    end=units[index+1] if index+1<len(units) and units[index+1]['lesson']==unit['lesson'] else {'page':end_pages[unit['lesson']]+1,'top':0}
    rows=[{**r,'page':p} for p,rs in ja.items() for r in rs if in_span(r,p,unit,end)]
    rows.sort(key=lambda r:(r['page'],r['y'],r['x']))
    starts=[r for r in rows if re.match(r'^[1-9][^0-9~]',r['text']) and r['x']<280 and 32<=r['h']<=53 and re.search('[ぁ-ゖァ-ヺ]',r['text'])]
    examples=[]
    for k,start in enumerate(starts):
        next_start=starts[k+1] if k+1<len(starts) else {'page':end['page'],'y':end['top']}
        jp_rows=[]
        for r in rows:
            if not (start['page'],start['y']-5)<=(r['page'],r['y'])<(next_start['page'],next_start['y']-10):continue
            if r is not start and not jp_rows:continue
            if r['page']!=start['page']:break
            if r['x']>=1100 or not 30<=r['h']<=53:continue
            if jp_rows and r['y']-jp_rows[-1]['y']>90:break
            value=clean_japanese(r['text'])
            if not value:break
            jp_rows.append(r)
            if complete(''.join(clean_japanese(l['text']) for l in jp_rows)):break
        text=''.join(clean_japanese(r['text']) for r in jp_rows)
        if not text or not complete(text):
            issues.append({'unit':unit['id'],'page':start['page'],'reason':'incomplete Japanese sentence','candidate':text});continue
        last=jp_rows[-1]
        inline=[]
        for r in zh.get(start['page'],[]):
            if abs(r['y']-last['y'])<15 and '/' in r['text']:inline.append(r['text'].split('/',1)[1])
        if inline:translation=''.join(inline)
        else:
            cn=[r for r in zh.get(start['page'],[]) if last['bottom']+8<r['y']<min(last['bottom']+160,next_start['y']-10 if next_start['page']==start['page'] else 2575)
                and 180<r['x']<900 and 29<r['h']<48 and re.search('[一-鿿]',r['text']) and not re.search('[ぁ-ゖァ-ヺ]',r['text'])]
            translation=''.join(r['text'] for r in cn)
        translation=translation.strip('。 ')
        if not translation:
            issues.append({'unit':unit['id'],'page':start['page'],'reason':'missing translation','candidate':text});continue
        examples.append({'text':text,'meaning':translation,'page':start['page'],'top':start['y'],'bottom':min(last['bottom']+160,2575)})
    record={**unit,'examples':examples}
    if not examples:issues.append({'unit':unit['id'],'page':unit['page'],'reason':'no accepted numbered example'})
    result.append(record)
(OUT/'main-draft.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'main-review.json').write_text(json.dumps(issues,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(result),'grammar points;',sum(len(e['examples']) for e in result),'examples;',len(issues),'review items')
for e in result:print(e['id'],e['title'],len(e['examples']),e['examples'][0]['text'] if e['examples'] else 'MISSING')
