import { cp, mkdir, readFile, realpath, stat, unlink, utimes, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'

// Run after generating with NUXT_APP_BASE_URL=/QuietSpell/ and ORIGIN set to the blog domain.
// Dry run prepares reviewable configuration files without changing the blog.
const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const blog = await realpath(path.resolve(process.argv[2] ?? 'F:/blog'))
const apply = process.argv.includes('--apply')
const requireFromBlog = createRequire(path.join(blog, 'package.json'))
const yaml = requireFromBlog('js-yaml')
const source = path.join(projectRoot, '.output/public')
const configPath = path.join(blog, '_config.yml')
const original = await readFile(configPath, 'utf8')
const config = yaml.load(original)
if (config.theme !== 'next' || config.source_dir !== 'source')
  throw new Error('Expected the inspected Hexo + NexT source layout.')
const destination = path.resolve(blog, 'source/QuietSpell')
if (!destination.startsWith(blog + path.sep)) throw new Error('Destination must be inside the supplied blog.')
await stat(path.join(source, 'japanese/index.html'))
const html = await readFile(path.join(source, 'japanese/index.html'), 'utf8')
if (!html.includes('/QuietSpell/_nuxt/') || !html.includes('https://fbyxdyn.github.io/'))
  throw new Error('Generate the site with the correct base URL and origin first.')

let modified = original.replace(/^url:.*$/m, 'url: https://fbyxdyn.github.io/')
function addListItem(key, value) {
  const existing = config[key]
  const values = existing == null ? [] : Array.isArray(existing) ? existing : [existing]
  if (values.includes(value)) return
  config[key] = [...values, value]
  const block = `${key}:\n${config[key].map(item => `  - ${JSON.stringify(item)}`).join('\n')}`
  // The inspected file uses empty or block-style lists. Reject inline nonempty lists to avoid loss.
  const pattern = new RegExp(`^${key}:[^\\n]*(?:\\n[ \\t]+[^\\n]*)*`, 'm')
  if (!pattern.test(modified)) throw new Error(`Cannot locate ${key} in Hexo config.`)
  modified = modified.replace(pattern, block)
}
addListItem('skip_render', 'QuietSpell/**')
addListItem('include', 'QuietSpell/**')
addListItem('include', '.nojekyll')
addListItem('exclude', 'typewords/**')

// NexT 7 reads source/_data/next.yml as the site's theme override.
const nextPath = path.join(blog, 'source/_data/next.yml')
let nextOriginal = null
try {
  nextOriginal = await readFile(nextPath, 'utf8')
} catch (error) {
  if (error.code !== 'ENOENT') throw error
}
const nextConfig = nextOriginal ? (yaml.load(nextOriginal) ?? {}) : {}
nextConfig.menu ??= {}
if (nextConfig.menu['日语学习']?.includes('/typewords/')) delete nextConfig.menu['日语学习']
nextConfig.menu['QuietSpell'] = '/QuietSpell/japanese/ || fa fa-language'
const nextModified = yaml.dump(nextConfig, { lineWidth: 120, noRefs: true })

const reviewDir = path.join(projectRoot, '.cache/hexo-integration')
await mkdir(reviewDir, { recursive: true })
await writeFile(path.join(reviewDir, '_config.yml.before'), original)
await writeFile(path.join(reviewDir, '_config.yml.after'), modified)
await writeFile(path.join(reviewDir, 'next.yml.after'), nextModified)
const parsed = yaml.load(modified)
if (
  parsed.url !== 'https://fbyxdyn.github.io/' ||
  !parsed.include.includes('.nojekyll') ||
  !parsed.skip_render.includes('QuietSpell/**')
)
  throw new Error('Invalid generated configuration.')

if (!apply) {
  console.log(
    `Prepared Hexo integration for ${blog}. Review ${reviewDir}. Pass --apply to copy the built site and apply the config.`
  )
  process.exit(0)
}

const backup = path.join(blog, '.quietspell-backup', new Date().toISOString().replace(/[:.]/g, '-'))
await mkdir(backup, { recursive: true })
await writeFile(path.join(backup, '_config.yml'), original)
if (nextOriginal !== null) await writeFile(path.join(backup, 'next.yml'), nextOriginal)
// These posts were renamed locally after the last published build. Preserve their existing URLs.
const publishedPermalinks = {
  '博客搭建初体验.md': '2025/12/03/blog1/',
  '《太白金星有点烦》读后感.md': '2025/03/13/my-first-blog/',
  'hexo使用技术文档.md': '2025/03/12/hello-world/',
}
let changedPosts = false
for (const [filename, permalink] of Object.entries(publishedPermalinks)) {
  const postPath = path.join(blog, 'source/_posts', filename)
  const postStats = await stat(postPath)
  const post = await readFile(postPath, 'utf8')
  const frontmatter = post.match(/^---\r?\n([\s\S]*?)\r?\n---/)
  if (!frontmatter || /^permalink:/m.test(frontmatter[1])) continue
  await mkdir(path.join(backup, 'posts'), { recursive: true })
  await writeFile(path.join(backup, 'posts', filename), post)
  const slug = permalink.split('/').at(-2)
  const withoutTemporarySlug = post.replace(new RegExp(`^slug: ${slug}\\r?\\n`, 'm'), '')
  await writeFile(postPath, withoutTemporarySlug.replace(/^---\r?\n/, `---\npermalink: ${permalink}\n`))
  await utimes(postPath, postStats.atime, postStats.mtime)
  changedPosts = true
}
if (changedPosts) {
  // Rebuild Hexo's source cache because the original post modification dates are retained.
  const databasePath = path.join(blog, 'db.json')
  try {
    await cp(databasePath, path.join(backup, 'db.json'))
    await unlink(databasePath)
  } catch (error) {
    if (error.code !== 'ENOENT') throw error
  }
}
await mkdir(path.dirname(nextPath), { recursive: true })
await cp(source, destination, { recursive: true })
await writeFile(configPath, modified)
await writeFile(nextPath, nextModified)
await writeFile(path.join(blog, 'source/.nojekyll'), '')
console.log(`Integrated Japanese learning at ${destination}. Original configuration backed up in ${backup}.`)
