import json
from pathlib import Path
import pdfplumber

root=Path(__file__).resolve().parents[1]/'tmp/pdfs'
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
for book in manifest[2:]:
    pages=[]
    with pdfplumber.open(book['path']) as doc:
        for index,page in enumerate(doc.pages):
            filtered=page.filter(lambda obj: obj['object_type']!='char' or obj['size']>=8)
            lines=[]
            for line in filtered.extract_text_lines():
                chars=line['chars']
                lines.append({'text':line['text'],'x0':line['x0'],'top':line['top'],'bottom':line['bottom'], 'heading': ''.join(c['text'] for c in chars if 'MS-Gothic' in c['fontname'] and c['size']>=11.8), 'height': max((c['size'] for c in chars),default=0)})
            pages.append({'page':index+1,'lines':lines})
            if (index+1)%50==0: print(f"Extracted text book {book['id']}: {index+1}/{len(doc.pages)}",flush=True)
    (root/f"text-book-{book['id']}.json").write_text(json.dumps(pages,ensure_ascii=False),encoding='utf-8')
