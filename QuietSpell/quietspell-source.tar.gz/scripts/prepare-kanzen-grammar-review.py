"""Create a small offline review package. Never publishes or copies into the live blog."""
import hashlib
import html
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/n3-books/kanzen-grammar'
DEST = OUT / 'review-package'
BOOK = ROOT / 'app/core/japanese/books/n3-kanzen-grammar.json'


def escape(value):
    return html.escape(str(value), quote=True)


def main():
    raw = BOOK.read_bytes()
    book = json.loads(raw)
    review = json.loads((OUT / 'calibration/accepted-review.json').read_text(encoding='utf-8'))
    assert hashlib.sha256(raw).hexdigest() == review['resultSha256']
    DEST.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(BOOK, DEST / 'n3-kanzen-grammar.json')
    shutil.copyfile(OUT / 'calibration/accepted-review.json', DEST / 'accepted-review.json')
    data_dir = DEST / 'source-data'
    data_dir.mkdir(exist_ok=True)
    inputs = ['kanzen-grammar-main-units.tsv', 'kanzen-grammar-main-reviewed-examples.tsv',
              'kanzen-grammar-organized-reviewed.tsv', 'kanzen-grammar-composition-reviewed.tsv',
              'kanzen-grammar-reading-corrections.json']
    for name in inputs:
        shutil.copyfile(ROOT / 'scripts/data' / name, data_dir / name)
    cards, units = [], []
    for entry in book['entries']:
        unit = entry['label'].split('｜')[0]
        if unit not in units:
            units.append(unit)
        authored = '自编学习例句' in entry['detailsSource']
        search = ' '.join([entry['id'], entry['label'], entry['text'], entry['reading'], entry['meaning'], entry['usage']])
        cards.append(f'''<article class="entry" data-unit="{escape(unit)}" data-search="{escape(search)}">
<div class="meta"><code>{escape(entry['id'])}</code><span>PDF 第 {entry['source']['page']} 页</span><span class="{'authored' if authored else 'source'}">{'自编例句' if authored else '原书来源例句'}</span></div>
<h3>{escape(entry['label'])}</h3><p class="jp" lang="ja">{escape(entry['text'])}</p><p lang="ja" class="reading">{escape(entry['reading'])}</p><p>{escape(entry['meaning'])}</p><pre>{escape(entry['usage'])}</pre><p class="origin">{escape(entry['detailsSource'])}</p></article>''')
    fields = {'connection': '接续', 'grammarMeaning': '用法', 'translation': '中文翻译'}
    changes = []
    for change in review['changes']:
        changes.append(f'''<tr><td><code>{escape(change['id'])}</code><br>{fields[change['field']]} · PDF {change['sourcePdfPage']}</td><td>{escape(change['before'])}</td><td>{escape(change['acceptedAfter'])}</td></tr>''')
    options = ''.join(f'<option value="{escape(unit)}">{escape(unit)}</option>' for unit in units)
    document = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>新完全 N3 语法 · 本地审核版</title>
<style>body{font-family:"Segoe UI","Microsoft YaHei",sans-serif;margin:0;color:#243147;background:#f4f7fb;line-height:1.75}main{max-width:1050px;margin:auto;padding:30px 20px}h1{font-size:28px;margin-bottom:8px}h2{font-size:21px;margin-top:34px}h3{font-size:18px;margin:14px 0}.intro,.origin{color:#68768b}.stats{display:flex;gap:12px;flex-wrap:wrap;margin:20px 0}.stats span,.entry,.notice{background:#fff;border:1px solid #e0e6f0;border-radius:12px;padding:14px 18px}.notice{border-left:4px solid #d49b2a}.filters{display:flex;gap:10px;flex-wrap:wrap;margin:18px 0;position:sticky;top:0;background:#f4f7fb;padding:10px 0}input,select{font:inherit;font-size:16px;min-height:44px;padding:8px 10px;border:1px solid #cfd8e6;border-radius:8px;max-width:100%;box-sizing:border-box}input{flex:1;min-width:180px}.entry{margin:16px 0}.meta{display:flex;gap:12px;align-items:center;flex-wrap:wrap;font-size:12px;color:#738198}.source{color:#27724f}.authored{color:#9b6428}.jp{font-size:20px}.reading{color:#65728b;font-size:14px}pre{white-space:pre-wrap;font:inherit;background:#f6f8fc;border-radius:8px;padding:14px}.origin{font-size:12px}a{color:#285fca}table{width:100%;border-collapse:collapse;font-size:13px;background:#fff}td,th{padding:11px;border:1px solid #dde4ef;text-align:left;vertical-align:top;overflow-wrap:anywhere}.table-wrap{overflow-x:auto}code{font-size:12px}nav{display:flex;gap:20px;flex-wrap:wrap}.entry[hidden]{display:none}@media(max-width:600px){main{padding:20px 14px}.jp{font-size:18px}.entry{padding:15px}td{min-width:140px}h1{font-size:25px}}</style>
<main><header><p class="intro">QuietSpell · 等待用户审核 · 尚未公开</p><h1>新完全掌握 N3 语法</h1><p>本地审核版：接续、用法、例句与译文。</p><nav><a href="#entries">查看全部条目</a><a href="#changes">查看本轮修订</a><a href="http://127.0.0.1:5567/japanese">打开本地学习页面</a></nav></header>
<div class="stats"><span>211 项语法／用法</span><span>36 个教学单元</span><span>196 条原书来源例句</span><span>15 条已标注自编例句</span></div>
<aside class="notice"><strong>审核范围</strong><p>这是按教学单元精选整理的学习版，练习题、模拟题未录入。少量自编例句已逐条标注；原 PDF 第39、42页有图像截断。本轮合并29项、30个字段，关键原书页已抽查，未宣称全书逐页精校或全部听音验收。审核通过前不会公开发布。</p></aside>
<section id="entries"><h2>全部 211 项</h2><p>可搜索语法名、例句、中文或条目编号。在本地学习页选择「新完全掌握 N3 · 语法」即可练习和试听。</p><div class="filters"><input id="search" type="search" aria-label="搜索语法条目" placeholder="搜索，如：つもり、かどうか、せず"><select id="unit" aria-label="选择教学单元"><option value="">全部教学单元</option>__OPTIONS__</select></div><p id="count" aria-live="polite">显示 211 项</p>__CARDS__</section>
<section id="changes"><h2>本轮修订：29项，30个字段</h2><p>日文例句、假名读音、条目编号及来源页码均保持不变。重点纠正了「つもりだ」自认用法与打算用法的区别。</p><div class="table-wrap"><table><thead><tr><th>条目／字段</th><th>修订前</th><th>本地审核版</th></tr></thead><tbody>__CHANGES__</tbody></table></div></section>
<footer><p class="intro">本地数据 SHA-256：<code>__SHA__</code>。此审核包不包含个人学习进度。</p></footer></main>
<script>const input=document.getElementById('search'),unit=document.getElementById('unit'),cards=Array.from(document.querySelectorAll('.entry'));function filter(){const query=input.value.normalize('NFKC').toLowerCase().trim();let count=0;for(const card of cards){const show=(!unit.value||card.dataset.unit===unit.value)&&(!query||card.dataset.search.normalize('NFKC').toLowerCase().includes(query));card.hidden=!show;if(show)count++}document.getElementById('count').textContent='显示 '+count+' / 211 项'}input.addEventListener('input',filter);unit.addEventListener('change',filter);</script></html>'''
    document = document.replace('__OPTIONS__', options).replace('__CARDS__', '\n'.join(cards)).replace('__CHANGES__', '\n'.join(changes)).replace('__SHA__', review['resultSha256'])
    (DEST / 'index.html').write_text(document, encoding='utf-8')
    manifest = {'status': 'awaiting-user-review', 'publicationApproved': False, 'entries': 211,
                'teachingUnits': len(units), 'sourceExamples': 196, 'authoredExamples': 15,
                'grammarSha256': review['resultSha256'], 'changedEntries': 29, 'changedFields': 30,
                'localPreview': 'http://127.0.0.1:5567/japanese',
                'excluded': ['raw OCR drafts', 'unapproved vocabulary batch3', 'personal learning progress'],
                'files': {str(path.relative_to(DEST)): hashlib.sha256(path.read_bytes()).hexdigest()
                          for path in DEST.rglob('*') if path.is_file() and path.suffix != '.zip' and path.name != 'manifest.json'}}
    (DEST / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    archive = DEST / 'QuietSpell-kanzen-grammar-review-20261121.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as package:
        for path in DEST.rglob('*'):
            if path.is_file() and path != archive:
                package.write(path, str(path.relative_to(DEST)))
    print(json.dumps({'reviewHtml': str(DEST / 'index.html'), 'archive': str(archive), 'entries': 211, 'publicationApproved': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
