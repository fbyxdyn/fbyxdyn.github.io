import assert from 'node:assert/strict'
import test from 'node:test'
import { readFile, stat } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { createServer } from 'vite'

const root = fileURLToPath(new URL('../', import.meta.url))
const vite = await createServer({
  configFile: false, root, cacheDir: `${root}.cache/vite-audio-tests`,
  server: { middlewareMode: true }, logLevel: 'error',
})
const { createJapaneseSpeaker, getJapaneseAudioPath, splitJapaneseSpeech } = await vite.ssrLoadModule('/app/core/japanese/audio.ts')
const { JAPANESE_LESSONS } = await vite.ssrLoadModule('/app/core/japanese/content.ts')
const { N3_BOOKS } = await vite.ssrLoadModule('/app/core/japanese/n3-books.ts')
const { getJapaneseExamples } = await vite.ssrLoadModule('/app/core/japanese/details.ts')
const recordings = JSON.parse(await readFile(new URL('../public/audio/japanese/recordings.json', import.meta.url)))

function fixture() {
  const players = [], calls = [], errors = []
  globalThis.__NUXT__ = { config: { app: { baseURL: '/QuietSpell/' } } }
  globalThis.document = { querySelector: () => null, baseURI: 'file:///app/hybrid/html/index.html' }
  globalThis.window = { location: { protocol: 'https:' } }
  globalThis.Audio = class {
    constructor() { players.push(this) }
    play() { calls.push(this.src); return this.nextPlay?.() ?? Promise.resolve() }
    pause() { this.paused = true }
    load() {}
    removeAttribute() { this.src = '' }
  }
  return { players, calls, errors, speaker: createJapaneseSpeaker(message => errors.push(message)) }
}

try {
  await test('reviewed readings bypass obsolete MP3s and known bad OCR examples remain hidden', async () => {
    const core = N3_BOOKS.find(book => book.id === 'n3-pdf-1')
    const forgetful = core.entries.find(entry => entry.text === '物忘れ')
    const example = getJapaneseExamples(forgetful)[0]
    assert.match(example.reading, /ごじゅっさい/)
    assert.equal(getJapaneseAudioPath(example.text, example.reading), null)
    const f = fixture()
    await f.speaker.speak(example.text, false, example.reading)
    assert.match(new URL(f.calls[0]).searchParams.get('audio'), /ごじゅっさい/)
    assert.equal(getJapaneseExamples(core.entries.find(entry => entry.text === '備える')).length, 0)
  })
  await test('all 103 handed-off Kanzen examples survive independent-book integration', async () => {
    const handedOff = JSON.parse(await readFile(new URL('../output/n3-books/kanzen/source-examples.json', import.meta.url)))
    const book = N3_BOOKS.find(item => item.id === 'n3-pdf-0')
    assert.equal(book.entries.length, 1800)
    assert.equal(handedOff.entries.length, 103)
    for (const row of handedOff.entries) {
      const entry = book.entries.find(item => item.id === row.id)
      for (const example of row.examples) assert.ok(getJapaneseExamples(entry).some(item =>
        item.text === example.text && item.reading === example.reading && item.meaning === example.meaning
      ), row.id)
    }
  })
  await test('all 120 second-batch examples retain their reviewed readings after merging', async () => {
    const handedOff = JSON.parse(await readFile(new URL('../output/n3-books/kanzen/batch2/source-examples.json', import.meta.url)))
    const book = N3_BOOKS.find(item => item.id === 'n3-pdf-0')
    assert.equal(handedOff.entries.length, 120)
    for (const row of handedOff.entries) {
      const entry = book.entries.find(item => item.id === row.id)
      for (const example of row.examples) assert.ok(getJapaneseExamples(entry).some(item =>
        item.text === example.text && item.reading === example.reading && item.meaning === example.meaning
      ), row.id)
    }
  })
  await test('built-in content has bundled audio or a complete real-time pronunciation path', async () => {
    let checked = 0, bundled = 0
    for (const lesson of [...JAPANESE_LESSONS, ...N3_BOOKS]) for (const entry of lesson.entries) {
      for (const item of [entry, ...getJapaneseExamples(entry), ...(entry.phrases ?? []), ...(entry.synonyms ?? []), ...(entry.similarSounds ?? [])]) {
        if (getJapaneseAudioPath(item.text, item.reading)) bundled++
        else assert.ok(splitJapaneseSpeech(item.reading || item.text).length, `${lesson.id}: ${item.text}`)
        checked++
      }
    }
    assert.ok(checked > 10000)
    assert.ok(bundled > 10000)
    for (const item of recordings) {
      assert.match(item.file, /^(?:n3\/)?[a-f0-9]{20}\.mp3$/)
      assert.ok((await stat(new URL(`../public/audio/japanese/${item.file}`, import.meta.url))).size > 1000)
    }
  })
  await test('manual play starts synchronously, reuses the mobile-unlocked element and needs no system TTS', async () => {
    const f = fixture()
    const pending = f.speaker.speak('開く', false, 'あく')
    assert.equal(f.calls.length, 1, 'play must happen in the tap handler before awaiting')
    await pending
    await f.speaker.speak('開く', true, 'ひらく')
    assert.equal(f.players.length, 1)
    assert.notEqual(f.calls[0], f.calls[1])
    assert.ok(f.calls.every(path => path.startsWith('/QuietSpell/audio/japanese/')))
    assert.deepEqual(f.errors, [])
    assert.equal(getJapaneseAudioPath('開く', 'ありえないよみ'), null)
  })
  await test('blocked mobile autoplay is visible and a subsequent tap retries successfully', async () => {
    const f = fixture()
    await f.speaker.speak('先生', false, 'せんせい')
    f.players[0].nextPlay = () => Promise.reject(Object.assign(new Error(), { name: 'NotAllowedError' }))
    await f.speaker.speak('先生', true, 'せんせい')
    assert.match(f.errors.at(-1), /点击.*听发音/)
    f.players[0].nextPlay = null
    await f.speaker.speak('先生', false, 'せんせい')
    assert.equal(f.calls.length, 3)
    assert.equal(f.players.length, 1)
  })
  await test('obsolete play failures cannot overwrite the current word and stop releases media', async () => {
    const f = fixture()
    await f.speaker.speak('先生')
    let reject
    f.players[0].nextPlay = () => new Promise((_, fail) => { reject = fail })
    const stale = f.speaker.speak('先生')
    f.players[0].nextPlay = null
    await f.speaker.speak('友達')
    reject(new Error('interrupted old request'))
    await stale
    assert.deepEqual(f.errors, [])
    f.speaker.stop()
    assert.equal(f.players[0].src, '')
    assert.equal(f.players[0].onerror, null)
    assert.equal(f.players[0].paused, true)
  })
  await test('native local file playback uses bundled N3 audio without reaching the website', async () => {
    const f = fixture()
    window.location.protocol = 'file:'
    await f.speaker.speak('開く', false, 'ひらく')
    assert.match(f.calls[0], /^file:\/\/\/app\/hybrid\/html\/audio\/japanese\/n3\//)
  })
  await test('imported content keeps a Japanese voice fallback using its specified reading', async () => {
    const f = fixture(), spoken = []
    window.speechSynthesis = {
      cancel() {}, getVoices: () => [{ lang: 'en-US' }, { lang: 'ja-JP' }],
      speak: value => spoken.push(value),
    }
    globalThis.SpeechSynthesisUtterance = class { constructor(text) { this.text = text } }
    await f.speaker.speak('外部未収録の語句', false, 'がいぶみしゅうろくのごく')
    assert.equal(f.players.length, 0)
    assert.equal(spoken[0].text, 'がいぶみしゅうろくのごく')
    assert.equal(spoken[0].voice.lang, 'ja-JP')
    delete window.speechSynthesis
    await f.speaker.speak('外部未収録の語句')
    assert.equal(f.players.length, 1)
    const url = new URL(f.calls[0])
    assert.equal(url.hostname, 'dict.youdao.com')
    assert.equal(url.searchParams.get('le'), 'jap')
    assert.equal(url.searchParams.get('audio'), '外部未収録の語句')
    assert.deepEqual(f.errors, [])
  })
  await test('missing device voices start real-time Japanese audio synchronously without waiting for voice discovery', async () => {
    const f = fixture()
    window.speechSynthesis = { cancel() {}, getVoices: () => [{ lang: 'en-US' }] }
    const started = f.speaker.speak('未配音の文', false, 'みはいおんのぶん')
    assert.equal(f.calls.length, 1)
    assert.equal(new URL(f.calls[0]).searchParams.get('audio'), 'みはいおんのぶん')
    await started
    assert.deepEqual(f.errors, [])
  })
  await test('long online readings play every chunk and stop cancels the remaining article', async () => {
    const f = fixture(), text = 'あ'.repeat(100) + 'い'.repeat(100) + 'う'.repeat(50)
    assert.deepEqual(splitJapaneseSpeech(text), ['あ'.repeat(100), 'い'.repeat(100), 'う'.repeat(50)])
    await f.speaker.speak(text)
    f.players[0].onended()
    assert.equal(new URL(f.calls.at(-1)).searchParams.get('audio'), 'い'.repeat(100))
    f.players[0].onended()
    assert.equal(new URL(f.calls.at(-1)).searchParams.get('audio'), 'う'.repeat(50))
    const oldEnded = f.players[0].onended
    f.speaker.stop()
    oldEnded()
    assert.equal(f.calls.length, 3)
    assert.equal(f.players.length, 1)
  })
  await test('failed static files fall back to streaming and online failures show a retry message', async () => {
    const f = fixture()
    await f.speaker.speak('先生', false, 'せんせい')
    f.players[0].onerror()
    await Promise.resolve()
    assert.equal(f.calls.length, 2)
    assert.equal(new URL(f.calls[1]).searchParams.get('audio'), 'せんせい')
    f.players[0].onerror()
    await Promise.resolve()
    assert.match(f.errors.at(-1), /检查网络/)
    assert.equal(f.calls.length, 2, 'network errors must not retry forever')
  })
  await test('a failing Japanese system voice falls back to real-time online playback', async () => {
    const f = fixture(), utterances = []
    window.speechSynthesis = { cancel() {}, getVoices: () => [{ lang: 'ja-JP' }], speak: value => utterances.push(value) }
    await f.speaker.speak('未収録の文')
    utterances[0].onerror({ error: 'synthesis-failed' })
    assert.equal(f.calls.length, 1)
    assert.match(f.calls[0], /^https:\/\/dict\.youdao\.com/)
  })
} finally {
  await vite.close()
}
