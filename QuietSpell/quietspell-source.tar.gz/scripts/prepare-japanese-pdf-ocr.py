"""Render the two image-only N3 books into bounded OCR tiles; keep intermediate scans private."""
import json
from pathlib import Path
import pypdfium2 as pdfium

root = Path(__file__).resolve().parents[1] / 'tmp' / 'pdfs'
manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
jobs = {'ja': [], 'zh-Hans-CN': []}
(root / 'tiles').mkdir(exist_ok=True)
for language in jobs:
    (root / language).mkdir(exist_ok=True)
for book in manifest[:2]:
    document = pdfium.PdfDocument(book['path'])
    for index in range(len(document)):
        page = document[index]
        width, height = page.get_size()
        # Preserve small furigana while respecting Windows OCR's 2600 px limit.
        image = page.render(scale=1900 / width).to_pil().convert('RGB')
        offsets = [0] if image.height <= 2450 else [0, image.height // 2 - 80]
        for tile, offset in enumerate(offsets):
            bottom = image.height if len(offsets) == 1 or tile == 1 else image.height // 2 + 80
            filename = root / 'tiles' / f"b{book['id']}-p{index+1:03}-{tile}.png"
            if not filename.exists():
                image.crop((0, offset, image.width, bottom)).save(filename)
            for language in jobs:
                jobs[language].append({'book': book['id'], 'page': index+1, 'offsetY': offset, 'fullHeight': image.height, 'image': str(filename.resolve()), 'output': str((root / language / f"b{book['id']}-p{index+1:03}-{tile}.json").resolve())})
        page.close()
        if (index + 1) % 50 == 0:
            print(f"Rendered book {book['id']}: {index+1}/{len(document)} pages", flush=True)
    document.close()
for language, language_jobs in jobs.items():
    (root / f'jobs-{language}.json').write_text(json.dumps(language_jobs, ensure_ascii=False), encoding='utf-8')
print(f"Prepared {len(jobs['ja'])} OCR tiles in each language.", flush=True)
