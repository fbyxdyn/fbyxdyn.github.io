import assert from 'node:assert/strict'
import test from 'node:test'
import { createHash } from 'node:crypto'
import { createServer } from 'vite'
import { fileURLToPath } from 'node:url'
import { createRenderer, nextTick } from 'vue'
import { createSyncWorker } from '../services/quietspell-sync/worker/index.mjs'

const root = fileURLToPath(new URL('../', import.meta.url))
const vite = await createServer({ configFile: false, root, cacheDir: `${root}.cache/vite-sync-tests`,
  server: { middlewareMode: true, hmr: false, watch: null }, resolve: { alias: { '@': `${root}app` } }, logLevel: 'error' })
const { createJapaneseSyncClient, JapaneseSyncError } = await vite.ssrLoadModule('/app/core/japanese/sync-client.ts')
const { parseJapaneseSnapshot } = await vite.ssrLoadModule('/app/core/japanese/snapshot.ts')
const { useJapaneseUserSync } = await vite.ssrLoadModule('/app/composables/useJapaneseUserSync.ts')
const lesson = { id: 'demo', title: 'Demo', kind: 'words', entries: [{ id: 'one', text: '日本語', reading: 'にほんご', meaning: '日语' }] }
const snapshot = () => ({ version: 1, preferencesVersion: 2, lessonId: 'demo', inputMode: 'japanese', practiceMode: 'free',
  progress: {}, wordbooks: [], customText: '', voice: 'original', session: null, finished: false,
  settings: { wordReviewRatio: 3, repeatCount: 1, autoNextWord: false, waitTimeForChangeWord: 300, wordSound: false, wordSoundVolume: 100, wordSoundSpeed: 1, translate: true } })
const env = { INVITE_CODE: 'synthetic-test-invite', GITHUB_TOKEN: 'synthetic-test-token', GITHUB_OWNER: 'example', GITHUB_REPO: 'private-data' }
const json = (value, status = 200) => new Response(JSON.stringify(value), { status, headers: { 'Content-Type': 'application/json' } })
function service() {
  const files = new Map(), blobs = new Map(), requests = [], github = []
  const worker = createSyncWorker({ fetch: async (url, init) => {
    github.push(url)
    const path = new URL(url).pathname.replace('/repos/example/private-data', '')
    if (!path) return json({ private: true, default_branch: 'main' })
    if (path.startsWith('/git/blobs/')) return new Response(blobs.get(path.split('/').at(-1)))
    const file = path.slice('/contents/'.length).split('/').map(decodeURIComponent).join('/')
    if (init.method !== 'PUT') {
      const previous = files.get(file)
      return previous ? json({ type: 'file', sha: previous.sha, size: previous.text.length }) : json({}, 404)
    }
    const change = JSON.parse(init.body), previous = files.get(file)
    if (previous && change.sha !== previous.sha) return json({}, 409)
    const text = Buffer.from(change.content, 'base64').toString('utf8')
    const sha = createHash('sha1').update(text).digest('hex')
    files.set(file, { sha, text }); blobs.set(sha, text)
    return json({ content: { sha } }, previous ? 200 : 201)
  } })
  const request = async (url, init) => {
    requests.push({ url, init })
    return worker.fetch(new Request(url, { ...init, headers: { ...init.headers, Origin: 'https://fbyxdyn.github.io' } }), env)
  }
  return { files, github, requests, request, client: createJapaneseSyncClient('https://sync.example', request) }
}
function mountSync(options) {
  const storage = new Map()
  globalThis.localStorage = { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) }
  const renderer = createRenderer({ createElement: () => ({}), createComment: () => ({}), createText: () => ({}),
    insert() {}, remove() {}, setText() {}, setElementText() {}, patchProp() {}, parentNode: () => null, nextSibling: () => null })
  let sync
  const app = renderer.createApp({ setup() { sync = useJapaneseUserSync(options); return () => null } })
  app.mount({})
  return { app, sync, storage }
}
try {
  await test('client/server round trip preserves Unicode IDs and snapshots; secrets remain in POST bodies only', async () => {
    const f = service(), id = ' 用户/../🌸 ', data = snapshot()
    const saved = await f.client.upload(id, env.INVITE_CODE, data, null)
    const loaded = await f.client.download(id, env.INVITE_CODE)
    assert.deepEqual(parseJapaneseSnapshot(loaded.snapshot, [lesson]), parseJapaneseSnapshot(data, [lesson]))
    assert.equal(saved.sha, loaded.sha)
    assert.equal(loaded.userId, id)
    for (const item of f.requests) {
      assert.equal(new URL(item.url).search, '')
      assert.equal(item.init.credentials, 'omit')
      assert.equal(JSON.parse(item.init.body).inviteCode, env.INVITE_CODE)
    }
    assert.equal(f.files.size, 1)
    const [path, stored] = [...f.files.entries()][0]
    assert.ok(path.startsWith('users/%20%E7%94%A8%E6%88%B7%2F'))
    assert.doesNotMatch(stored.text, /synthetic-test-invite|synthetic-test-token/)
  })
  await test('wrong invitation blocks upload and download without contacting the private repository', async () => {
    const f = service()
    await assert.rejects(f.client.upload('id', 'wrong', snapshot(), null), e => e instanceof JapaneseSyncError && e.status === 403)
    await assert.rejects(f.client.download('id', 'wrong'), e => e.status === 403)
    assert.equal(f.github.length, 0)
  })
  await test('conflicting upload never overwrites newer remote data', async () => {
    const f = service(), first = await f.client.upload('id', env.INVITE_CODE, snapshot(), null)
    const newer = snapshot(); newer.settings.wordSoundSpeed = 2
    await f.client.upload('id', env.INVITE_CODE, newer, first.sha)
    await assert.rejects(f.client.upload('id', env.INVITE_CODE, snapshot(), first.sha), e => e.status === 409)
    assert.equal((await f.client.download('id', env.INVITE_CODE)).snapshot.settings.wordSoundSpeed, 2)
  })
  await test('schema validation rejects malformed progress, prototype keys and unknown sessions before restore', () => {
    for (const change of [
      s => { s.progress.demo = { index: -1 } },
      s => { s.settings = JSON.parse('{"__proto__":{"polluted":true}}') },
      s => { s.session = { lessonId: 'other' } },
      s => { s.voice = 'untrusted' },
      s => { s.settings.wordSoundSpeed = -1 },
      s => { s.settings.fsrsParameters = { learning_steps: ['not-a-duration'] } },
      s => { s.settings.fsrsParameters = { relearning_steps: [{ component: {} }] } },
      s => { s.settings.fsrsGoodLimit = null },
    ]) {
      const s = snapshot(); change(s)
      assert.throws(() => parseJapaneseSnapshot(s, [lesson]))
    }
    assert.equal({}.polluted, undefined)
  })
  await test('canceled late downloads never apply data; only the ID is persisted and closing clears the invitation', async () => {
    let complete, restored = 0
    globalThis.fetch = (_url, _init) => new Promise(resolve => { complete = resolve })
    const f = mountSync({ endpoint: 'https://sync.example', exportSnapshot: snapshot, restoreSnapshot: () => restored++, restoreDownloadBackup() {} })
    f.sync.userId.value = '用户/ abc '
    f.sync.inviteCode.value = env.INVITE_CODE
    const pending = f.sync.download()
    f.sync.cancel()
    complete(json({ ok: true, userId: f.sync.userId.value, sha: 'a'.repeat(40), updatedAt: new Date().toISOString(), snapshot: snapshot() }))
    await pending
    assert.equal(restored, 0)
    assert.ok(!JSON.stringify([...f.storage]).includes(env.INVITE_CODE))
    f.sync.resetSecret()
    assert.equal(f.sync.inviteCode.value, '')
    f.app.unmount()
  })
  await test('manual upload discovers cloud revision without applying it, then updates the requested ID', async () => {
    const f = service()
    globalThis.fetch = f.request
    let restored = 0
    const view = mountSync({ endpoint: 'https://sync.example', exportSnapshot: snapshot, restoreSnapshot: () => restored++, restoreDownloadBackup() {} })
    view.sync.userId.value = 'same-id'
    view.sync.inviteCode.value = env.INVITE_CODE
    await view.sync.upload()
    assert.equal(view.sync.status.value, 'success')
    assert.equal(restored, 0)
    assert.deepEqual(f.requests.map(item => new URL(item.url).pathname), ['/sync/download', '/sync/upload'])
    await view.sync.download()
    assert.equal(restored, 1)
    view.app.unmount()
    await nextTick()
  })
  await test('client preserves a uniCloud function prefix and rejects oversized bodies before sending', async () => {
    let calls = 0
    const client = createJapaneseSyncClient('https://cloud.example/quietspell/', async url => {
      calls++
      assert.equal(new URL(url).pathname, '/quietspell/sync/download')
      return json({ ok: true, userId: 'demo', sha: 'a'.repeat(40), updatedAt: new Date().toISOString(), snapshot: snapshot() })
    })
    await client.download('demo', 'test')
    await assert.rejects(client.upload('demo', 'test', { customText: 'x'.repeat(2 * 1024 * 1024) }, null), error => error.status === 413)
    assert.equal(calls, 1)
  })
  await test('budget failures show safe local messages and malformed SHA lengths are rejected', async () => {
    const client = createJapaneseSyncClient('https://cloud.example/quietspell', async () => json({ ok: false, error: { code: 'BUDGET_EXHAUSTED', message: 'private upstream token' } }, 429))
    await assert.rejects(client.download('demo', 'test'), error => error.status === 429 && error.message.includes('用量已达上限') && !error.message.includes('private'))
    const malformed = createJapaneseSyncClient('https://cloud.example/quietspell', async () => json({ ok: true, userId: 'demo', sha: 'a'.repeat(41), updatedAt: new Date().toISOString(), snapshot: snapshot() }))
    await assert.rejects(malformed.download('demo', 'test'), /版本校验失败/)
  })
} finally { await vite.close() }
