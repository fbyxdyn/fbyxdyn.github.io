import { enrichJapaneseEntry } from './details.ts'
import { STARTER_JAPANESE_DETAILS } from './starter-details.ts'

export interface JapaneseExample {
  text: string
  reading: string
  meaning: string
}
export interface JapaneseExpression extends JapaneseExample {
  note?: string
}
export interface JapaneseEntry {
  id: string
  text: string
  reading: string
  meaning: string
  // Explicit spellings are useful for particles pronounced differently from their kana.
  romaji?: string[]
  example?: JapaneseExample
  partOfSpeech?: string
  senses?: { partOfSpeech?: string; meaning: string; note?: string }[]
  examples?: JapaneseExample[]
  phrases?: JapaneseExpression[]
  synonyms?: JapaneseExpression[]
  similarSounds?: JapaneseExpression[]
  usage?: string
  detailsSource?: string
  label?: string
  source?: { book: number; page: number; number: number; confidence?: number }
}

export interface JapaneseLesson {
  id: string
  title: string
  description: string
  kind: 'kana' | 'words' | 'article'
  entries: JapaneseEntry[]
  sourceType?: 'vocabulary' | 'grammar' | 'listening'
}

const kanaRows = [
  ['あいうえお', 'a i u e o'],
  ['かきくけこ', 'ka ki ku ke ko'],
  ['さしすせそ', 'sa shi su se so'],
  ['たちつてと', 'ta chi tsu te to'],
  ['なにぬねの', 'na ni nu ne no'],
  ['はひふへほ', 'ha hi fu he ho'],
  ['まみむめも', 'ma mi mu me mo'],
  ['やゆよ', 'ya yu yo'],
  ['らりるれろ', 'ra ri ru re ro'],
  ['わをん', 'wa wo n'],
]

const voicedRows = [
  ['がぎぐげご', 'ga gi gu ge go'],
  ['ざじずぜぞ', 'za ji zu ze zo'],
  ['だぢづでど', 'da di du de do'],
  ['ばびぶべぼ', 'ba bi bu be bo'],
  ['ぱぴぷぺぽ', 'pa pi pu pe po'],
]

const contractedRows = [
  ['きゃ きゅ きょ', 'kya kyu kyo'],
  ['しゃ しゅ しょ', 'sha shu sho'],
  ['ちゃ ちゅ ちょ', 'cha chu cho'],
  ['にゃ にゅ にょ', 'nya nyu nyo'],
  ['ひゃ ひゅ ひょ', 'hya hyu hyo'],
  ['みゃ みゅ みょ', 'mya myu myo'],
  ['りゃ りゅ りょ', 'rya ryu ryo'],
  ['ぎゃ ぎゅ ぎょ', 'gya gyu gyo'],
  ['じゃ じゅ じょ', 'ja ju jo'],
  ['びゃ びゅ びょ', 'bya byu byo'],
  ['ぴゃ ぴゅ ぴょ', 'pya pyu pyo'],
]

export function toKatakana(text: string): string {
  return text.replace(/[ぁ-ゖ]/g, character => String.fromCharCode(character.charCodeAt(0) + 0x60))
}

function kanaEntries(rows: string[][], prefix: string, katakana = false): JapaneseEntry[] {
  return rows.flatMap(([characters, romanizations]) => {
    const kana = characters.includes(' ') ? characters.split(' ') : [...characters]
    return kana.map((reading, index) => ({
      id: `${prefix}-${index}-${reading}`,
      text: katakana ? toKatakana(reading) : reading,
      reading: katakana ? toKatakana(reading) : reading,
      meaning: katakana ? '片假名' : '平假名',
      romaji: [romanizations.split(' ')[index]],
    }))
  })
}

function words(id: string, rows: string[][]): JapaneseEntry[] {
  return rows.map(([text, reading, meaning, romaji], index) => ({
    id: `${id}-${index}`,
    text,
    reading,
    meaning,
    ...(romaji ? { romaji: romaji.split('|') } : {}),
  }))
}

export const JAPANESE_LESSONS: JapaneseLesson[] = [
  {
    id: 'hiragana',
    title: '平假名 · 五十音',
    description: '46 个基础假名，从 あいうえお 开始。',
    kind: 'kana',
    entries: kanaEntries(kanaRows, 'h'),
  },
  {
    id: 'katakana',
    title: '片假名 · 五十音',
    description: '46 个基础片假名，认识外来语的写法。',
    kind: 'kana',
    entries: kanaEntries(kanaRows, 'k', true),
  },
  {
    id: 'voiced',
    title: '浊音与半浊音',
    description: 'が、ざ、だ、ば、ぱ 行，共 25 个。',
    kind: 'kana',
    entries: kanaEntries(voicedRows, 'v'),
  },
  {
    id: 'contracted',
    title: '拗音',
    description: 'きゃ、しゅ、ちょ 等 33 个组合。',
    kind: 'kana',
    entries: kanaEntries(contractedRows, 'c'),
  },
  {
    id: 'greetings',
    title: '日常问候',
    description: '从第一句日语开始，练习常用表达。',
    kind: 'words',
    entries: words('greetings', [
      ['こんにちは', 'こんにちは', '你好；日间问候', 'konnichiwa|konnichiha'],
      ['おはよう', 'おはよう', '早上好'],
      ['こんばんは', 'こんばんは', '晚上好', 'konbanwa|konbanha'],
      ['ありがとう', 'ありがとう', '谢谢'],
      ['すみません', 'すみません', '不好意思；对不起'],
      ['さようなら', 'さようなら', '再见'],
      ['はじめまして', 'はじめまして', '初次见面'],
      ['お願いします', 'おねがいします', '拜托了；请多关照'],
      ['はい', 'はい', '是；好的'],
      ['いいえ', 'いいえ', '不是；不'],
    ]),
  },
  {
    id: 'everyday',
    title: '入门词汇 · 日常生活',
    description: '20 个基础词汇，结合汉字、读音和中文释义。',
    kind: 'words',
    entries: words('everyday', [
      ['私', 'わたし', '我'],
      ['日本語', 'にほんご', '日语'],
      ['学生', 'がくせい', '学生'],
      ['先生', 'せんせい', '老师'],
      ['友達', 'ともだち', '朋友'],
      ['学校', 'がっこう', '学校'],
      ['本', 'ほん', '书'],
      ['水', 'みず', '水'],
      ['猫', 'ねこ', '猫'],
      ['犬', 'いぬ', '狗'],
      ['今日', 'きょう', '今天'],
      ['明日', 'あした', '明天'],
      ['朝', 'あさ', '早晨'],
      ['食べる', 'たべる', '吃'],
      ['飲む', 'のむ', '喝'],
      ['行く', 'いく', '去'],
      ['見る', 'みる', '看'],
      ['聞く', 'きく', '听'],
      ['電車', 'でんしゃ', '电车'],
      ['切手', 'きって', '邮票'],
    ]),
  },
  {
    id: 'katakana-words',
    title: '片假名词汇',
    description: '练习长音符号、促音和常见外来语。',
    kind: 'words',
    entries: words('katakana-words', [
      ['コーヒー', 'コーヒー', '咖啡'],
      ['スーパー', 'スーパー', '超市'],
      ['テレビ', 'テレビ', '电视'],
      ['カメラ', 'カメラ', '照相机'],
      ['ホテル', 'ホテル', '酒店'],
      ['タクシー', 'タクシー', '出租车'],
      ['パン', 'パン', '面包'],
      ['ベッド', 'ベッド', '床'],
      ['チケット', 'チケット', '票'],
      ['コンピューター', 'コンピューター', '电脑'],
    ]),
  },
  {
    id: 'introduction',
    title: '短文 · 自我介绍',
    description: '逐句练习，用日语介绍自己。',
    kind: 'article',
    entries: words('introduction', [
      ['はじめまして。', 'はじめまして。', '初次见面。'],
      ['私は学生です。', 'わたしはがくせいです。', '我是学生。', 'watashi wa gakusei desu.|watashi ha gakusei desu.'],
      [
        '毎日、日本語を勉強します。',
        'まいにち、にほんごをべんきょうします。',
        '我每天学习日语。',
        'mainichi, nihongo o benkyou shimasu.|mainichi, nihongo wo benkyou shimasu.',
      ],
      ['どうぞよろしくお願いします。', 'どうぞよろしくおねがいします。', '请多关照。'],
    ]),
  },
  {
    id: 'weekend',
    title: '短文 · 我的周末',
    description: '在短句中练习生活词汇与句型。',
    kind: 'article',
    entries: words('weekend', [
      [
        '今日は日曜日です。',
        'きょうはにちようびです。',
        '今天是星期日。',
        'kyou wa nichiyoubi desu.|kyou ha nichiyoubi desu.',
      ],
      ['友達と公園に行きます。', 'ともだちとこうえんにいきます。', '我和朋友去公园。'],
      [
        '一緒にお弁当を食べます。',
        'いっしょにおべんとうをたべます。',
        '我们一起吃便当。',
        'issho ni obentou o tabemasu.|issho ni obentou wo tabemasu.',
      ],
      ['とても楽しいです。', 'とてもたのしいです。', '非常开心。'],
    ]),
  },
]

const examples: Record<string, [string, string, string]> = {
  こんにちは: ['こんにちは、お元気ですか。', 'こんにちは、おげんきですか。', '你好，你好吗？'],
  おはよう: ['おはよう、よく眠れましたか。', 'おはよう、よくねむれましたか。', '早上好，睡得好吗？'],
  こんばんは: ['こんばんは、今日は寒いですね。', 'こんばんは、きょうはさむいですね。', '晚上好，今天真冷啊。'],
  ありがとう: ['手伝ってくれて、ありがとう。', 'てつだってくれて、ありがとう。', '谢谢你帮忙。'],
  すみません: ['すみません、駅はどこですか。', 'すみません、えきはどこですか。', '请问，车站在哪里？'],
  さようなら: ['先生、さようなら。', 'せんせい、さようなら。', '老师，再见。'],
  はじめまして: ['はじめまして、田中です。', 'はじめまして、たなかです。', '初次见面，我姓田中。'],
  お願いします: ['水をお願いします。', 'みずをおねがいします。', '请给我水。'],
  はい: ['はい、わかりました。', 'はい、わかりました。', '好的，明白了。'],
  いいえ: ['いいえ、違います。', 'いいえ、ちがいます。', '不，不是的。'],
  私: ['私は中国から来ました。', 'わたしはちゅうごくからきました。', '我来自中国。'],
  日本語: ['日本語を勉強しています。', 'にほんごをべんきょうしています。', '我正在学习日语。'],
  学生: ['兄は大学生です。', 'あにはだいがくせいです。', '哥哥是大学生。'],
  先生: ['先生に質問します。', 'せんせいにしつもんします。', '向老师提问。'],
  友達: ['友達と映画を見ます。', 'ともだちとえいがをみます。', '和朋友看电影。'],
  学校: ['毎日、学校に行きます。', 'まいにち、がっこうにいきます。', '每天去学校。'],
  本: ['図書館で本を読みます。', 'としょかんでほんをよみます。', '在图书馆看书。'],
  水: ['水を飲みます。', 'みずをのみます。', '喝水。'],
  猫: ['猫が寝ています。', 'ねこがねています。', '猫在睡觉。'],
  犬: ['犬と散歩します。', 'いぬとさんぽします。', '和狗散步。'],
  今日: ['今日はいい天気です。', 'きょうはいいてんきです。', '今天天气很好。'],
  明日: ['明日は休みです。', 'あしたはやすみです。', '明天休息。'],
  朝: ['朝、パンを食べます。', 'あさ、パンをたべます。', '早晨吃面包。'],
  食べる: ['一緒にご飯を食べましょう。', 'いっしょにごはんをたべましょう。', '一起吃饭吧。'],
  飲む: ['毎朝、お茶を飲みます。', 'まいあさ、おちゃをのみます。', '每天早晨喝茶。'],
  行く: ['明日、京都に行きます。', 'あした、きょうとにいきます。', '明天去京都。'],
  見る: ['夜、テレビを見ます。', 'よる、テレビをみます。', '晚上看电视。'],
  聞く: ['音楽を聞きます。', 'おんがくをききます。', '听音乐。'],
  電車: ['電車で会社に行きます。', 'でんしゃでかいしゃにいきます。', '坐电车去公司。'],
  切手: ['郵便局で切手を買います。', 'ゆうびんきょくできってをかいます。', '在邮局买邮票。'],
  コーヒー: ['コーヒーを一杯ください。', 'コーヒーをいっぱいください。', '请给我一杯咖啡。'],
  スーパー: ['スーパーで野菜を買います。', 'スーパーでやさいをかいます。', '在超市买蔬菜。'],
  テレビ: ['このテレビは新しいです。', 'このテレビはあたらしいです。', '这台电视是新的。'],
  カメラ: ['カメラで写真を撮ります。', 'カメラでしゃしんをとります。', '用相机拍照。'],
  ホテル: ['駅の近くにホテルがあります。', 'えきのちかくにホテルがあります。', '车站附近有一家酒店。'],
  タクシー: ['タクシーで帰ります。', 'タクシーでかえります。', '坐出租车回去。'],
  パン: ['このパンはおいしいです。', 'このパンはおいしいです。', '这个面包很好吃。'],
  ベッド: ['部屋にベッドがあります。', 'へやにベッドがあります。', '房间里有一张床。'],
  チケット: ['チケットを二枚ください。', 'チケットをにまいください。', '请给我两张票。'],
  コンピューター: ['コンピューターで仕事をします。', 'コンピューターでしごとをします。', '用电脑工作。'],
}

for (const lesson of JAPANESE_LESSONS) {
  for (const entry of lesson.entries) {
    const example = examples[entry.text]
    if (example) entry.example = { text: example[0], reading: example[1], meaning: example[2] }
    Object.assign(entry, enrichJapaneseEntry(entry, STARTER_JAPANESE_DETAILS))
  }
}
