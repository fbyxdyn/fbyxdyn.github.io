import type { JapaneseSupplement } from './details'

// Original teaching examples and usage notes, kept separate from PDF transcriptions.
export const STARTER_JAPANESE_DETAILS: JapaneseSupplement[] = [
  {
    text: '友達',
    reading: 'ともだち',
    partOfSpeech: '名词',
    examples: [
      { text: '友達に手紙を書きました。', reading: 'ともだちにてがみをかきました。', meaning: '我给朋友写了信。' },
      {
        text: '週末は友達と過ごします。',
        reading: 'しゅうまつはともだちとすごします。',
        meaning: '周末和朋友一起度过。',
      },
    ],
    phrases: [
      { text: '友達になる', reading: 'ともだちになる', meaning: '成为朋友' },
      { text: '友達と遊ぶ', reading: 'ともだちとあそぶ', meaning: '和朋友一起玩' },
    ],
    synonyms: [
      {
        text: '友人',
        reading: 'ゆうじん',
        meaning: '朋友',
        note: '较正式，常用于书面语或正式介绍；「友達」在日常会话中更常用。',
      },
    ],
    usage: '用「友達と」表示和朋友一起做某事；用「友達に」标记动作的对象，例如给朋友写信。',
    detailsSource: '学习补充（自编例句）',
  },
  {
    text: '先生',
    reading: 'せんせい',
    partOfSpeech: '名词 / 称呼',
    senses: [{ meaning: '老师', note: '也可直接用来称呼老师。' }, { meaning: '对医生等专业人士的敬称' }],
    examples: [
      {
        text: '田中先生は日本語を教えています。',
        reading: 'たなかせんせいはにほんごをおしえています。',
        meaning: '田中老师教日语。',
      },
    ],
    phrases: [{ text: '先生に質問する', reading: 'せんせいにしつもんする', meaning: '向老师提问' }],
    synonyms: [
      {
        text: '教師',
        reading: 'きょうし',
        meaning: '教师',
        note: '说明职业身份；一般不能像「先生」那样直接用来称呼对方。',
      },
    ],
    detailsSource: '学习补充（自编例句）',
  },
  {
    text: '食べる',
    reading: 'たべる',
    partOfSpeech: '一段动词 / 他动词',
    examples: [{ text: '毎朝、パンを食べます。', reading: 'まいあさ、ぱんをたべます。', meaning: '每天早晨吃面包。' }],
    phrases: [
      { text: '朝ご飯を食べる', reading: 'あさごはんをたべる', meaning: '吃早饭' },
      { text: '外で食べる', reading: 'そとでたべる', meaning: '在外面吃饭' },
    ],
    synonyms: [
      {
        text: '召し上がる',
        reading: 'めしあがる',
        meaning: '吃 / 喝（尊敬语）',
        note: '用于尊敬对方或第三人，不能用来抬高自己；不是所有语境都能直接替换。',
      },
    ],
    usage: '基本句型为「食物＋を＋食べる」。礼貌形式是「食べます」。',
    detailsSource: '学习补充（自编例句）',
  },
  {
    text: '見る',
    reading: 'みる',
    partOfSpeech: '一段动词 / 他动词',
    examples: [
      {
        text: '昨日、友達と映画を見ました。',
        reading: 'きのう、ともだちとえいがをみました。',
        meaning: '昨天和朋友一起看了电影。',
      },
    ],
    phrases: [
      { text: '映画を見る', reading: 'えいがをみる', meaning: '看电影' },
      { text: '様子を見る', reading: 'ようすをみる', meaning: '观察情况' },
    ],
    synonyms: [
      {
        text: '眺める',
        reading: 'ながめる',
        meaning: '眺望；注视',
        note: '强调持续地看景物等；并不能替代所有表示「看」的「見る」。',
      },
    ],
    usage: '「見る」表示主动看；「見える」表示看得见、进入视野，句型和意思有所不同。',
    detailsSource: '学习补充（自编例句）',
  },
  {
    text: '聞く',
    reading: 'きく',
    partOfSpeech: '五段动词 / 他动词',
    senses: [{ meaning: '听' }, { meaning: '询问；打听' }],
    examples: [
      { text: '駅員に道を聞きました。', reading: 'えきいんにみちをききました。', meaning: '我向车站工作人员问了路。' },
    ],
    phrases: [
      { text: '音楽を聞く', reading: 'おんがくをきく', meaning: '听音乐' },
      { text: '意見を聞く', reading: 'いけんをきく', meaning: '听取意见' },
    ],
    synonyms: [
      { text: '尋ねる', reading: 'たずねる', meaning: '询问', note: '只对应「聞く」的询问义，不能替换听音乐等用法。' },
    ],
    usage: '「人に＋内容を＋聞く」可以表示向某人询问某事。',
    detailsSource: '学习补充（自编例句）',
  },
  {
    text: '学生',
    reading: 'がくせい',
    partOfSpeech: '名词',
    examples: [{ text: '私は大学の学生です。', reading: 'わたしはだいがくのがくせいです。', meaning: '我是大学生。' }],
    phrases: [
      { text: '学生生活', reading: 'がくせいせいかつ', meaning: '学生生活' },
      { text: '学生証', reading: 'がくせいしょう', meaning: '学生证' },
    ],
    usage:
      '学校层级不同，常用称呼也会不同，例如小学生常称「児童」、中学生和高中生常称「生徒」。这些词不能一概当作同义词互换。',
    detailsSource: '学习补充（自编例句）',
  },
]
