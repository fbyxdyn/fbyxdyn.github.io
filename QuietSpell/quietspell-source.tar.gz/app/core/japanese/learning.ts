import type { JapaneseEntry } from './content'

export type JapanesePracticeMode = 'system' | 'free' | 'identify' | 'listen' | 'recall'
export type JapaneseStage = 'follow' | 'identify' | 'listen' | 'recall'
export interface JapaneseSharedSettings {
  wordReviewRatio: number
  autoAddRandomReviewWhenNoDue?: boolean
  repeatCount: number
  repeatCustomCount?: number
  autoNextWord: boolean
  waitTimeForChangeWord: number
  wordSound: boolean
  wordSoundVolume: number
  wordSoundSpeed: number
  translate: boolean
  fsrsParameters?: Record<string, any>
  fsrsEasyLimit?: number
  fsrsGoodLimit?: number
  fsrsHardLimit?: number
}
export const defaultJapaneseSettings = (): JapaneseSharedSettings => ({
  wordReviewRatio: 3,
  repeatCount: 1,
  autoNextWord: false,
  waitTimeForChangeWord: 300,
  wordSound: true,
  wordSoundVolume: 100,
  wordSoundSpeed: 1,
  translate: true,
})
export interface JapaneseTask {
  entryId: string
  stage: JapaneseStage
  review: boolean
}
export interface JapaneseSession {
  lessonId: string
  mode: JapanesePracticeMode
  tasks: JapaneseTask[]
  position: number
  repetition: number
  wrong: Record<string, number>
  newCount: number
  reviewCount: number
}
export const japaneseStageNames: Record<JapaneseStage, string> = {
  follow: '跟写',
  identify: '自测',
  listen: '听写',
  recall: '默写',
}

/** Keep the same new-word limit, review ratio and stage order as the English practice flow. */
export function createJapaneseSession(options: {
  lessonId: string
  entries: JapaneseEntry[]
  start: number
  daily: number
  reviewRatio: number
  mode: JapanesePracticeMode
  dueIds: string[]
  reviewOnly?: boolean
}): JapaneseSession {
  const { lessonId, entries, mode } = options
  const daily = Math.max(1, Math.min(500, Math.trunc(options.daily) || 20))
  const start = Math.max(0, Math.min(entries.length, Math.trunc(options.start) || 0))
  const fresh = options.reviewOnly ? [] : entries.slice(start, start + daily)
  const newIds = new Set(fresh.map(item => item.id))
  const byId = new Map(entries.map(item => [item.id, item]))
  const ratio = Math.max(0, Math.min(10, Math.trunc(options.reviewRatio) || 0))
  const reviews = [...new Set(options.dueIds)]
    .filter(id => byId.has(id) && !newIds.has(id))
    .slice(0, options.reviewOnly ? daily * Math.max(1, ratio) : daily * ratio)
  const tasks: JapaneseTask[] = []
  const append = (ids: string[], stages: JapaneseStage[], review: boolean) => {
    for (const stage of stages) for (const entryId of ids) tasks.push({ entryId, stage, review })
  }
  const newStages: JapaneseStage[] =
    mode === 'system' ? ['follow', 'listen', 'recall'] : [mode === 'free' ? 'follow' : mode]
  const reviewStages: JapaneseStage[] = mode === 'system' ? ['identify', 'listen', 'recall'] : newStages
  append(
    fresh.map(item => item.id),
    newStages,
    false
  )
  append(reviews, reviewStages, true)
  return {
    lessonId,
    mode,
    tasks,
    position: 0,
    repetition: 0,
    wrong: {},
    newCount: fresh.length,
    reviewCount: reviews.length,
  }
}

/** IME confirmation must never submit an answer or consume the next exercise. */
export function shouldHandleJapaneseKey(
  event: { key: string; isComposing?: boolean; keyCode?: number; repeat?: boolean },
  composing: boolean,
  millisecondsSinceComposition: number
): boolean {
  return (
    event.key === 'Enter' &&
    !event.isComposing &&
    !composing &&
    event.keyCode !== 229 &&
    !event.repeat &&
    millisecondsSinceComposition > 80
  )
}
