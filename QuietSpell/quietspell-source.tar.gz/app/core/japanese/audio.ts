import manifest from './audio-manifest.json'
import { withAppBaseURL } from '../utils/base-url'
import { isJapaneseVoice, type JapaneseVoice } from './voices'

export const JAPANESE_RELAY = 'https://quietspell-japanese-voice.wavy-cream-0113.chatgpt.site/speech'
export function getMicrosoftJapaneseAudioURL(text: string, voice: JapaneseVoice) {
  return `${JAPANESE_RELAY}?${new URLSearchParams({ text, voice })}`
}

const recordings = new Map(Object.entries(manifest))
const textsWithReadings = new Set(
  [...recordings.keys()].filter(key => key.includes('\0')).map(key => key.split('\0')[0])
)

/** Readings distinguish homographs such as 開く（あく／ひらく）. */
export function getJapaneseAudioPath(text: string, reading?: string): string | null {
  text = text.normalize('NFC').trim()
  reading = reading?.normalize('NFC').trim()
  const file = reading
    ? recordings.get(`${text}\0${reading}`) || (!textsWithReadings.has(text) ? recordings.get(text) : undefined)
    : recordings.get(text)
  return file ? `/audio/japanese/${file}` : null
}

/** Keep requests short and play all chunks, rather than silently truncating an article. */
export function splitJapaneseSpeech(text: string): string[] {
  const characters = Array.from(
    text
      .normalize('NFC')
      .replace(/[～〜~]/g, '')
      .trim()
  )
  const chunks: string[] = []
  while (characters.length) {
    let length = Math.min(100, characters.length)
    if (characters.length > length) {
      for (let i = length - 1; i >= 50; i--) {
        if (/[。！？!?、,；;\s]/u.test(characters[i]!)) {
          length = i + 1
          break
        }
      }
    }
    const chunk = characters.splice(0, length).join('').trim()
    if (chunk) chunks.push(chunk)
  }
  return chunks
}

export function getJapaneseOnlineAudioURL(text: string) {
  return `https://dict.youdao.com/dictvoice?audio=${encodeURIComponent(text)}&le=jap`
}

export function createJapaneseSpeaker(
  onError: (message: string) => void,
  getSettings: () => { volume: number; rate: number; voice?: JapaneseVoice } = () => ({ volume: 1, rate: 0.85 })
) {
  let audio: HTMLAudioElement | null = null
  let request = 0
  let loadTimer: ReturnType<typeof setTimeout> | undefined

  function stop() {
    request++
    clearTimeout(loadTimer)
    if (audio) {
      audio.pause()
      audio.onerror = null
      audio.onended = null
      audio.removeAttribute('src')
      audio.load()
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.cancel()
  }

  async function speak(text: string, automatic = false, reading?: string) {
    stop()
    const activeRequest = request
    const chunks = splitJapaneseSpeech(reading || text)
    if (!chunks.length) return

    async function playSource(source: string, next?: () => void, fallback?: () => Promise<void>) {
      if (activeRequest !== request) return
      // Call play in the tap handler and retain the same mobile-unlocked element.
      const player = (audio ??= new Audio())
      player.preload = 'auto'
      player.src = source
      player.volume = Math.max(0, Math.min(1, getSettings().volume))
      player.playbackRate = Math.max(0.25, Math.min(3, getSettings().rate))
      let failed = false
      const fail = async (error?: { name?: string }) => {
        if (failed || activeRequest !== request) return
        failed = true
        player.onerror = null
        player.onended = null
        if (error?.name === 'NotAllowedError') {
          onError(
            automatic ? '手机浏览器限制自动播放，请点击“听发音”开启声音。' : '浏览器未允许播放，请再次点击“听发音”。'
          )
        } else if (fallback) {
          await fallback()
        } else {
          onError('在线日语发音暂时无法播放，请检查网络并再次点击“听发音”。')
        }
      }
      player.onerror = () => {
        void fail()
      }
      player.onended = () => {
        if (!failed && activeRequest === request) next?.()
      }
      const timer = setTimeout(() => {
        void fail({ name: 'TimeoutError' })
      }, 12000)
      loadTimer = timer
      try {
        await player.play()
      } catch (error) {
        await fail(error as { name?: string })
      } finally {
        clearTimeout(timer)
      }
    }

    let originalOnlineSource: 'youdao' | 'google' = 'youdao'
    function playOnline(index = 0): Promise<void> {
      const source =
        originalOnlineSource === 'youdao'
          ? getJapaneseOnlineAudioURL(chunks[index]!)
          : `https://translate.google.com/translate_tts?${new URLSearchParams({ ie: 'UTF-8', client: 'tw-ob', tl: 'ja', q: chunks[index]! })}`
      return playSource(
        source,
        index + 1 < chunks.length
          ? () => {
              void playOnline(index + 1)
            }
          : undefined,
        originalOnlineSource === 'youdao'
          ? async () => {
              originalOnlineSource = 'google'
              await playOnline(index)
            }
          : undefined
      )
    }

    async function playOriginal() {
      const path = getJapaneseAudioPath(text, reading)
      if (path) {
        await playSource(withAppBaseURL(path), undefined, () => playOnline())
        return
      }

      const synth = 'speechSynthesis' in window ? window.speechSynthesis : null
      const voice = synth?.getVoices().find(item => /^ja(?:-|_)/i.test(item.lang))
      // Do not wait for voiceschanged here: the first play must retain the user's tap.
      if (!synth || !voice || typeof SpeechSynthesisUtterance === 'undefined') {
        await playOnline()
        return
      }
      const utterance = new SpeechSynthesisUtterance((reading || text).replace(/[～〜~]/g, '').trim())
      utterance.lang = 'ja-JP'
      utterance.voice = voice
      utterance.rate = Math.max(0.25, Math.min(3, getSettings().rate))
      utterance.volume = Math.max(0, Math.min(1, getSettings().volume))
      utterance.onerror = event => {
        if (activeRequest === request && !['interrupted', 'canceled'].includes(event.error)) void playOnline()
      }
      try {
        synth.speak(utterance)
      } catch {
        await playOnline()
      }
    }

    const selectedVoice = getSettings().voice
    if (isJapaneseVoice(selectedVoice)) {
      const playMicrosoft = (index = 0): Promise<void> =>
        playSource(
          getMicrosoftJapaneseAudioURL(chunks[index]!, selectedVoice),
          index + 1 < chunks.length
            ? () => {
                void playMicrosoft(index + 1)
              }
            : undefined,
          async () => {
            if (activeRequest !== request) return
            onError('微软音源暂不可用，已自动使用原有发音。')
            await playOriginal()
          }
        )
      await playMicrosoft()
    } else {
      await playOriginal()
    }
  }
  return { speak, stop }
}
