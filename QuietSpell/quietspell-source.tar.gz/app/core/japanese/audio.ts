import manifest from './audio-manifest.json'
import { withAppBaseURL } from '../utils/base-url'

/** Static assets work on the website; native clients can reuse this manifest with their audio player. */
export function getJapaneseAudioPath(text: string): string | null {
  const file = (manifest as Record<string, string>)[text]
  return file ? `/audio/japanese/${file}` : null
}

export function createJapaneseSpeaker(
  onError: (message: string) => void,
  getSettings: () => { volume: number; rate: number } = () => ({ volume: 1, rate: 0.85 })
) {
  let audio: HTMLAudioElement | null = null
  let request = 0

  function stop() {
    request++
    if (audio) {
      audio.pause()
      audio.removeAttribute('src')
      audio.load()
      audio = null
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.cancel()
  }

  async function speak(text: string, automatic = false) {
    stop()
    const activeRequest = request
    const path = getJapaneseAudioPath(text)
    if (path) {
      const source =
        window.location.protocol === 'file:' && path.includes('/n3/')
          ? `https://fbyxdyn.github.io/QuietSpell${path}`
          : withAppBaseURL(path)
      const player = (audio = new Audio(source))
      player.volume = Math.max(0, Math.min(1, getSettings().volume))
      player.playbackRate = Math.max(0.25, Math.min(3, getSettings().rate))
      player.onerror = () => {
        if (activeRequest === request) onError('内置音频加载失败，请检查网络或部署文件。')
      }
      try {
        await player.play()
      } catch (error) {
        if (activeRequest === request && !(automatic && error instanceof Error && error.name === 'NotAllowedError'))
          onError('音频无法播放，请再次点击发音按钮。')
      }
      return
    }
    if (!('speechSynthesis' in window)) {
      onError('当前浏览器不支持自定义文章朗读。')
      return
    }
    const synth = window.speechSynthesis
    const findVoice = () => synth.getVoices().find(voice => /^ja(?:-|_)/i.test(voice.lang))
    let voice = findVoice()
    if (!voice) {
      // Voice discovery is asynchronous on some browsers. Do not overwrite onvoiceschanged.
      await new Promise<void>(resolve => {
        const done = () => {
          clearTimeout(timer)
          synth.removeEventListener('voiceschanged', done)
          resolve()
        }
        const timer = setTimeout(done, 1200)
        synth.addEventListener('voiceschanged', done)
      })
      if (activeRequest !== request) return
      voice = findVoice()
    }
    if (!voice) {
      onError('自定义文章需要设备日语语音。请在系统设置中安装日语语音，或使用内置课程音频。')
      return
    }
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = 'ja-JP'
    utterance.voice = voice
    utterance.rate = Math.max(0.25, Math.min(3, getSettings().rate))
    utterance.volume = Math.max(0, Math.min(1, getSettings().volume))
    utterance.onerror = event => {
      if (activeRequest === request && !['interrupted', 'canceled'].includes(event.error))
        onError('自定义文章朗读失败，请检查设备日语语音。')
    }
    synth.speak(utterance)
  }
  return { speak, stop }
}
