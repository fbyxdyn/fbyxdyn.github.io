import manifest from './audio-manifest.json'
import { withAppBaseURL } from '../utils/base-url'
import { isMicrosoftJapaneseVoice, type JapaneseVoice, type MicrosoftJapaneseVoice } from './voices'
import { createInlineAudioCache, INLINE_AUDIO_PRIMER } from './inline-audio'

export const JAPANESE_RELAY = 'https://quietspell-japanese-voice.wavy-cream-0113.chatgpt.site/speech'
export function getMicrosoftJapaneseAudioURL(text: string, voice: MicrosoftJapaneseVoice) {
  return `${JAPANESE_RELAY}?${new URLSearchParams({ text, voice })}`
}

const recordings = new Map(Object.entries(manifest))
const textsWithReadings = new Set(
  [...recordings.keys()].filter(key => key.includes('\0')).map(key => key.split('\0')[0])
)

/** Readings distinguish homographs such as 開く（あく／ひらく）. */
export function getJapaneseAudioPath(text: string, reading?: string): string | null {
  text = text.normalize('NFC').trim()
  reading = reading?.normalize('NFC').trim()
  const file = reading
    ? recordings.get(`${text}\0${reading}`) || (!textsWithReadings.has(text) ? recordings.get(text) : undefined)
    : recordings.get(text)
  return file ? `/audio/japanese/${file}` : null
}

/** Keep requests short and play all chunks, rather than silently truncating an article. */
export function splitJapaneseSpeech(text: string): string[] {
  const characters = Array.from(
    text
      .normalize('NFC')
      .replace(/[～〜~]/g, '')
      .trim()
  )
  const chunks: string[] = []
  while (characters.length) {
    let length = Math.min(100, characters.length)
    if (characters.length > length) {
      for (let i = length - 1; i >= 50; i--) {
        if (/[。！？!?、,；;\s]/u.test(characters[i]!)) {
          length = i + 1
          break
        }
      }
    }
    const chunk = characters.splice(0, length).join('').trim()
    if (chunk) chunks.push(chunk)
  }
  return chunks
}

export function getJapaneseOnlineAudioURL(text: string) {
  return `https://dict.youdao.com/dictvoice?audio=${encodeURIComponent(text)}&le=jap`
}

export type JapanesePlaybackStatus = 'idle' | 'loading' | 'playing' | 'ready' | 'error'
export interface JapanesePlaybackState {
  status: JapanesePlaybackStatus
  source: 'original' | 'microsoft'
}

export function createJapaneseSpeaker(
  onError: (message: string) => void,
  getSettings: () => { volume: number; rate: number; voice?: JapaneseVoice } = () => ({ volume: 1, rate: 0.85 }),
  onState: (state: JapanesePlaybackState) => void = () => {}
) {
  let audio: HTMLAudioElement | null = null
  let context: AudioContext | undefined
  let bufferSource: AudioBufferSourceNode | undefined
  let gain: GainNode | undefined
  let request = 0
  let attempt = 0
  let abortAttempt: (() => void) | undefined
  let objectURL: string | undefined
  let lastSpeech: { text: string; reading?: string } | undefined
  const inlineCache = createInlineAudioCache()
  const state = (status: JapanesePlaybackStatus, source: 'original' | 'microsoft') => onState({ status, source })

  function releaseMedia() {
    if (bufferSource) {
      bufferSource.onended = null
      try { bufferSource.stop() } catch { /* Already ended. */ }
      bufferSource.disconnect()
      bufferSource = undefined
    }
    gain?.disconnect()
    gain = undefined
    if (audio) {
      audio.onerror = null
      audio.onended = null
      audio.pause()
      audio.removeAttribute('src')
      audio.load()
    }
    if (objectURL) URL.revokeObjectURL(objectURL)
    objectURL = undefined
  }

  function stop() {
    request++
    attempt++
    abortAttempt?.()
    abortAttempt = undefined
    releaseMedia()
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.cancel()
    state('idle', 'original')
  }

  // Resume synchronously in the tap handler, before requesting or decoding audio.
  // Buffer playback avoids mobile browsers' external-media/download interception.
  function unlockContext(): Promise<boolean> {
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
      if (!AudioContextClass) return Promise.resolve(false)
      context ??= new AudioContextClass()
      if (context.state === 'running') return Promise.resolve(true)
      return context.resume().then(() => context?.state === 'running', () => false)
    } catch {
      return Promise.resolve(false)
    }
  }

  async function speak(text: string, automatic = false, reading?: string) {
    stop()
    lastSpeech = { text, reading }
    const activeRequest = request
    const chunks = splitJapaneseSpeech(reading || text)
    if (!chunks.length) return
    const selectedVoice = getSettings().voice
    const microsoft = isMicrosoftJapaneseVoice(selectedVoice)
    const contextReady = microsoft && (!automatic || context?.state === 'running') ? unlockContext() : Promise.resolve(false)
    const volume = () => Math.max(0, Math.min(1, getSettings().volume))
    const rate = () => Math.max(0.25, Math.min(3, getSettings().rate))

    async function playSource(source: string, next?: () => void, fallback?: () => Promise<void>, inline = false) {
      if (activeRequest !== request) return
      const activeAttempt = ++attempt
      const current = () => activeRequest === request && activeAttempt === attempt
      const sourceKind = inline ? 'microsoft' : 'original'
      state('loading', sourceKind)
      const controller = new AbortController()
      let failed = false
      let readyBlob = false
      let cancelWait: () => void
      const canceled = new Promise<void>(resolve => { cancelWait = resolve })
      const cancel = () => {
        controller.abort()
        cancelWait()
      }
      abortAttempt = cancel
      const ended = () => {
        if (current() && !failed) {
          releaseMedia()
          if (next) next()
          else state('idle', sourceKind)
        }
      }
      let timer: ReturnType<typeof setTimeout>
      const fail = async (error?: { name?: string }) => {
        if (failed || !current()) return
        failed = true
        clearTimeout(timer)
        cancel()
        releaseMedia()
        if (error?.name === 'NotAllowedError') {
          // A playback permission error is not a Microsoft outage. Keep the fetched
          // clip in memory so an explicit second tap can play it synchronously.
          state(readyBlob ? 'ready' : 'error', sourceKind)
          onError(readyBlob
            ? '语音已就绪，浏览器要求再次点击“播放已就绪语音”。'
            : automatic ? '手机浏览器限制自动播放，请点击“听发音”开启声音。' : '浏览器未允许播放，请再次点击“听发音”。')
        } else if (fallback) {
          if (inline) inlineCache.remove(source)
          await fallback()
        } else {
          state('error', sourceKind)
          onError('在线日语发音暂时无法播放，请检查网络并再次点击“听发音”。')
        }
      }
      // Cancellation settles even if a browser's play/resume/decode promise hangs.
      timer = setTimeout(() => { void fail({ name: 'TimeoutError' }) }, 12000)
      async function play() {
        let blob = inline ? inlineCache.get(source) : undefined
        if (inline) {
          if (!blob) {
            // For browsers without Web Audio, unlock the reusable media element
            // now; do not wait for its primer promise to resolve before fetching.
            if (!context && !automatic) {
              const player = (audio ??= new Audio())
              player.src = INLINE_AUDIO_PRIMER
              void player.play().catch(() => {})
            }
            blob = await inlineCache.load(source, controller.signal)
          }
          if (!current() || failed) return
          readyBlob = true
          if (context && await contextReady) {
            try {
              const buffer = await context.decodeAudioData(await blob.arrayBuffer())
              if (!current() || failed) return
              const node = context.createBufferSource()
              gain = context.createGain()
              gain.gain.value = volume()
              node.buffer = buffer
              node.playbackRate.value = rate()
              node.connect(gain)
              gain.connect(context.destination)
              bufferSource = node
              node.onended = ended
              node.start()
              clearTimeout(timer)
              state('playing', sourceKind)
              return
            } catch {
              if (!current() || failed) return
              // Older webviews may lack MP3 decoding; use the in-page Blob player.
            }
          }
        }
        if (!current() || failed) return
        const player = (audio ??= new Audio())
        player.preload = 'auto'
        player.setAttribute?.('playsinline', '')
        player.setAttribute?.('webkit-playsinline', '')
        player.volume = volume()
        player.playbackRate = rate()
        if (blob) {
          if (objectURL) URL.revokeObjectURL(objectURL)
          objectURL = URL.createObjectURL(blob)
          player.src = objectURL
        } else player.src = source
        player.onerror = () => { void fail() }
        player.onended = ended
        await player.play()
        if (!current() || failed) return
        clearTimeout(timer)
        state('playing', sourceKind)
      }
      try {
        await Promise.race([play().catch(error => fail(error)), canceled])
      } finally {
        if (abortAttempt === cancel && !failed) abortAttempt = undefined
        // A canceled request must not clear a newer request's timer or state.
        if (!current() || failed) clearTimeout(timer)
      }
    }

    let originalOnlineSource: 'youdao' | 'google' = 'youdao'
    function playOnline(index = 0): Promise<void> {
      const source = originalOnlineSource === 'youdao'
        ? getJapaneseOnlineAudioURL(chunks[index]!)
        : `https://translate.google.com/translate_tts?${new URLSearchParams({ ie: 'UTF-8', client: 'tw-ob', tl: 'ja', q: chunks[index]! })}`
      return playSource(source, index + 1 < chunks.length ? () => { void playOnline(index + 1) } : undefined,
        originalOnlineSource === 'youdao' ? async () => { originalOnlineSource = 'google'; await playOnline(index) } : undefined)
    }

    async function playOriginal() {
      if (activeRequest !== request) return
      const path = getJapaneseAudioPath(text, reading)
      if (path) {
        await playSource(withAppBaseURL(path), undefined, () => playOnline())
        return
      }
      const synth = 'speechSynthesis' in window ? window.speechSynthesis : null
      const voice = synth?.getVoices().find(item => /^ja(?:-|_)/i.test(item.lang))
      if (!synth || !voice || typeof SpeechSynthesisUtterance === 'undefined') {
        await playOnline()
        return
      }
      const utterance = new SpeechSynthesisUtterance((reading || text).replace(/[～〜~]/g, '').trim())
      utterance.lang = 'ja-JP'
      utterance.voice = voice
      utterance.rate = rate()
      utterance.volume = volume()
      utterance.onend = () => { if (activeRequest === request) state('idle', 'original') }
      utterance.onerror = event => {
        if (activeRequest === request && !['interrupted', 'canceled'].includes(event.error)) void playOnline()
      }
      try {
        synth.speak(utterance)
        state('playing', 'original')
      } catch { await playOnline() }
    }

    if (microsoft) {
      const playMicrosoft = (index = 0): Promise<void> =>
        playSource(getMicrosoftJapaneseAudioURL(chunks[index]!, selectedVoice),
          index + 1 < chunks.length ? () => { void playMicrosoft(index + 1) } : undefined,
          async () => {
            if (activeRequest !== request) return
            onError('微软音源暂不可用，已自动使用原有发音。')
            await playOriginal()
          }, true)
      await playMicrosoft()
    } else await playOriginal()
  }

  function retry() {
    if (lastSpeech) return speak(lastSpeech.text, false, lastSpeech.reading)
  }
  function dispose() {
    stop()
    void context?.close().catch(() => {})
    context = undefined
  }
  return { speak, stop, retry, dispose }
}
