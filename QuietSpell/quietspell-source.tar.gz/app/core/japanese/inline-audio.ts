// A short silent WAV primes this audio element inside an explicit user gesture.
export const INLINE_AUDIO_PRIMER =
  'data:audio/wav;base64,UklGRsQAAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'

/** Small, memory-only cache. No downloads, IndexedDB, files or persistent storage. */
export function createInlineAudioCache(limit = 12) {
  const clips = new Map<string, Blob>()
  function get(source: string) {
    const cached = clips.get(source)
    if (cached) {
      clips.delete(source)
      clips.set(source, cached)
    }
    return cached
  }
  return {
    get,
    remove(source: string) { clips.delete(source) },
    async load(source: string, signal: AbortSignal): Promise<Blob> {
      if (signal.aborted) throw new DOMException('Canceled', 'AbortError')
      const cached = get(source)
      if (cached) return cached
      const response = await fetch(source, { signal, credentials: 'omit', cache: 'no-store' })
      if (!response.ok || !response.headers.get('Content-Type')?.toLowerCase().startsWith('audio/'))
        throw new Error('Voice request did not return audio.')
      const blob = await response.blob()
      if (blob.size < 256 || signal.aborted) throw new Error('Voice response was empty or canceled.')
      clips.set(source, blob)
      while (clips.size > limit) clips.delete(clips.keys().next().value!)
      return blob
    },
  }
}
