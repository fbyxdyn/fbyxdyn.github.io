import highFrequency from './books/n3-pdf-0.json'
import coreVocabulary from './books/n3-pdf-1.json'
import grammarExamples from './books/n3-pdf-2.json'
import listeningExpressions from './books/n3-pdf-3.json'
import type { JapaneseLesson } from './content'
import supplements from './books/n3-enrichment.json'
import kanzenSupplements from './books/n3-kanzen-enrichment.json'
import { createJapaneseDetailsIndex, enrichJapaneseEntry, type JapaneseSupplement } from './details'

const details = createJapaneseDetailsIndex(supplements as JapaneseSupplement[])
const kanzenDetails = createJapaneseDetailsIndex(kanzenSupplements as JapaneseSupplement[])
export const N3_BOOKS: JapaneseLesson[] = (
  [highFrequency, coreVocabulary, grammarExamples, listeningExpressions] as JapaneseLesson[]
).map(book => ({
  ...book,
  entries: book.entries.map(entry =>
    enrichJapaneseEntry(entry, book.id === highFrequency.id ? kanzenDetails : details)
  ),
}))
