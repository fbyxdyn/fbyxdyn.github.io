export const JAPANESE_VOICES = [
  { id: 'original', label: '原始语音 · 内置优先 / 实时补充' },
  { id: 'ja-JP-NanamiNeural', label: '微软 Nanami · 女声' },
  { id: 'ja-JP-KeitaNeural', label: '微软 Keita · 男声' },
] as const
export type JapaneseVoice = (typeof JAPANESE_VOICES)[number]['id']
export const DEFAULT_JAPANESE_VOICE: JapaneseVoice = 'ja-JP-NanamiNeural'
export function isJapaneseVoice(value: unknown): value is JapaneseVoice {
  return JAPANESE_VOICES.some(voice => voice.id === value)
}
export type MicrosoftJapaneseVoice = Exclude<JapaneseVoice, 'original'>
export function isMicrosoftJapaneseVoice(value: unknown): value is MicrosoftJapaneseVoice {
  return value === 'ja-JP-NanamiNeural' || value === 'ja-JP-KeitaNeural'
}
