import type { JapaneseEntry, JapaneseExpression } from './content'

export interface ParsedJapaneseWordbook {
  title: string
  entries: JapaneseEntry[]
}

function text(value: unknown, maxLength: number, field: string): string {
  if (value == null) return ''
  if (typeof value !== 'string' && typeof value !== 'number') throw new Error(`${field}必须是文字。`)
  const result = String(value).trim().normalize('NFC')
  if (result.length > maxLength) throw new Error(`${field}内容过长（最多 ${maxLength} 字）。`)
  return result
}

function pick(row: Record<string, unknown>, keys: string[]): unknown {
  for (const key of keys) if (Object.hasOwn(row, key) && row[key] !== '' && row[key] != null) return row[key]
  return ''
}

function list(value: unknown, field: string, limit = 30): unknown[] {
  if (value == null || value === '') return []
  if (typeof value === 'string') {
    try {
      value = JSON.parse(value)
    } catch {
      throw new Error(`${field}请使用 JSON 数组。`)
    }
  }
  if (!Array.isArray(value)) throw new Error(`${field}必须是数组。`)
  if (value.length > limit) throw new Error(`${field}最多支持 ${limit} 条。`)
  return value
}

function expressions(value: unknown, field: string): JapaneseExpression[] {
  return list(value, field).map(item => {
    if (!item || typeof item !== 'object' || Array.isArray(item)) throw new Error(`${field}中的每项需要包含 text。`)
    const row = item as Record<string, unknown>
    const content = text(pick(row, ['text', 'c', 'word', '表达', '日文']), 2000, field)
    if (!content) throw new Error(`${field}中的日文不能为空。`)
    const note = text(pick(row, ['note', '用法区别']), 2000, '用法区别')
    return {
      text: content,
      reading: text(pick(row, ['reading', 'kana', '读音']), 2000, '读音'),
      meaning: text(pick(row, ['meaning', 'cn', 'translation', '释义', '翻译']), 2000, '释义'),
      ...(note ? { note } : {}),
    }
  })
}

export function parseJapaneseWordbookRows(rows: unknown[], title = '我的日语词书'): ParsedJapaneseWordbook {
  if (!rows.length) throw new Error('词书中没有单词。')
  if (rows.length > 3000) throw new Error('每本词书最多支持 3,000 个词条。')
  const entries: JapaneseEntry[] = []
  const seen = new Set<string>()
  rows.forEach((value, index) => {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(`第 ${index + 1} 行格式错误。`)
    const row = value as Record<string, unknown>
    const word = text(pick(row, ['word', 'text', '单词', '日语']), 200, '单词')
    if (!word) throw new Error(`第 ${index + 1} 行缺少单词，请使用“单词”或 word 列。`)
    if (!/[\u3040-\u30ff\u3400-\u9fff]/.test(word)) throw new Error(`第 ${index + 1} 行不含日语文字。`)
    let reading = text(pick(row, ['reading', 'kana', '假名', '读音']), 400, '假名')
    if (!reading && /^[\u3040-\u30ff\s。、！？]+$/.test(word)) reading = word
    if (reading && !/^[\u3040-\u30ff\s。、！？]+$/.test(reading.normalize('NFKC')))
      throw new Error(`第 ${index + 1} 行的读音请填写平假名或片假名。`)
    let translation = pick(row, ['meaning', 'translation', '释义', '中文'])
    if (!translation && Array.isArray(row.trans))
      translation = row.trans
        .map(item => (typeof item?.cn === 'string' ? item.cn : ''))
        .filter(Boolean)
        .join('；')
    const meaning = text(translation, 1000, '释义')
    const sourceExample = pick(row, ['example', 'sentence', '例句'])
    const nestedExample =
      sourceExample && typeof sourceExample === 'object' && !Array.isArray(sourceExample)
        ? (sourceExample as Record<string, unknown>)
        : null
    const exampleText = text(nestedExample?.text ?? sourceExample, 2000, '例句')
    const exampleReading = text(nestedExample?.reading ?? pick(row, ['exampleReading', '例句读音']), 2000, '例句读音')
    const exampleMeaning = text(nestedExample?.meaning ?? pick(row, ['exampleMeaning', '例句翻译']), 2000, '例句翻译')
    const partOfSpeech = text(pick(row, ['partOfSpeech', 'pos', '词性']), 100, '词性')
    const examples = expressions(pick(row, ['examples', 'sentences', '例句列表']), '例句列表')
    const phrases = expressions(pick(row, ['phrases', '搭配列表', '短语列表']), '搭配列表')
    const synonyms = expressions(pick(row, ['synonyms', '近义表达']), '近义表达')
    const similarSounds = expressions(pick(row, ['similarSounds', '近音词']), '近音词')
    const senses = list(pick(row, ['senses', '词义列表']), '词义列表', 20).map(item => {
      if (!item || typeof item !== 'object' || Array.isArray(item))
        throw new Error('词义列表中的每项需要包含 meaning。')
      const value = item as Record<string, unknown>
      const senseMeaning = text(pick(value, ['meaning', 'cn', '释义']), 1000, '词义')
      if (!senseMeaning) throw new Error('词义不能为空。')
      const pos = text(pick(value, ['partOfSpeech', 'pos', '词性']), 100, '词性')
      const note = text(pick(value, ['note', '说明']), 2000, '词义说明')
      return { meaning: senseMeaning, ...(pos ? { partOfSpeech: pos } : {}), ...(note ? { note } : {}) }
    })
    const usage = text(pick(row, ['usage', '用法提示']), 3000, '用法提示')
    const detailsSource = text(pick(row, ['detailsSource', '补充来源']), 1000, '补充来源')
    const key = `${word}\0${reading}`
    if (seen.has(key)) return
    seen.add(key)
    entries.push({
      id: `word-${entries.length}`,
      text: word,
      reading,
      meaning,
      ...(exampleText ? { example: { text: exampleText, reading: exampleReading, meaning: exampleMeaning } } : {}),
      ...(partOfSpeech ? { partOfSpeech } : {}),
      ...(senses.length ? { senses } : {}),
      ...(examples.length ? { examples } : {}),
      ...(phrases.length ? { phrases } : {}),
      ...(synonyms.length ? { synonyms } : {}),
      ...(similarSounds.length ? { similarSounds } : {}),
      ...(usage ? { usage } : {}),
      ...(detailsSource ? { detailsSource } : {}),
    })
  })
  return { title: text(title, 80, '词书名称') || '我的日语词书', entries }
}

/** RFC-style quoted fields, including commas and line breaks inside example sentences. */
export function parseWordbookDelimited(source: string): Record<string, string>[] {
  const content = source.replace(/^\uFEFF/, '')
  const delimiter = content.split(/\r?\n/, 1)[0].includes('\t') ? '\t' : ','
  const rows: string[][] = []
  let row: string[] = [],
    value = '',
    quoted = false
  for (let index = 0; index < content.length; index++) {
    const character = content[index]
    if (character === '"') {
      if (quoted && content[index + 1] === '"') {
        value += '"'
        index++
      } else quoted = !quoted
    } else if (!quoted && (character === delimiter || character === '\n' || character === '\r')) {
      row.push(value)
      value = ''
      if (character !== delimiter) {
        if (row.some(cell => cell.trim())) rows.push(row)
        row = []
        if (character === '\r' && content[index + 1] === '\n') index++
      }
    } else value += character
  }
  if (quoted) throw new Error('CSV 引号未闭合，请检查例句中的引号。')
  row.push(value)
  if (row.some(cell => cell.trim())) rows.push(row)
  const headers = rows.shift()?.map(header => header.trim()) ?? []
  if (!headers.some(header => ['word', 'text', '单词', '日语'].includes(header)))
    throw new Error('首行需要包含“单词”或 word 列；请先下载模板。')
  return rows.map(cells => Object.fromEntries(headers.map((header, index) => [header, cells[index] ?? ''])))
}

export function parseJapaneseWordbookText(source: string, title = '我的日语词书'): ParsedJapaneseWordbook {
  if (source.length > 2_000_000) throw new Error('词书请控制在 2 MB 以内。')
  const content = source.trim().replace(/^\uFEFF/, '')
  if (content.startsWith('[') || content.startsWith('{')) {
    let data: unknown
    try {
      data = JSON.parse(content)
    } catch {
      throw new Error('JSON 格式错误，请检查括号和逗号。')
    }
    if (Array.isArray(data)) return parseJapaneseWordbookRows(data, title)
    if (!data || typeof data !== 'object') throw new Error('JSON 需要是词条数组或包含 words 的对象。')
    const book = data as Record<string, unknown>
    const rows = book.words ?? book.entries
    if (!Array.isArray(rows)) throw new Error('JSON 词书需要包含 words 或 entries 数组。')
    return parseJapaneseWordbookRows(rows, text(book.title ?? book.name ?? title, 80, '词书名称'))
  }
  return parseJapaneseWordbookRows(parseWordbookDelimited(content), title)
}
