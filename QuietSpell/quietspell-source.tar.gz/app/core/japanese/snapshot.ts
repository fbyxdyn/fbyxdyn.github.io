import type { Card } from 'ts-fsrs'
import type { JapaneseLesson } from './content'
import { createCustomArticle } from './input'
import { defaultJapaneseSettings, type JapaneseSession, type JapaneseSharedSettings } from './learning'
import { isJapaneseVoice, type JapaneseVoice } from './voices'
import { parseJapaneseWordbookRows } from './wordbook'

export const JAPANESE_STORAGE_KEY = 'typewords-japanese-practice-v1'
export const JAPANESE_BACKUP_KEY = 'quietspell-japanese-before-download-v1'
export const MAX_SNAPSHOT_BYTES = 8 * 1024 * 1024

export interface LessonProgress {
  index: number
  mastered: string[]
  mistakes: string[]
  correct: number
  attempts: number
  daily: number
  cards: Record<string, Card>
}
export interface JapaneseSnapshot {
  version: 1
  preferencesVersion: 2
  lessonId: string
  inputMode: 'romaji' | 'japanese'
  practiceMode: 'system' | 'free' | 'identify' | 'listen' | 'recall'
  progress: Record<string, LessonProgress>
  customText: string
  wordbooks: JapaneseLesson[]
  settings: JapaneseSharedSettings
  voice: JapaneseVoice
  session: JapaneseSession | null
  finished: boolean
}
const modes = ['system', 'free', 'identify', 'listen', 'recall']
const stages = ['follow', 'identify', 'listen', 'recall']
function invalid(): never { throw new Error('学习数据格式无效或与当前版本不兼容，本机数据未被替换。') }
function record(value: unknown): Record<string, any> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) invalid()
  if (Object.keys(value).some(key => ['__proto__', 'constructor', 'prototype'].includes(key))) invalid()
  return value as Record<string, any>
}
function count(value: unknown, max = Number.MAX_SAFE_INTEGER): number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0 || value > max) invalid()
  return value
}
function number(value: unknown, min: number, max: number): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max) invalid()
  return value
}
function date(value: unknown): Date {
  if ((typeof value !== 'string' && !(value instanceof Date)) || !Number.isFinite(new Date(value).getTime())) invalid()
  return new Date(value)
}
function ids(value: unknown, valid: Set<string>): string[] {
  if (!Array.isArray(value) || value.length > valid.size || value.some(id => typeof id !== 'string' || !valid.has(id))) invalid()
  return [...new Set(value)]
}
function card(value: unknown): Card {
  const c = record(value)
  return {
    due: date(c.due), stability: number(c.stability, 0, Number.MAX_SAFE_INTEGER),
    difficulty: number(c.difficulty, 0, 10), elapsed_days: count(c.elapsed_days),
    scheduled_days: count(c.scheduled_days), reps: count(c.reps), lapses: count(c.lapses),
    learning_steps: count(c.learning_steps ?? 0), state: count(c.state, 3),
    ...(c.last_review != null ? { last_review: date(c.last_review) } : {}),
  }
}

/** Validate the entire restore before writing storage or changing reactive state. */
export function parseJapaneseSnapshot(value: unknown, builtIns: JapaneseLesson[]): JapaneseSnapshot {
  const s = record(value)
  if (s.version !== 1 || s.preferencesVersion !== 2 || !isJapaneseVoice(s.voice) ||
      !['japanese', 'romaji'].includes(s.inputMode) || !modes.includes(s.practiceMode) ||
      typeof s.customText !== 'string' || typeof s.finished !== 'boolean' ||
      !Array.isArray(s.wordbooks) || s.wordbooks.length > 10) invalid()
  const seen = new Set<string>()
  const wordbooks: JapaneseLesson[] = s.wordbooks.map(item => {
    const b = record(item)
    if (typeof b.id !== 'string' || !/^wordbook-[a-f\d-]{36}$/.test(b.id) || seen.has(b.id) ||
        typeof b.title !== 'string' || !Array.isArray(b.entries)) invalid()
    seen.add(b.id)
    const parsed = parseJapaneseWordbookRows(b.entries, b.title)
    if (parsed.entries.length !== b.entries.length || parsed.entries.some((entry, i) => entry.id !== b.entries[i].id)) invalid()
    return { id: b.id, title: parsed.title, description: `我的词书 · ${parsed.entries.length} 个词条`, kind: 'words', entries: parsed.entries }
  })
  const custom = s.customText.trim() ? createCustomArticle(s.customText) : []
  const lessons = [...builtIns, ...wordbooks, ...(custom.length ? [{ id: 'custom', entries: custom }] : [])]
  const byLesson = new Map(lessons.map(lesson => [lesson.id, lesson.entries]))
  if (typeof s.lessonId !== 'string' || !byLesson.has(s.lessonId)) invalid()
  const progress = Object.fromEntries(Object.entries(record(s.progress)).map(([id, value]) => {
    const entries = byLesson.get(id)
    if (!entries) throw new Error('云端含有当前版本未提供的课程，请更新网页后再下载。本机数据未被替换。')
    const valid = new Set(entries.map(entry => entry.id)), p = record(value)
    const attempts = count(p.attempts), correct = count(p.correct, attempts)
    const cards = Object.fromEntries(Object.entries(record(p.cards)).map(([id, value]) => {
      if (!valid.has(id)) invalid()
      return [id, card(value)]
    }))
    return [id, { index: count(p.index, entries.length), daily: number(p.daily, 1, 500),
      mastered: ids(p.mastered, valid), mistakes: ids(p.mistakes, valid), attempts, correct, cards }]
  }))
  const settings = defaultJapaneseSettings() as JapaneseSharedSettings & Record<string, any>, prefs = record(s.settings)
  const ranges: Record<string, [number, number]> = {
    wordReviewRatio: [0, 10], repeatCount: [1, 100], repeatCustomCount: [1, 15],
    waitTimeForChangeWord: [0, 10000], wordSoundVolume: [0, 100], wordSoundSpeed: [0.25, 3],
    fsrsEasyLimit: [0, 1000], fsrsGoodLimit: [0, 1000], fsrsHardLimit: [0, 1000],
  }
  for (const [key, initial] of Object.entries(settings)) {
    if (typeof initial === 'boolean') {
      if (typeof prefs[key] !== 'boolean') invalid()
      settings[key] = prefs[key]
    } else settings[key] = number(prefs[key], ...ranges[key]!)
  }
  for (const key of ['repeatCustomCount', 'fsrsEasyLimit', 'fsrsGoodLimit', 'fsrsHardLimit'])
    if (prefs[key] !== undefined) settings[key] = number(prefs[key], ...ranges[key]!)
  if (prefs.autoAddRandomReviewWhenNoDue !== undefined) {
    if (typeof prefs.autoAddRandomReviewWhenNoDue !== 'boolean') invalid()
    settings.autoAddRandomReviewWhenNoDue = prefs.autoAddRandomReviewWhenNoDue
  }
  // FSRS parameters contain only numeric/boolean scalars and the numeric weights.
  if (prefs.fsrsParameters !== undefined) {
    settings.fsrsParameters = Object.fromEntries(Object.entries(record(prefs.fsrsParameters)).map(([key, value]) => {
      if (key === 'w' && Array.isArray(value) && value.length <= 100 && value.every(v => typeof v === 'number' && Number.isFinite(v))) return [key, [...value]]
      if (typeof value === 'boolean' || (typeof value === 'number' && Number.isFinite(value))) return [key, value]
      invalid()
    }))
  }
  let session: JapaneseSession | null = null
  if (s.session != null) {
    const v = record(s.session), valid = new Set(byLesson.get(s.lessonId)!.map(entry => entry.id))
    if (v.lessonId !== s.lessonId || v.mode !== s.practiceMode || !Array.isArray(v.tasks) || v.tasks.length > 20000) invalid()
    const tasks = v.tasks.map(item => {
      const t = record(item)
      if (!valid.has(t.entryId) || !stages.includes(t.stage) || typeof t.review !== 'boolean') invalid()
      return { entryId: t.entryId, stage: t.stage, review: t.review }
    })
    const wrong = Object.fromEntries(Object.entries(record(v.wrong)).map(([id, value]) => {
      if (!valid.has(id)) invalid()
      return [id, count(value)]
    }))
    session = { lessonId: s.lessonId, mode: s.practiceMode, tasks,
      position: count(v.position, Math.max(0, tasks.length - 1)), repetition: count(v.repetition, 15),
      newCount: count(v.newCount, 500), reviewCount: count(v.reviewCount, 5000), wrong }
  }
  return { version: 1, preferencesVersion: 2, lessonId: s.lessonId, inputMode: s.inputMode,
    practiceMode: s.practiceMode, progress, customText: s.customText, wordbooks, settings,
    voice: s.voice, session, finished: s.finished }
}
