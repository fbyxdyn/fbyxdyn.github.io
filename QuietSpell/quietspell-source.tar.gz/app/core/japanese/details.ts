import type { JapaneseEntry, JapaneseExample } from './content'

export type JapaneseSupplement = Pick<JapaneseEntry, 'text' | 'reading'> &
  Partial<
    Pick<JapaneseEntry, 'partOfSpeech' | 'senses' | 'examples' | 'phrases' | 'synonyms' | 'usage' | 'detailsSource'>
  >

const key = (text: string, reading: string) => `${text.normalize('NFKC').trim()}\0${reading.normalize('NFKC').trim()}`

export function createJapaneseDetailsIndex(supplements: JapaneseSupplement[]) {
  return new Map(supplements.map(item => [key(item.text, item.reading), item]))
}

/** Supplementary teaching content never replaces the original word, reading, source or progress ID. */
export function enrichJapaneseEntry(
  entry: JapaneseEntry,
  supplements: JapaneseSupplement[] | Map<string, JapaneseSupplement>
): JapaneseEntry {
  const index = Array.isArray(supplements) ? createJapaneseDetailsIndex(supplements) : supplements
  const extra = index.get(key(entry.text, entry.reading))
  if (!extra) return entry
  const { text, reading, ...details } = extra
  return {
    ...details,
    ...entry,
    ...Object.fromEntries(Object.entries(details).filter(([field]) => entry[field] == null)),
  }
}

export function getJapaneseExamples(entry: JapaneseEntry): JapaneseExample[] {
  const seen = new Set<string>()
  return [entry.example, ...(entry.examples ?? [])].filter((item): item is JapaneseExample => {
    if (!item?.text.trim()) return false
    const id = item.text.normalize('NFKC').replace(/\s/g, '')
    if (seen.has(id)) return false
    seen.add(id)
    return true
  })
}
