export class JapaneseSyncError extends Error {
  constructor(message: string, public status = 0, public code = 'network_error') { super(message) }
}
export interface CloudSnapshot {
  ok: true
  userId: string
  sha: string
  updatedAt: string
  snapshot: unknown
}
export const DEFAULT_JAPANESE_SYNC_ENDPOINT = 'https://env-00jy732183w8.dev-hz.cloudbasefunction.cn/quietspell'
export const MAX_JAPANESE_SYNC_BYTES = 2 * 1024 * 1024
export function getJapaneseSyncEndpoint(): string {
  const runtime = (globalThis as any).__NUXT__?.config?.public?.japaneseSyncEndpoint
  return typeof runtime === 'string' && runtime ? runtime : import.meta.env?.VITE_JAPANESE_SYNC_ENDPOINT || DEFAULT_JAPANESE_SYNC_ENDPOINT
}
export function createJapaneseSyncClient(endpoint = getJapaneseSyncEndpoint(), request: typeof fetch = fetch) {
  async function post(action: 'upload' | 'download', userId: string, inviteCode: string, extra: Record<string, unknown> = {}, signal?: AbortSignal) {
    if (!endpoint) throw new JapaneseSyncError('同步服务尚未开通，请稍后再试。', 503, 'not_configured')
    const base = new URL(endpoint)
    if (base.protocol !== 'https:' && !(base.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(base.hostname)))
      throw new JapaneseSyncError('同步服务地址无效。')
    if (!userId.length) throw new JapaneseSyncError('请输入用户 ID。')
    if (!inviteCode.length) throw new JapaneseSyncError('请输入邀请码。')
    const body = JSON.stringify({ ...extra, userId, inviteCode })
    if (new TextEncoder().encode(body).length > MAX_JAPANESE_SYNC_BYTES)
      throw new JapaneseSyncError('数据超过单次同步大小，请减少导入内容后重试。', 413, 'too_large')
    let response: Response
    try {
      response = await request(`${endpoint.replace(/\/$/, '')}/sync/${action}`, {
        method: 'POST', mode: 'cors', credentials: 'omit', cache: 'no-store',
        headers: { 'Content-Type': 'application/json' }, body, signal,
      })
    } catch (error) {
      if (signal?.aborted) throw error
      throw new JapaneseSyncError('无法连接同步服务，请检查网络后重试。')
    }
    let result: any
    try { result = await response.json() } catch { throw new JapaneseSyncError('同步服务返回异常，请稍后重试。', response.status) }
    if (!response.ok || result?.ok !== true) {
      const messages: Record<number, string> = {
        401: '同步服务暂不可用，请联系站点维护者。', 403: '当前页面未获准连接同步服务，请使用正式网站重试。',
        404: '该用户 ID 还没有云端数据，请先上传。',
        409: '云端数据已变化，已停止上传。请先核对云端数据后重试。',
        413: '数据超过单次同步大小，请减少导入内容后重试。',
        429: '操作过于频繁，请稍后重试。', 503: '同步服务尚未配置完成，请稍后再试。',
      }
      const codes: Record<string, string> = {
        INVITE_INVALID: '邀请码不正确，无法上传或下载。',
        BUDGET_EXHAUSTED: '免费共享用量已达上限，暂时停止联网同步，请稍后再试。',
        BUDGET_BUSY: '同步服务繁忙，请稍后再试。',
        BUDGET_UNAVAILABLE: '用量保护暂不可用，已停止联网同步，请稍后再试。',
        SYNC_DISABLED: '同步服务尚未启用，请稍后再试。',
      }
      // Never display arbitrary upstream errors that could contain credentials.
      throw new JapaneseSyncError(codes[result?.error?.code] || messages[response.status] || '同步失败，请检查网络后重试。', response.status,
        typeof result?.error?.code === 'string' ? result.error.code : 'sync_error')
    }
    if (result.userId !== userId || typeof result.sha !== 'string' || !/^(?:[a-f\d]{40}|[a-f\d]{64})$/i.test(result.sha) ||
        typeof result.updatedAt !== 'string' || !Number.isFinite(new Date(result.updatedAt).getTime()))
      throw new JapaneseSyncError('同步数据身份或版本校验失败，本机数据未被替换。')
    return result as CloudSnapshot
  }
  return {
    download: (userId: string, inviteCode: string, signal?: AbortSignal) => post('download', userId, inviteCode, {}, signal),
    upload: (userId: string, inviteCode: string, snapshot: unknown, sha: string | null, signal?: AbortSignal) =>
      post('upload', userId, inviteCode, { snapshot, sha }, signal),
  }
}
