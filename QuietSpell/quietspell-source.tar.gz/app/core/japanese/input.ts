import type { JapaneseEntry } from './content'

const kanaMap: Record<string, string> = {}
const rows = [
  ['あいうえお', 'a i u e o'],
  ['かきくけこ', 'ka ki ku ke ko'],
  ['さしすせそ', 'sa shi su se so'],
  ['たちつてと', 'ta chi tsu te to'],
  ['なにぬねの', 'na ni nu ne no'],
  ['はひふへほ', 'ha hi fu he ho'],
  ['まみむめも', 'ma mi mu me mo'],
  ['やゆよ', 'ya yu yo'],
  ['らりるれろ', 'ra ri ru re ro'],
  ['わをん', 'wa wo n'],
  ['がぎぐげご', 'ga gi gu ge go'],
  ['ざじずぜぞ', 'za ji zu ze zo'],
  ['だぢづでど', 'da di du de do'],
  ['ばびぶべぼ', 'ba bi bu be bo'],
  ['ぱぴぷぺぽ', 'pa pi pu pe po'],
  ['ぁぃぅぇぉ', 'xa xi xu xe xo'],
  ['ゃゅょゎゔ', 'xya xyu xyo xwa vu'],
]
for (const [kana, romaji] of rows) {
  ;[...kana].forEach((character, index) => {
    kanaMap[character] = romaji.split(' ')[index]
  })
}
for (const [first, prefix] of Object.entries({
  き: 'ky',
  し: 'sh',
  ち: 'ch',
  に: 'ny',
  ひ: 'hy',
  み: 'my',
  り: 'ry',
  ぎ: 'gy',
  じ: 'j',
  び: 'by',
  ぴ: 'py',
})) {
  for (const [small, vowel] of [
    ['ゃ', 'a'],
    ['ゅ', 'u'],
    ['ょ', 'o'],
  ])
    kanaMap[first + small] = prefix + vowel
}
Object.assign(kanaMap, {
  ふぁ: 'fa',
  ふぃ: 'fi',
  ふぇ: 'fe',
  ふぉ: 'fo',
  てぃ: 'ti',
  でぃ: 'di',
  うぃ: 'wi',
  うぇ: 'we',
  うぉ: 'wo',
  しぇ: 'she',
  ちぇ: 'che',
  じぇ: 'je',
})

export function toHiragana(text: string): string {
  return text.normalize('NFKC').replace(/[ァ-ヶ]/g, character => String.fromCharCode(character.charCodeAt(0) - 0x60))
}

/** Kana spelling, not a phonetic transliteration: particles may override this in the lesson. */
export function kanaToRomaji(reading: string): string {
  const kana = [...toHiragana(reading)]
  let result = ''
  for (let index = 0; index < kana.length; index++) {
    const character = kana[index]
    if (character === 'っ') {
      const following = kanaMap[kana[index + 1]] ?? ''
      result += following.startsWith('ch') ? 't' : (following.match(/^[bcdfghjklmpqrstvwxyz]/)?.[0] ?? 'xtsu')
      continue
    }
    if (character === 'ー') {
      result += '-'
      continue
    }
    if (character === 'ん' && /^[aiueoy]/.test(kanaMap[kana[index + 1]] ?? '')) {
      result += "n'"
      continue
    }
    const pair = character + (kana[index + 1] ?? '')
    if (kanaMap[pair]) {
      result += kanaMap[pair]
      index++
    } else result += kanaMap[character] ?? character
  }
  return result.replace(/。/g, '.').replace(/、/g, ',')
}

export function normalizeRomaji(text: string): string {
  return text
    .normalize('NFKC')
    .toLowerCase()
    .replace(/’/g, "'")
    .replace(/[\s。、,.!?！？「」『』]/g, '')
    .replace(/shi/g, 'si')
    .replace(/chi/g, 'ti')
    .replace(/tsu/g, 'tu')
    .replace(/fu/g, 'hu')
    .replace(/sha/g, 'sya')
    .replace(/shu/g, 'syu')
    .replace(/sho/g, 'syo')
    .replace(/cha/g, 'tya')
    .replace(/chu/g, 'tyu')
    .replace(/cho/g, 'tyo')
    .replace(/jya|zya|ja/g, 'jya')
    .replace(/jyu|zyu|ju/g, 'jyu')
    .replace(/jyo|zyo|jo/g, 'jyo')
    .replace(/zi/g, 'ji')
}

function expandLongMarks(text: string): string {
  return text.replace(/([aiueo])-+/g, match => match[0].repeat(match.length))
}

function normalizeJapanese(text: string): string {
  return text.normalize('NFKC').replace(/[\s。、,.!?！？「」『』]/g, '')
}

export function getRomaji(entry: JapaneseEntry): string {
  return entry.romaji?.[0] ?? kanaToRomaji(entry.reading)
}

export function isJapaneseAnswerCorrect(input: string, entry: JapaneseEntry, mode: 'romaji' | 'japanese'): boolean {
  if (!input.trim()) return false
  if (mode === 'japanese') {
    // Keep the script distinction: ア is not a correct answer to an あ exercise.
    const actual = normalizeJapanese(input)
    return !!actual && [entry.text, entry.reading].some(answer => actual === normalizeJapanese(answer))
  }
  const actual = normalizeRomaji(input)
  return (entry.romaji?.length ? entry.romaji : [kanaToRomaji(entry.reading)]).some(answer => {
    const expected = normalizeRomaji(answer)
    const variants = [expected, expandLongMarks(expected)]
    // Accept IME-style "nn" as well as Hepburn n / n' for ん.
    const nVariants = variants.flatMap(value => [value, value.replace(/n'/g, 'nn').replace(/n$/g, 'nn')])
    return nVariants.includes(actual)
  })
}

/** Imported text has no inferred reading: Japanese IME input is required. */
export function createCustomArticle(text: string): JapaneseEntry[] {
  const normalized = text.trim().normalize('NFC')
  if (!/[\u3040-\u30ff\u3400-\u9fff]/.test(normalized)) throw new Error('请粘贴含有日语文字的文章。')
  if (normalized.length > 20000) throw new Error('文章请控制在 20,000 字以内。')
  return (normalized.match(/[^。！？\n]+[。！？]?/gu) ?? [])
    .map(sentence => sentence.trim())
    .filter(Boolean)
    .map((sentence, index) => ({ id: `custom-${index}`, text: sentence, reading: '', meaning: '' }))
}
