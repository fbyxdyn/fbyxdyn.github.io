<script setup lang="ts">
import JapanesePracticeView from '@/components/JapanesePracticeView.vue'
import { useSettingStore } from '@/core/stores/setting'
const runtimeConfig = useRuntimeConfig()
const settings = useSettingStore()
useSeoMeta({
  title: '日语学习 · QuietSpell',
  description: 'QuietSpell：安静练习日语假名、单词与例句。支持 N3 词书和个人词书导入。',
})
</script>
<template>
  <JapanesePracticeView :shared-settings="settings" :show-source-archive="runtimeConfig.public.sourceArchive" />
</template>
