<script setup lang="ts">
import { computed, nextTick, ref } from 'vue'
import JapaneseWordDetails from './JapaneseWordDetails.vue'
import { useJapanesePractice } from '@/composables/useJapanesePractice'
import { withAppBaseURL } from '@/core/utils/base-url'
import type { JapaneseSharedSettings } from '@/core/japanese/learning'
import {
  parseJapaneseWordbookRows,
  parseJapaneseWordbookText,
  type ParsedJapaneseWordbook,
} from '@/core/japanese/wordbook'

const props = withDefaults(
  defineProps<{ showSourceArchive?: boolean; nativeApp?: boolean; sharedSettings?: JapaneseSharedSettings }>(),
  {
    showSourceArchive: false,
    nativeApp: false,
  }
)

const {
  lessons,
  lesson,
  lessonId,
  canUseRomaji,
  inputMode,
  practiceMode,
  settings,
  daily,
  startIndex,
  session,
  stage,
  task,
  stageName,
  repetitions,
  beginSession,
  pause,
  assess,
  stats,
  entries,
  index,
  entry,
  romaji,
  showAnswer,
  accuracy,
  input,
  inputRef,
  result,
  revealed,
  skipped,
  finished,
  ready,
  message,
  storageMessage,
  reviewIds,
  customText,
  selectLesson,
  submit,
  next,
  skipSpelling,
  restart,
  jumpTo,
  importArticle,
  importWordbook,
  removeWordbook,
  speak,
  onKeydown,
  setComposing,
} = useJapanesePractice(props)
const showSettings = ref(false)
const settingsDialog = ref<HTMLDialogElement>()
function openSettings() {
  pause()
  showSettings.value = true
  void nextTick(() => settingsDialog.value?.showModal())
}
function closeSettings() {
  settingsDialog.value?.close()
  showSettings.value = false
}
function applySettings() {
  beginSession()
  closeSettings()
}
const showImport = ref(false)
const importDialog = ref<HTMLDialogElement>()
const showWordbookImport = ref(false)
const wordbookDialog = ref<HTMLDialogElement>()
const wordbookDraft = ref('')
const wordbookTitle = ref('我的日语词书')
const wordbookError = ref('')
const readingFile = ref(false)
const draft = ref('')
const groups = [
  { kind: 'kana', title: '01 / 假名基础' },
  { kind: 'words', title: '02 / 单词与例句' },
  { kind: 'n3', title: '03 / N3 词书与表达' },
  { kind: 'article', title: '04 / 逐句练习' },
]
const showKanaPrompt = computed(
  () => lesson.value.kind === 'kana' && stage.value !== 'listen' && inputMode.value === 'romaji'
)
const progressValue = computed(() => (finished.value ? entries.value.length : index.value))
const overviewPosition = computed(() =>
  Math.max(
    0,
    lesson.value.entries.findIndex(item => item.id === entry.value?.id)
  )
)
const overviewStart = computed(() => Math.floor(overviewPosition.value / 100) * 100)
const overviewEntries = computed(() => lesson.value.entries.slice(overviewStart.value, overviewStart.value + 100))
function changeOverviewGroup(event: Event) {
  const offset = Number((event.target as HTMLSelectElement).value) * 100
  if (lesson.value.entries[offset]) jumpTo(lesson.value.entries[offset].id)
}
function changeCourse(event: Event) {
  selectLesson((event.target as HTMLSelectElement).value)
}

function openImport() {
  message.value = ''
  draft.value = customText.value
  showImport.value = true
  void nextTick(() => importDialog.value?.showModal())
}
function closeImport() {
  importDialog.value?.close()
  showImport.value = false
}
function confirmImport() {
  if (importArticle(draft.value)) closeImport()
}

function openWordbookImport() {
  wordbookError.value = ''
  showWordbookImport.value = true
  void nextTick(() => wordbookDialog.value?.showModal())
}
function closeWordbookImport() {
  wordbookDialog.value?.close()
  showWordbookImport.value = false
}
function finishWordbookImport(book: ParsedJapaneseWordbook) {
  importWordbook(book)
  wordbookDraft.value = ''
  closeWordbookImport()
}
function importPastedWordbook() {
  try {
    finishWordbookImport(parseJapaneseWordbookText(wordbookDraft.value, wordbookTitle.value))
  } catch (error) {
    wordbookError.value = error instanceof Error ? error.message : '词书导入失败。'
  }
}
async function onWordbookFile(event: Event) {
  const picker = event.target as HTMLInputElement
  const file = picker.files?.[0]
  if (!file) return
  readingFile.value = true
  wordbookError.value = ''
  try {
    if (file.size > 2_000_000) throw new Error('词书文件请控制在 2 MB 以内。')
    const title = file.name.replace(/\.[^.]+$/, '').slice(0, 80)
    if (/\.xlsx?$/i.test(file.name)) {
      const XLSX = await import('xlsx')
      const workbook = XLSX.read(await file.arrayBuffer(), {
        type: 'array',
        sheetRows: 3002,
        cellFormula: false,
        cellHTML: false,
        sheets: 0,
      })
      if (!workbook.SheetNames[0]) throw new Error('Excel 文件中没有工作表。')
      finishWordbookImport(
        parseJapaneseWordbookRows(
          XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]], { defval: '' }),
          title
        )
      )
    } else if (/\.(csv|tsv|txt|json)$/i.test(file.name)) {
      finishWordbookImport(parseJapaneseWordbookText(await file.text(), title))
    } else throw new Error('请选择 Excel、CSV、TSV 或 JSON 词书文件。')
  } catch (error) {
    wordbookError.value = error instanceof Error ? error.message : '文件读取失败，请检查词书格式。'
  } finally {
    readingFile.value = false
    picker.value = ''
  }
}
</script>

<template>
  <main class="japanese-page">
    <header class="page-heading">
      <div>
        <p class="eyebrow">QUIETSPELL / 日本語</p>
        <h1>每一次输入，都更懂日语。</h1>
        <p class="muted">从五十音到第一篇短文，按自己的节奏练习。</p>
      </div>
      <div class="heading-actions">
        <a v-if="!props.nativeApp" :href="withAppBaseURL('/words')" class="subtle-button">英语学习</a>
        <button class="subtle-button" type="button" @click="openSettings">学习设置</button>
        <a href="https://fbyxdyn.github.io/" class="text-button">返回博客 ↗</a>
        <button class="subtle-button" type="button" @click="openWordbookImport">＋ 导入日语词书</button>
        <button class="subtle-button" type="button" @click="openImport">＋ 导入日语文章</button>
      </div>
    </header>
    <p v-if="props.nativeApp" class="muted">词书与学习进度可离线使用；基础音频已内置，N3 扩展音频需联网播放。</p>

    <p v-if="storageMessage" class="notice" role="status">{{ storageMessage }}</p>
    <p v-if="!ready" class="muted" role="status">正在读取学习进度…</p>
    <div v-if="ready" class="mobile-course-picker">
      <label for="mobile-japanese-course">选择日语词书或课程</label>
      <select id="mobile-japanese-course" :value="lessonId" @change="changeCourse">
        <optgroup v-for="group in groups" :key="group.kind" :label="group.title">
          <option
            v-for="item in lessons.filter(item =>
              group.kind === 'n3' ? !!item.sourceType : item.kind === group.kind && !item.sourceType
            )"
            :key="item.id"
            :value="item.id"
          >
            {{ item.title }}（{{ item.entries.length }} {{ item.kind === 'article' ? '句' : '项' }}）
          </option>
        </optgroup>
      </select>
    </div>
    <div v-if="ready" class="learning-grid">
      <aside class="lesson-sidebar" aria-label="选择日语课程">
        <section v-for="group in groups" :key="group.kind">
          <h2 class="group-title">{{ group.title }}</h2>
          <button
            v-for="item in lessons.filter(item =>
              group.kind === 'n3' ? !!item.sourceType : item.kind === group.kind && !item.sourceType
            )"
            :key="item.id"
            type="button"
            class="lesson-button"
            :class="{ selected: lessonId === item.id }"
            :aria-pressed="lessonId === item.id"
            @click="selectLesson(item.id)"
          >
            <span>{{ item.title }}</span>
            <small>{{ item.entries.length }} {{ item.kind === 'article' ? '句' : '项' }}</small>
          </button>
        </section>
        <p class="sidebar-note">进度自动保存在当前浏览器。内置内容附带音频；自定义文章使用设备日语朗读。</p>
        <section v-if="!props.nativeApp" class="english-library" aria-label="英语词书">
          <h2 class="group-title">英语词书</h2>
          <a :href="withAppBaseURL('/dict-list')" class="lesson-button"
            ><span>CET-4 · 大学英语四级</span><small>2,607 词</small></a
          >
          <a :href="withAppBaseURL('/words')" class="text-button">进入英语学习与复习</a>
        </section>
      </aside>

      <div class="workspace">
        <section class="practice-card" aria-labelledby="lesson-title">
          <div class="lesson-heading">
            <div>
              <h2 id="lesson-title">{{ lesson.title }}</h2>
              <p class="muted">{{ lesson.description }}</p>
            </div>
            <span class="count">{{ finished ? entries.length : index + 1 }} / {{ entries.length }}</span>
          </div>
          <progress :value="progressValue" :max="entries.length" aria-label="本轮练习进度"></progress>
          <div class="practice-controls">
            <label
              >输入方式
              <select v-model="inputMode" :disabled="!canUseRomaji">
                <option value="japanese">日文输入（假名 / 汉字）</option>
                <option value="romaji">罗马音辅助练习</option>
              </select>
            </label>
            <label
              >练习模式
              <select v-model="practiceMode">
                <option value="system">学习 · 跟写 → 听写 → 默写</option>
                <option value="free">自由跟写</option>
                <option value="identify">自测</option>
                <option value="listen">听写</option>
                <option value="recall">默写</option>
              </select>
            </label>
            <span v-if="reviewIds !== null" class="review-badge">错题复习</span>
            <button v-if="lessonId.startsWith('wordbook-')" class="text-button" type="button" @click="removeWordbook">
              移除此词书
            </button>
          </div>
          <div class="task-summary" aria-label="本轮学习计划">
            <span>新词 {{ session?.newCount ?? 0 }} · 复习 {{ session?.reviewCount ?? 0 }}</span>
            <span v-if="!finished"
              >{{ task?.review ? '复习' : '新词' }} · {{ stageName }} · 第 {{ (session?.repetition ?? 0) + 1 }} /
              {{ repetitions }} 次</span
            >
            <button type="button" class="text-button" @click="openSettings">调整计划</button>
          </div>

          <div v-if="finished" class="completion" role="status">
            <span class="completion-icon" aria-hidden="true">✓</span>
            <h3>{{ entries.length ? '这一轮完成了！' : '当前没有待练任务' }}</h3>
            <p class="muted">
              学习进度 {{ stats.index }} / {{ lesson.entries.length }}。可继续下一组，或调整学习进度重新练习。
            </p>
            <div class="actions">
              <button type="button" class="primary-button" @click="restart()">
                {{ stats.index >= lesson.entries.length ? '从头练习' : '开始下一组' }}
              </button>
              <button v-if="stats.mistakes.length" type="button" class="subtle-button" @click="restart(true)">
                复习错题（{{ stats.mistakes.length }}）
              </button>
            </div>
          </div>
          <div v-else-if="entry" class="typing-area">
            <p class="prompt-label">
              {{
                lesson.kind === 'kana'
                  ? '认识假名 · 记住读音'
                  : lesson.kind === 'article'
                    ? '一句一句，把日语写下来'
                    : '记住单词，也记住用法'
              }}
            </p>
            <p v-if="entry.label" class="grammar-point">语法点：{{ entry.label }}</p>
            <div class="target-text" lang="ja">
              <template v-if="showAnswer || showKanaPrompt">{{ entry.text }}</template>
              <template v-else-if="stage === 'listen'">听发音，输入日文</template>
              <template v-else-if="lesson.kind === 'kana'">{{ romaji }}</template>
              <template v-else>{{ entry.meaning || '听发音，输入这一句日语' }}</template>
            </div>
            <p v-if="showAnswer && entry.reading !== entry.text" class="reading" lang="ja">{{ entry.reading }}</p>
            <p
              v-if="
                showAnswer &&
                settings.translate &&
                (stage !== 'identify' || result === 'correct') &&
                entry.meaning &&
                lesson.kind !== 'kana'
              "
              class="meaning"
            >
              <span v-if="entry.partOfSpeech" class="word-part-of-speech">{{ entry.partOfSpeech }}</span
              >{{ entry.meaning }}
            </p>
            <p v-if="showAnswer && inputMode === 'romaji'" class="romaji">{{ romaji }}</p>
            <div class="actions pronunciation-actions">
              <button type="button" class="subtle-button" @click="speak()">
                ♪ {{ lesson.kind === 'article' ? '朗读本句' : '听发音' }}
              </button>
              <button v-if="!showAnswer" type="button" class="text-button" @click="revealed = true">显示答案</button>
            </div>

            <div v-if="stage === 'identify' && result !== 'correct'" class="actions self-assessment">
              <button type="button" class="subtle-button" @click="assess(false)">不认识 · 看释义</button>
              <button type="button" class="primary-button" @click="assess(true)">认识</button>
            </div>
            <template v-if="stage !== 'identify'">
              <label class="input-label" for="japanese-answer">{{
                inputMode === 'romaji' ? '输入罗马音' : '输入日语原文或假名读音'
              }}</label>
              <input
                id="japanese-answer"
                ref="inputRef"
                v-model="input"
                class="answer-input"
                :class="{ correct: result === 'correct', wrong: result === 'wrong' }"
                :readonly="result === 'correct'"
                :lang="inputMode === 'japanese' ? 'ja' : 'en'"
                :inputmode="inputMode === 'japanese' ? 'text' : 'latin'"
                autocomplete="off"
                autocapitalize="off"
                :spellcheck="false"
                :aria-invalid="result === 'wrong'"
                aria-describedby="answer-feedback input-help"
                :placeholder="inputMode === 'romaji' ? '例如：shi / si' : '使用日语输入法，选词后再按 Enter'"
                @keydown="onKeydown"
                @compositionstart="setComposing(true)"
                @compositionend="setComposing(false)"
              />
            </template>
            <div id="answer-feedback" class="feedback" :class="result" aria-live="polite">
              <template v-if="skipped">✓ 已跳过，按答对记录。查看详解后点击下一项继续。</template>
              <template v-else-if="result === 'correct'">✓ 输入正确，按 Enter 继续</template>
              <template v-else-if="result === 'wrong'">再检查一下读音或拼写，修改后按 Enter 重试。</template>
              <template v-else>{{
                stage === 'identify' ? '回想释义后，选择认识或不认识' : '先用日语输入法确认选词，再按 Enter 检查'
              }}</template>
            </div>
            <div class="answer-actions">
              <button v-if="result === 'correct'" type="button" class="primary-button submit-button" @click="next">
                {{ index + 1 === entries.length ? '完成本轮' : '下一项' }} →
              </button>
              <button
                v-else-if="stage !== 'identify'"
                type="button"
                class="primary-button submit-button"
                :disabled="!input.trim()"
                @click="submit"
              >
                检查答案 ↵
              </button>
              <button
                v-if="stage !== 'identify' && result !== 'correct'"
                type="button"
                class="skip-spelling-button"
                aria-label="跳过拼写"
                title="跳过本次拼写，计为答对并显示本词详解"
                @click="skipSpelling"
              >
                <svg
                  viewBox="0 0 24 24"
                  width="22"
                  height="22"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="1.8"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  aria-hidden="true"
                >
                  <path d="m4 5 8 7-8 7V5Zm10 0 8 7-8 7V5Z" />
                </svg>
              </button>
            </div>
            <p v-if="stage !== 'identify'" id="input-help" class="input-help">
              {{
                inputMode === 'romaji'
                  ? '兼容 shi / si、chi / ti、tsu / tu。长音可输入 - 或重复元音；空格和句末标点可省略。'
                  : '日语输入法选词期间不会判错。支持原文或读音；假名练习区分平假名与片假名。'
              }}
            </p>

            <JapaneseWordDetails
              v-if="lesson.kind !== 'kana' && showAnswer && (stage !== 'identify' || result === 'correct')"
              :entry="entry"
              :show-translation="settings.translate"
              @speak="speak"
            />
          </div>
          <p v-if="message && !showImport" class="notice" role="status">{{ message }}</p>
          <p v-if="entry?.source" class="source-note">来源：{{ lesson.title }} · 原文件第 {{ entry.source.page }} 页</p>
        </section>

        <section class="stats-strip" aria-label="当前课程累计统计">
          <div>
            <strong
              >{{ stats.mastered.length }}<small> / {{ lesson.entries.length }}</small></strong
            ><span>已练习</span>
          </div>
          <div>
            <strong>{{ accuracy }}<small>%</small></strong
            ><span>答题正确率</span>
          </div>
          <div>
            <strong>{{ stats.mistakes.length }}</strong
            ><span>待巩固</span>
          </div>
          <button type="button" class="subtle-button" :disabled="!stats.mistakes.length" @click="restart(true)">
            复习错题
          </button>
        </section>

        <details class="lesson-overview" :open="stage === 'follow'">
          <summary>本课内容 · 点击可跳转练习</summary>
          <label v-if="lesson.entries.length > 100" class="overview-groups"
            >选择练习范围
            <select :value="Math.floor(overviewPosition / 100)" @change="changeOverviewGroup">
              <option v-for="group in Math.ceil(lesson.entries.length / 100)" :key="group" :value="group - 1">
                第 {{ group }} 组 · {{ (group - 1) * 100 + 1 }}–{{ Math.min(group * 100, lesson.entries.length) }}
              </option>
            </select>
          </label>
          <div
            class="overview-grid"
            :class="{ sentences: lesson.kind === 'article' || lesson.sourceType === 'grammar' }"
          >
            <button
              v-for="item in overviewEntries"
              :key="item.id"
              type="button"
              :class="{ current: item.id === entry?.id, learned: stats.mastered.includes(item.id) }"
              @click="jumpTo(item.id)"
            >
              <span lang="ja">{{ item.text }}</span
              ><small v-if="settings.translate">{{ item.meaning }}</small>
            </button>
          </div>
        </details>
        <p class="audio-credit">
          内置合成音频：Open JTalk / HTS Voice “Mei” · © Nagoya Institute of Technology ·
          <a href="https://creativecommons.org/licenses/by/3.0/" target="_blank" rel="noopener noreferrer">CC BY 3.0</a>
        </p>
        <p v-if="props.showSourceArchive" class="audio-credit">
          <a :href="withAppBaseURL('/quietspell-source.tar.gz')">下载本版本源码（GPL-3.0）</a>
        </p>
      </div>
    </div>

    <dialog
      v-if="showSettings"
      ref="settingsDialog"
      class="import-dialog learning-settings"
      aria-labelledby="learning-settings-title"
      @cancel.prevent="closeSettings"
    >
      <h2 id="learning-settings-title">学习设置</h2>
      <p class="muted">
        按原版的每日新词、复习比例和分阶段练习安排。学习设置中的音量、语速、重复次数及显示选项与英语共用。
      </p>
      <div class="settings-grid">
        <label>每日新词 <input v-model.number="daily" type="number" min="1" max="500" /></label>
        <label
          >学习进度（已学词数）<input v-model.number="startIndex" type="number" min="0" :max="lesson.entries.length"
        /></label>
        <label
          >复习比例（新词 × 倍数）<input v-model.number="settings.wordReviewRatio" type="number" min="0" max="10"
        /></label>
        <label
          >跟写重复次数<select v-model.number="settings.repeatCount">
            <option :value="1">1 次</option>
            <option :value="2">2 次</option>
            <option :value="3">3 次</option>
            <option :value="5">5 次</option>
            <option v-if="![100, 1, 2, 3, 5].includes(settings.repeatCount)" :value="settings.repeatCount">
              {{ settings.repeatCount }} 次
            </option>
            <option :value="100">自定义</option>
          </select></label
        >
        <label v-if="settings.repeatCount === 100"
          >自定义重复次数<input v-model.number="settings.repeatCustomCount" type="number" min="6" max="15"
        /></label>
        <label>发音音量（%）<input v-model.number="settings.wordSoundVolume" type="number" min="0" max="100" /></label>
        <label
          >发音语速<input v-model.number="settings.wordSoundSpeed" type="number" min="0.25" max="3" step="0.25"
        /></label>
        <label
          >自动切词等待（毫秒）<input
            v-model.number="settings.waitTimeForChangeWord"
            type="number"
            min="200"
            max="10000"
            step="100"
        /></label>
      </div>
      <div class="settings-toggles">
        <label v-if="props.sharedSettings"
          ><input v-model="settings.autoAddRandomReviewWhenNoDue" type="checkbox" /> 无到期词时加入随机复习</label
        >
        <label><input v-model="settings.wordSound" type="checkbox" /> 自动发音（听写始终播放）</label>
        <label><input v-model="settings.autoNextWord" type="checkbox" /> 答对后自动切换</label>
        <label><input v-model="settings.translate" type="checkbox" /> 显示释义与例句翻译</label>
      </div>
      <p class="muted">
        复习按 FSRS 到期时间安排，错题优先。保存并开始会按以上设置重新生成本轮任务，已保存的学习记录会保留。
      </p>
      <div class="actions">
        <a v-if="!props.nativeApp" class="text-button" :href="withAppBaseURL('/setting')">更多设置</a
        ><button type="button" class="subtle-button" @click="closeSettings">返回练习</button
        ><button type="button" class="primary-button" @click="applySettings">保存并开始</button>
      </div>
    </dialog>

    <dialog
      v-if="showImport"
      ref="importDialog"
      class="import-dialog"
      aria-labelledby="import-title"
      @cancel.prevent="closeImport"
    >
      <h2 id="import-title">把喜欢的日语文章变成练习</h2>
      <p class="muted">
        按句号和换行自动分句，最多 20,000
        字。导入后使用日语输入法练习，发音使用设备的日语朗读。重新导入会替换上一篇自定义文章及其进度。
      </p>
      <label for="japanese-article">日语文章</label>
      <textarea
        id="japanese-article"
        v-model="draft"
        rows="9"
        maxlength="20000"
        lang="ja"
        autofocus
        placeholder="今日はいい天気です。&#10;友達と公園に行きます。"
      ></textarea>
      <p v-if="message" class="notice" role="alert">{{ message }}</p>
      <div class="actions">
        <button type="button" class="subtle-button" @click="closeImport">取消</button
        ><button type="button" class="primary-button" :disabled="!draft.trim()" @click="confirmImport">
          导入并开始
        </button>
      </div>
    </dialog>
    <dialog
      v-if="showWordbookImport"
      ref="wordbookDialog"
      class="import-dialog"
      aria-labelledby="wordbook-import-title"
      @cancel.prevent="closeWordbookImport"
    >
      <h2 id="wordbook-import-title">导入自己的日语词书</h2>
      <p class="muted">
        支持 Excel（第一个工作表）、CSV、TSV、JSON；最多 3,000 条、2
        MB。首行使用模板中的列名。文件仅在当前浏览器读取和保存。
      </p>
      <p class="muted">填写假名后可练罗马音；未填写时使用日语输入法。自定义单词和例句可调用设备日语语音朗读。</p>
      <p class="muted">JSON 模板支持词性、多条例句、短语搭配、近义表达和用法说明；导入后会显示在单词下方。</p>
      <div class="actions template-links">
        <a :href="withAppBaseURL('/templates/japanese-wordbook.csv')" download class="text-button">下载 CSV 模板</a>
        <a :href="withAppBaseURL('/templates/japanese-wordbook.json')" download class="text-button">下载 JSON 模板</a>
      </div>
      <label for="wordbook-file">选择词书文件</label>
      <input
        id="wordbook-file"
        type="file"
        accept=".xlsx,.xls,.csv,.tsv,.txt,.json"
        :disabled="readingFile"
        @change="onWordbookFile"
      />
      <p v-if="readingFile" class="muted" role="status">正在读取词书…</p>
      <details class="paste-wordbook">
        <summary>也可以直接粘贴 CSV 或 JSON</summary>
        <label for="wordbook-title">词书名称</label>
        <input id="wordbook-title" v-model="wordbookTitle" maxlength="80" class="answer-input" />
        <label for="wordbook-content">词书内容</label>
        <textarea
          id="wordbook-content"
          v-model="wordbookDraft"
          rows="6"
          maxlength="2000000"
          placeholder="单词,假名,释义,例句,例句读音,例句翻译&#10;猫,ねこ,猫,猫が好きです。,ねこがすきです。,我喜欢猫。"
        ></textarea>
        <button
          type="button"
          class="primary-button"
          :disabled="!wordbookDraft.trim() || readingFile"
          @click="importPastedWordbook"
        >
          导入粘贴内容
        </button>
      </details>
      <p v-if="wordbookError" class="notice" role="alert">{{ wordbookError }}</p>
      <div class="actions"><button type="button" class="subtle-button" @click="closeWordbookImport">关闭</button></div>
    </dialog>
  </main>
</template>

<style scoped lang="scss">
.task-summary {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
  padding-top: 14px;
  color: var(--color-sub-text);
  font-size: 14px;
}
.english-library {
  margin-top: 24px;
}
.english-library a {
  text-decoration: none;
}
.settings-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px 20px;
}
.settings-grid label {
  display: flex;
  flex-direction: column;
  gap: 8px;
  font-size: 14px;
}
.settings-grid input,
.settings-grid select {
  width: 100%;
  box-sizing: border-box;
  border: 1px solid var(--color-input-border);
  border-radius: 8px;
  background: var(--color-input-bg);
  color: var(--color-input-color);
  padding: 9px 12px;
  font-size: 16px;
}
.settings-toggles label {
  display: flex;
  gap: 8px;
  align-items: center;
  font-size: 14px;
}
.self-assessment {
  margin: 20px 0;
}
@media (max-width: 500px) {
  .settings-grid {
    grid-template-columns: 1fr;
  }
}
.japanese-page {
  max-width: 1180px;
  margin: 0 auto;
  padding: 42px 32px;
  color: var(--color-main-text);
}
.page-heading,
.lesson-heading,
.example-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
}
.page-heading {
  margin-bottom: 30px;
}
.heading-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}
h1 {
  font-size: clamp(22px, 2.5vw, 32px);
  margin: 8px 0 12px;
  color: var(--color-input-color);
  letter-spacing: -0.02em;
}
h2 {
  font-size: 20px;
  margin: 0 0 8px;
  color: var(--color-input-color);
}
p {
  margin: 6px 0;
  line-height: 1.7;
}
.eyebrow {
  font-size: 11px;
  letter-spacing: 0.18em;
  color: #9472d4;
  font-weight: 700;
}
.muted,
.count {
  color: var(--color-sub-text);
  font-size: 13px;
}
.learning-grid {
  display: grid;
  grid-template-columns: 225px minmax(0, 1fr);
  gap: 30px;
  align-items: start;
}
.mobile-course-picker {
  display: none;
  margin-bottom: 18px;
}
.mobile-course-picker label {
  display: block;
  margin-bottom: 8px;
  font-size: 14px;
}
.mobile-course-picker select {
  box-sizing: border-box;
  width: 100%;
  min-height: 44px;
  font-size: 16px;
}
.lesson-sidebar {
  position: sticky;
  top: 20px;
}
.group-title {
  margin: 24px 0 10px;
  font-size: 11px;
  letter-spacing: 0.09em;
  color: var(--color-sub-text);
}
.lesson-sidebar section:first-child .group-title {
  margin-top: 0;
}
button,
select,
input,
textarea {
  font: inherit;
}
button {
  cursor: pointer;
  transition:
    background 0.15s,
    border-color 0.15s;
}
button:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}
button:focus-visible,
select:focus-visible,
summary:focus-visible {
  outline: 2px solid #9472d4;
  outline-offset: 3px;
}
.lesson-button {
  width: 100%;
  display: flex;
  align-items: center;
  text-align: left;
  justify-content: space-between;
  gap: 8px;
  background: transparent;
  color: inherit;
  border: 1px solid transparent;
  border-radius: 10px;
  padding: 12px;
  margin: 2px 0;
  font-size: 13px;
}
.lesson-button small {
  flex-shrink: 0;
  color: var(--color-sub-text);
  font-size: 11px;
}
.lesson-button:hover {
  background: var(--color-second);
}
.lesson-button.selected {
  border-color: #9472d480;
  background: #9472d415;
  color: #9472d4;
  font-weight: 600;
}
.sidebar-note {
  font-size: 11px;
  color: var(--color-sub-text);
  margin: 24px 12px 0;
}
.workspace {
  min-width: 0;
}
.practice-card {
  padding: 28px;
  background: var(--color-card-bg);
  border-radius: 20px;
  border: 1px solid var(--color-line);
}
.count {
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
progress {
  display: block;
  appearance: none;
  width: 100%;
  height: 4px;
  border: 0;
  border-radius: 4px;
  overflow: hidden;
  margin: 20px 0;
  background: var(--color-third);
}
progress::-webkit-progress-bar {
  background: var(--color-third);
}
progress::-webkit-progress-value {
  background: #9472d4;
  border-radius: 4px;
}
progress::-moz-progress-bar {
  background: #9472d4;
}
.practice-controls {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 16px;
  padding-bottom: 20px;
  border-bottom: 1px solid var(--color-line);
}
.practice-controls label {
  font-size: 12px;
  display: flex;
  align-items: center;
  gap: 8px;
}
select {
  color: var(--color-main-text);
  background: var(--color-second);
  padding: 7px 9px;
  border: 1px solid var(--color-line);
  border-radius: 7px;
  font-size: 12px;
}
.review-badge {
  font-size: 11px;
  color: #b87d2b;
  background: #b87d2b15;
  padding: 6px 10px;
  border-radius: 20px;
}
.typing-area {
  padding-top: 26px;
  text-align: center;
}
.prompt-label {
  font-size: 11px;
  letter-spacing: 0.08em;
  color: var(--color-sub-text);
}
.target-text {
  font-family: 'Noto Sans JP', 'Yu Gothic', 'Meiryo', sans-serif;
  font-size: clamp(28px, 4vw, 54px);
  color: var(--color-input-color);
  margin: 18px 0 6px;
  line-height: 1.55;
  overflow-wrap: anywhere;
}
.reading {
  color: #9472d4;
  font-size: 17px;
}
.meaning {
  font-size: 14px;
}
.word-part-of-speech {
  color: var(--color-link, #1685d1);
  margin-right: 10px;
}
.romaji {
  font-family: ui-monospace, monospace;
  color: var(--color-sub-text);
  font-size: 15px;
  margin-top: 12px;
  overflow-wrap: anywhere;
}
.actions {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  flex-wrap: wrap;
}
.pronunciation-actions {
  margin: 18px 0 28px;
}
.primary-button,
.subtle-button {
  border-radius: 9px;
  padding: 10px 16px;
  font-size: 13px;
  border: 1px solid var(--color-line);
  line-height: 1.5;
}
.primary-button {
  background: #8061ba;
  color: white;
  border-color: #8061ba;
}
.primary-button:hover:not(:disabled) {
  background: #7051aa;
}
.subtle-button {
  background: var(--color-second);
  color: var(--color-main-text);
}
.subtle-button:hover:not(:disabled) {
  border-color: #9472d4;
}
.text-button {
  color: #9472d4;
  background: transparent;
  border: 0;
  padding: 6px;
  font-size: 12px;
}
.input-label {
  display: block;
  text-align: left;
  font-size: 12px;
  margin-bottom: 8px;
}
.answer-input {
  box-sizing: border-box;
  width: 100%;
  border: 1px solid var(--color-input-border);
  color: var(--color-input-color);
  background: var(--color-input-bg);
  border-radius: 10px;
  padding: 15px;
  font-size: 20px;
  text-align: center;
  outline: none;
}
.answer-input:focus {
  border-color: #9472d4;
  box-shadow: 0 0 0 3px #9472d415;
}
.answer-input::placeholder {
  font-size: 13px;
}
.answer-input.wrong {
  border-color: #cc7755;
}
.answer-input.correct {
  border-color: #459879;
}
.feedback {
  min-height: 22px;
  padding: 10px 0;
  color: var(--color-sub-text);
  font-size: 12px;
}
.feedback.correct {
  color: #459879;
}
.feedback.wrong {
  color: #c57650;
}
.submit-button {
  min-width: 150px;
}
.answer-actions {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 10px;
}
.skip-spelling-button {
  display: inline-flex;
  justify-content: center;
  align-items: center;
  width: 42px;
  height: 42px;
  border: 1px solid var(--color-line);
  border-radius: 9px;
  background: var(--color-second);
  color: var(--color-sub-text);
}
.skip-spelling-button:hover {
  border-color: #9472d4;
  color: #9472d4;
}
.input-help {
  font-size: 11px;
  color: var(--color-sub-text);
  margin-top: 16px;
}
.grammar-point {
  color: #9472d4;
  font-size: 14px;
}
.source-note {
  font-size: 10px;
  color: var(--color-sub-text);
  text-align: right;
  margin-top: 16px;
}
.overview-groups {
  display: flex;
  gap: 10px;
  align-items: center;
  margin-top: 16px;
  font-size: 12px;
}
.example {
  margin-top: 28px;
  padding: 20px;
  background: var(--color-second);
  border: 1px solid var(--color-line);
  border-radius: 12px;
  text-align: left;
}
.example-heading {
  color: var(--color-sub-text);
  font-size: 11px;
  margin-bottom: 12px;
}
.example-text {
  font-size: 19px;
  color: var(--color-input-color);
}
.stats-strip {
  display: flex;
  gap: 16px;
  justify-content: space-between;
  align-items: center;
  padding: 24px 20px;
}
.stats-strip div {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.stats-strip strong {
  font-size: 23px;
  color: var(--color-input-color);
}
.stats-strip small {
  font-weight: normal;
  font-size: 12px;
  color: var(--color-sub-text);
}
.stats-strip span {
  font-size: 11px;
  color: var(--color-sub-text);
}
.lesson-overview {
  padding: 18px 20px;
  border: 1px solid var(--color-line);
  border-radius: 12px;
  background: var(--color-second);
}
summary {
  cursor: pointer;
  font-size: 12px;
}
.overview-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(90px, 1fr));
  gap: 8px;
  margin-top: 18px;
}
.overview-grid.sentences {
  grid-template-columns: 1fr;
}
.overview-grid button {
  padding: 10px 6px;
  background: var(--color-card-bg);
  color: var(--color-main-text);
  border: 1px solid transparent;
  border-radius: 7px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  overflow-wrap: anywhere;
}
.overview-grid small {
  font-size: 10px;
  color: var(--color-sub-text);
}
.overview-grid .current {
  border-color: #9472d4;
}
.overview-grid .learned span {
  color: #459879;
}
.audio-credit {
  font-size: 10px;
  color: var(--color-sub-text);
  margin-top: 18px;
}
.audio-credit a {
  color: inherit;
}
.notice {
  font-size: 12px;
  padding: 12px 16px;
  background: #b87d2b12;
  border-radius: 9px;
  color: #b87d2b;
  margin: 12px 0;
}
.completion {
  text-align: center;
  padding: 50px 0;
}
.completion h3 {
  font-size: 24px;
}
.completion .actions {
  margin-top: 24px;
}
.completion-icon {
  display: inline-grid;
  place-items: center;
  font-size: 34px;
  width: 70px;
  height: 70px;
  border-radius: 50%;
  background: #45987915;
  color: #459879;
}
.import-dialog::backdrop {
  background: #0007;
}
.import-dialog {
  box-sizing: border-box;
  border: 1px solid var(--color-line);
  color: var(--color-main-text);
  background: var(--color-card-bg);
  border-radius: 18px;
  padding: 28px;
  width: min(616px, calc(100% - 40px));
  max-height: 85vh;
  overflow-y: auto;
}
.import-dialog label {
  display: block;
  margin: 18px 0 8px;
  font-size: 13px;
}
.import-dialog textarea {
  width: 100%;
  box-sizing: border-box;
  border: 1px solid var(--color-input-border);
  background: var(--color-input-bg);
  color: var(--color-input-color);
  border-radius: 10px;
  padding: 14px;
  resize: vertical;
  line-height: 1.8;
}
.import-dialog .actions {
  justify-content: flex-end;
  margin-top: 18px;
}
.template-links {
  justify-content: flex-start !important;
}
.paste-wordbook {
  margin-top: 20px;
}
.paste-wordbook > button {
  margin-top: 12px;
}
#wordbook-file {
  max-width: 100%;
  font-size: 13px;
}
@media (max-width: 1000px) {
  .japanese-page {
    padding: 28px 18px;
  }
  .learning-grid {
    grid-template-columns: minmax(0, 1fr);
    gap: 18px;
  }
  .lesson-sidebar {
    display: none;
  }
  .mobile-course-picker {
    display: block;
  }
  .practice-card {
    padding: 22px;
  }
}
@media (max-width: 768px) {
  .page-heading {
    flex-direction: column;
    align-items: flex-start;
    gap: 14px;
  }
  .learning-grid {
    grid-template-columns: 1fr;
  }
  .lesson-sidebar {
    display: none;
  }
  .lesson-sidebar section {
    min-width: 185px;
  }
  .lesson-sidebar .group-title {
    margin-top: 0;
  }
  .sidebar-note {
    display: none;
  }
  .practice-card {
    padding: 18px;
    border-radius: 14px;
  }
  .stats-strip {
    padding: 20px 4px;
    gap: 10px;
    flex-wrap: wrap;
  }
  .stats-strip .subtle-button {
    font-size: 11px;
    padding: 8px;
  }
  .lesson-heading h2 {
    font-size: 18px;
  }
  .japanese-page {
    padding: 22px max(12px, env(safe-area-inset-right)) max(28px, env(safe-area-inset-bottom))
      max(12px, env(safe-area-inset-left));
    box-sizing: border-box;
    width: 100%;
  }
  .example {
    padding: 14px;
  }
  .import-dialog {
    padding: 20px;
    max-height: 85dvh;
  }
  .heading-actions {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    width: 100%;
    gap: 8px;
  }
  .heading-actions a,
  .heading-actions button {
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    box-sizing: border-box;
    min-height: 44px;
    font-size: 14px;
  }
  .practice-controls {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
    gap: 12px;
  }
  .practice-controls label {
    justify-content: space-between;
    font-size: 14px;
  }
  .practice-controls select {
    min-width: 0;
    width: 72%;
    min-height: 44px;
    font-size: 16px;
  }
  .answer-input {
    scroll-margin-top: 110px;
    font-size: 20px;
  }
  .answer-input::placeholder {
    font-size: 14px;
  }
  .skip-spelling-button {
    width: 46px;
    height: 46px;
    flex-shrink: 0;
  }
  .primary-button,
  .subtle-button {
    min-height: 44px;
    font-size: 14px;
  }
  .input-label,
  .feedback,
  .input-help,
  .muted,
  .task-summary {
    font-size: 14px;
  }
  .lesson-heading {
    align-items: flex-start;
    gap: 10px;
  }
  .lesson-heading > div {
    min-width: 0;
  }
  .lesson-heading h2 {
    overflow-wrap: anywhere;
  }
  .overview-groups {
    flex-wrap: wrap;
  }
  .overview-groups select {
    max-width: 100%;
    font-size: 16px;
    min-height: 44px;
  }
}
</style>
