<script setup lang="ts">
const route = useRoute()
const japanese = computed(() => route.path.startsWith('/japanese'))
</script>

<template>
  <nav class="study-language-switch" aria-label="切换学习语言">
    <span class="switch-label">学习语言</span>
    <NuxtLink to="/words" :aria-current="!japanese ? 'page' : undefined" :class="{ active: !japanese }">英语</NuxtLink>
    <NuxtLink to="/japanese" :aria-current="japanese ? 'page' : undefined" :class="{ active: japanese }"
      >日语 <small>日本語</small></NuxtLink
    >
  </nav>
</template>

<style scoped>
.study-language-switch {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 6px;
  padding: 14px 24px 0;
  font-size: 12px;
}
.switch-label {
  color: var(--color-sub-text);
  margin-right: 8px;
}
a {
  display: inline-block;
  padding: 8px 14px;
  border: 1px solid transparent;
  border-radius: 8px;
  color: var(--color-main-text);
  text-decoration: none;
}
a:hover {
  background: var(--color-second);
}
a.active {
  background: var(--color-card-bg);
  border-color: #9472d480;
  color: #9472d4;
}
small {
  font-size: 10px;
  margin-left: 4px;
}
@media (max-width: 768px) {
  .study-language-switch {
    padding: 26px 12px 0;
  }
}
</style>
