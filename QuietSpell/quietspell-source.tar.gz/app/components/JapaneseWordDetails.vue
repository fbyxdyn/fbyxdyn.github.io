<script setup lang="ts">
import { computed } from 'vue'
import type { JapaneseEntry, JapaneseExpression } from '@/core/japanese/content'
import { getJapaneseExamples } from '@/core/japanese/details'

const props = defineProps<{ entry: JapaneseEntry; showTranslation: boolean }>()
const emit = defineEmits<{ speak: [text: string] }>()
const examples = computed(() => getJapaneseExamples(props.entry))
const groups = computed(() =>
  [
    { title: '短语与搭配', items: props.entry.phrases ?? [] },
    { title: '近义表达与区别', items: props.entry.synonyms ?? [] },
    { title: '近音词与区别', items: props.entry.similarSounds ?? [] },
  ].filter(group => group.items.length)
)
const hasDetails = computed(
  () => examples.value.length || groups.value.length || props.entry.senses?.length || props.entry.usage
)
function segments(text: string) {
  const target = props.entry.text
  if (!target) return [{ text, highlight: false }]
  return text
    .split(target)
    .flatMap((part, index) => [...(index ? [{ text: target, highlight: true }] : []), { text: part, highlight: false }])
    .filter(part => part.text)
}
function speakExpression(item: JapaneseExpression) {
  const spoken = /[～〜~]/.test(item.text) ? item.reading || item.text.replace(/[～〜~]/g, '') : item.text
  if (spoken.trim()) emit('speak', spoken)
}
</script>

<template>
  <section class="word-details" aria-label="日语单词详解">
    <section v-if="entry.senses?.length && showTranslation" class="detail-section" aria-label="词义辨析">
      <h3>词义</h3>
      <ol class="sense-list">
        <li v-for="(sense, i) in entry.senses" :key="i">
          <span v-if="sense.partOfSpeech" class="part-of-speech">{{ sense.partOfSpeech }}</span>
          {{ sense.meaning }}
          <p v-if="sense.note" class="usage-note">{{ sense.note }}</p>
        </li>
      </ol>
    </section>

    <section v-if="examples.length" class="detail-section examples-section" aria-label="日语例句">
      <h3>例句</h3>
      <div class="detail-content">
        <article v-for="(example, i) in examples" :key="example.text" class="example-item">
          <div class="japanese-line">
            <p lang="ja">
              <template v-for="(part, j) in segments(example.text)" :key="j"
                ><mark v-if="part.highlight">{{ part.text }}</mark
                ><template v-else>{{ part.text }}</template></template
              >
            </p>
            <button
              type="button"
              class="speak-button"
              :aria-label="`朗读例句 ${i + 1}：${example.text}`"
              @click="emit('speak', example.text)"
            >
              ♪
            </button>
          </div>
          <p v-if="example.reading && example.reading !== example.text" class="kana-reading" lang="ja">
            {{ example.reading }}
          </p>
          <p v-if="showTranslation && example.meaning" class="translation">{{ example.meaning }}</p>
        </article>
      </div>
    </section>

    <section v-for="group in groups" :key="group.title" class="detail-section" :aria-label="group.title">
      <h3>{{ group.title }}</h3>
      <div class="detail-content">
        <article v-for="item in group.items" :key="item.text" class="expression-item">
          <div class="japanese-line">
            <p lang="ja">
              <template v-for="(part, j) in segments(item.text)" :key="j"
                ><mark v-if="part.highlight">{{ part.text }}</mark
                ><template v-else>{{ part.text }}</template></template
              >
            </p>
            <button
              type="button"
              class="speak-button"
              :aria-label="`朗读表达：${item.text}`"
              @click="speakExpression(item)"
            >
              ♪
            </button>
          </div>
          <p v-if="item.reading && item.reading !== item.text" class="kana-reading" lang="ja">{{ item.reading }}</p>
          <p v-if="showTranslation && item.meaning" class="translation">{{ item.meaning }}</p>
          <p v-if="showTranslation && item.note" class="usage-note">{{ item.note }}</p>
        </article>
      </div>
    </section>

    <section v-if="entry.usage && showTranslation" class="detail-section" aria-label="用法提示">
      <h3>用法提示</h3>
      <p class="usage-note">{{ entry.usage }}</p>
    </section>
    <p v-if="!hasDetails" class="empty-details">这条词书尚未收录例句、搭配和近义表达。</p>
    <p v-if="entry.detailsSource" class="details-source">补充内容：{{ entry.detailsSource }}</p>
  </section>
</template>

<style scoped>
.word-details {
  container-type: inline-size;
  margin-top: 28px;
  text-align: left;
}
.detail-section {
  display: grid;
  grid-template-columns: 100px minmax(0, 1fr);
  gap: 20px;
  border-top: 1px dashed var(--color-line);
  padding: 22px 0;
}
h3 {
  font-size: 16px;
  font-weight: 500;
  margin: 3px 0;
  color: var(--color-main-text);
}
p {
  margin: 0;
  line-height: 1.7;
  overflow-wrap: anywhere;
}
.detail-content {
  min-width: 0;
}
.example-item + .example-item,
.expression-item + .expression-item {
  margin-top: 20px;
}
.japanese-line {
  display: flex;
  gap: 12px;
  align-items: baseline;
}
.japanese-line p {
  font-family: 'Noto Sans JP', 'Yu Gothic', 'Meiryo', sans-serif;
  font-size: 21px;
  color: var(--color-input-color);
}
mark {
  color: var(--color-link, #1685d1);
  background: transparent;
}
.kana-reading {
  font-size: 14px;
  color: var(--color-sub-text);
  margin-top: 4px;
}
.translation {
  font-size: 17px;
  color: var(--color-main-text);
  margin-top: 4px;
}
.speak-button {
  min-width: 36px;
  min-height: 36px;
  color: var(--color-link, #1685d1);
  border: 1px solid var(--color-line);
  border-radius: 6px;
  background: var(--color-second);
  padding: 2px 9px;
  font: inherit;
  cursor: pointer;
  flex-shrink: 0;
}
.speak-button:focus-visible {
  outline: 2px solid #9472d4;
  outline-offset: 3px;
}
.sense-list {
  margin: 0;
  padding-left: 20px;
  font-size: 17px;
  line-height: 1.8;
}
.sense-list li + li {
  margin-top: 10px;
}
.part-of-speech {
  color: var(--color-link, #1685d1);
  margin-right: 8px;
}
.usage-note {
  font-size: 15px;
  color: var(--color-sub-text);
  line-height: 1.8;
  margin-top: 6px;
}
.details-source,
.empty-details {
  font-size: 13px;
  color: var(--color-sub-text);
  line-height: 1.7;
}
.details-source {
  margin-top: 8px;
}
@media (max-width: 760px) {
  .speak-button {
    min-width: 44px;
    min-height: 44px;
  }
  .detail-section {
    grid-template-columns: 1fr;
    gap: 10px;
  }
  .japanese-line p {
    font-size: 19px;
  }
}
@container (max-width: 520px) {
  .detail-section {
    grid-template-columns: 1fr;
    gap: 10px;
  }
  .japanese-line p {
    font-size: 19px;
  }
}
</style>
