<script setup lang="ts">
import { useRouter } from 'vue-router'
const router = useRouter()

function goHome() {
  router.push('/japanese')
}
</script>

<template>
  <button class="quietspell-logo" type="button" @click="goHome">QuietSpell<span>静心拼写</span></button>
</template>

<style scoped lang="scss">
.quietspell-logo {
  cursor: pointer;
  background: transparent;
  border: 0;
  padding: 0;
  color: #8061ba;
  font-size: 23px;
  font-weight: 750;
  letter-spacing: -0.04em;
  text-align: left;
}
.quietspell-logo span {
  display: block;
  font-size: 9px;
  font-weight: 400;
  letter-spacing: 0.25em;
  margin-top: 2px;
  color: var(--color-sub-text);
}
</style>
