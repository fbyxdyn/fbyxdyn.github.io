<script setup lang="ts">
import { computed, nextTick, ref } from 'vue'
import { useJapaneseUserSync } from '@/composables/useJapaneseUserSync'
import type { JapaneseSnapshot } from '@/core/japanese/snapshot'

const props = defineProps<{
  ready: boolean
  pause: () => void
  exportSnapshot: () => JapaneseSnapshot
  restoreSnapshot: (value: unknown) => void
  restoreDownloadBackup: () => void
}>()
const opened = ref(false)
const dialog = ref<HTMLDialogElement>()
const { userId, inviteCode, status, message, configured, upload, download, cancel, resetSecret, restoreBackup } = useJapaneseUserSync(props)
const busy = computed(() => status.value === 'uploading' || status.value === 'downloading')
function open() {
  props.pause()
  opened.value = true
  void nextTick(() => dialog.value?.showModal())
}
function close() {
  resetSecret()
  dialog.value?.close()
  opened.value = false
}
</script>

<template>
  <button class="subtle-button" type="button" :disabled="!ready" @click="open">用户设置</button>
  <dialog v-if="opened" ref="dialog" class="user-sync-dialog" aria-labelledby="user-sync-title" @cancel.prevent="close">
    <h2 id="user-sync-title">用户设置</h2>
    <p class="sync-muted">按用户 ID 保存和读取日语学习数据。</p>
    <label for="quietspell-user-id">用户 ID</label>
    <input id="quietspell-user-id" v-model="userId" type="text" autocomplete="off" autocapitalize="off" :spellcheck="false" placeholder="输入你的用户 ID" aria-describedby="user-id-help" />
    <p id="user-id-help" class="sync-muted">可用中文、英文、数字和符号，区分大小写与空格。请在各设备使用完全相同的 ID。</p>
    <div class="sync-actions">
      <button class="primary-button" type="button" :disabled="busy || !configured" @click="upload">上传该用户数据</button>
      <button class="subtle-button" type="button" :disabled="busy || !configured" @click="download">下载该用户数据</button>
    </div>
    <label for="quietspell-invite-code">邀请码</label>
    <input id="quietspell-invite-code" v-model="inviteCode" type="password" autocomplete="new-password" autocapitalize="off" :spellcheck="false" placeholder="输入邀请码后才能上传或下载" />
    <p class="sync-muted">邀请码只用于本次验证，关闭窗口后清空。</p>
    <p v-if="!configured" class="sync-notice" role="status">云同步服务尚未开通。用户 ID 可先保存在本机，管理员配置完成后即可上传和下载。</p>
    <p class="sync-muted">包含进度、错题、复习计划、学习设置和已导入的词书／文章，不上传内置音频。上传会更新该 ID 的云端备份；下载会替换本机数据，并先备份原数据。</p>
    <p class="sync-muted">邀请码为共享访问凭据。知道邀请码和用户 ID 的人，都能读取或更新该 ID 的数据。</p>
    <p v-if="busy" class="sync-notice" role="status">{{ status === 'uploading' ? '正在上传…' : '正在下载并校验…' }}</p>
    <p v-if="message" class="sync-notice" :class="{ 'sync-error': status === 'error' }" role="status" aria-live="polite">{{ message }}</p>
    <div class="sync-actions">
      <button v-if="busy" class="subtle-button" type="button" @click="cancel">取消操作</button>
      <button class="text-button" type="button" :disabled="busy" @click="restoreBackup">恢复下载前的本机数据</button>
      <button class="subtle-button" type="button" @click="close">关闭</button>
    </div>
  </dialog>
</template>

<style scoped>
button { font: inherit; cursor: pointer; }
button:disabled { opacity: .45; cursor: not-allowed; }
button:focus-visible, input:focus-visible { outline: 2px solid #9472d4; outline-offset: 3px; }
.primary-button, .subtle-button { border-radius: 10px; padding: 10px 16px; border: 1px solid var(--color-line); font-size: .9rem; }
.primary-button { background: #8662c8; color: white; border-color: #8662c8; }
.subtle-button { color: var(--color-main-text); background: var(--color-card-bg); }
.text-button { border: 0; background: transparent; padding: 8px 0; color: #8662c8; font-size: .9rem; }
.user-sync-dialog { box-sizing: border-box; width: min(600px, calc(100% - 32px)); max-height: 85vh; overflow-y: auto; border: 1px solid var(--color-line); border-radius: 18px; padding: 26px; color: var(--color-main-text); background: var(--color-card-bg); }
.user-sync-dialog::backdrop { background: #0007; }
.user-sync-dialog h2 { margin: 0 0 12px; font-size: 1.4rem; }
.user-sync-dialog label { display: block; margin: 20px 0 8px; font-size: 1rem; font-weight: 600; }
.user-sync-dialog input { box-sizing: border-box; width: 100%; min-width: 0; padding: 12px; border: 1px solid var(--color-input-border); border-radius: 10px; font-size: 1rem; color: var(--color-input-color); background: var(--color-input-bg); }
.sync-muted { margin: 10px 0; font-size: .9rem; line-height: 1.7; color: var(--color-sub-text); overflow-wrap: anywhere; }
.sync-actions { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 18px; align-items: center; }
.sync-actions button { min-height: 42px; white-space: normal; }
.sync-notice { padding: 12px; border-radius: 10px; background: #8774d514; line-height: 1.6; overflow-wrap: anywhere; }
.sync-error { color: #c34b4b; }
@media (max-width: 600px) { .user-sync-dialog { padding: 20px; } .sync-actions > button { flex: 1 1 130px; } }
</style>
