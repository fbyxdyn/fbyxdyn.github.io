import { computed, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import { JAPANESE_LESSONS, type JapaneseEntry, type JapaneseLesson } from '@/core/japanese/content'
import { createCustomArticle, getRomaji, isJapaneseAnswerCorrect } from '@/core/japanese/input'
import { createJapaneseSpeaker } from '@/core/japanese/audio'
import { N3_BOOKS } from '@/core/japanese/n3-books'
import { parseJapaneseWordbookRows, type ParsedJapaneseWordbook } from '@/core/japanese/wordbook'
import { createEmptyCard, FSRS, Rating, type Card, type Grade } from 'ts-fsrs'
import {
  createJapaneseSession,
  defaultJapaneseSettings,
  japaneseStageNames,
  shouldHandleJapaneseKey,
  type JapanesePracticeMode,
  type JapaneseSession,
  type JapaneseSharedSettings,
} from '@/core/japanese/learning'

const STORAGE_KEY = 'typewords-japanese-practice-v1'
interface LessonProgress {
  index: number
  mastered: string[]
  mistakes: string[]
  correct: number
  attempts: number
  daily: number
  cards: Record<string, Card>
}
const emptyProgress = (): LessonProgress => ({
  index: 0,
  mastered: [],
  mistakes: [],
  correct: 0,
  attempts: 0,
  daily: 20,
  cards: {},
})

export function useJapanesePractice(options: { sharedSettings?: JapaneseSharedSettings } = {}) {
  const lessonId = ref('hiragana')
  const inputMode = ref<'romaji' | 'japanese'>('japanese')
  const practiceMode = ref<JapanesePracticeMode>('system')
  const localSettings = ref(defaultJapaneseSettings())
  const settings = computed(() => options.sharedSettings ?? localSettings.value)
  const session = ref<JapaneseSession | null>(null)
  const progress = ref<Record<string, LessonProgress>>({})
  const customText = ref('')
  const customEntries = ref<JapaneseEntry[]>([])
  const wordbooks = ref<JapaneseLesson[]>([])
  const input = ref('')
  const result = ref<'idle' | 'wrong' | 'correct'>('idle')
  const revealed = ref(false)
  const skipped = ref(false)
  const finished = ref(false)
  const ready = ref(false)
  const message = ref('')
  const storageMessage = ref('')
  const inputRef = ref<HTMLInputElement>()
  const reviewIds = ref<string[] | null>(null)
  const speaker = createJapaneseSpeaker(
    text => {
      message.value = text
    },
    () => ({ volume: settings.value.wordSoundVolume / 100, rate: settings.value.wordSoundSpeed })
  )
  let lastWrongInput: string | null = null
  let composing = false
  let compositionEndedAt = -Infinity
  let advanceTimer: ReturnType<typeof setTimeout> | undefined

  const lessons = computed<JapaneseLesson[]>(() => [
    ...JAPANESE_LESSONS,
    ...N3_BOOKS,
    ...wordbooks.value,
    ...(customEntries.value.length
      ? [
          {
            id: 'custom',
            title: '我的日语文章',
            description: '使用日语输入法，逐句练习你导入的文章。',
            kind: 'article' as const,
            entries: customEntries.value,
          },
        ]
      : []),
  ])
  const lesson = computed(() => lessons.value.find(item => item.id === lessonId.value) ?? JAPANESE_LESSONS[0])
  const canUseRomaji = computed(() => lesson.value.entries.every(item => !!item.reading))
  const stats = computed(() => progress.value[lesson.value.id] ?? emptyProgress())
  const entryMap = computed(() => new Map(lesson.value.entries.map(item => [item.id, item])))
  const entries = computed(
    () => session.value?.tasks.map(task => entryMap.value.get(task.entryId)!).filter(Boolean) ?? []
  )
  const index = computed(() => session.value?.position ?? 0)
  const entry = computed(() => entries.value[index.value])
  const task = computed(() => session.value?.tasks[index.value])
  const stage = computed(() => task.value?.stage ?? 'follow')
  const stageName = computed(() => japaneseStageNames[stage.value])
  const romaji = computed(() => (entry.value?.reading ? getRomaji(entry.value) : ''))
  const showAnswer = computed(
    () => ['follow', 'identify'].includes(stage.value) || revealed.value || result.value === 'correct'
  )
  const daily = computed({
    get: () => stats.value.daily,
    set: (value: number) => {
      currentProgress().daily = Math.max(1, Math.min(500, Number(value) || 20))
    },
  })
  const startIndex = computed({
    get: () => stats.value.index,
    set: (value: number) => {
      currentProgress().index = Math.max(0, Math.min(lesson.value.entries.length, Number(value) || 0))
    },
  })
  const repetitions = computed(() =>
    stage.value !== 'follow'
      ? 1
      : Math.max(
          1,
          Math.min(
            15,
            settings.value.repeatCount === 100 ? settings.value.repeatCustomCount || 6 : settings.value.repeatCount
          )
        )
  )
  const accuracy = computed(() =>
    stats.value.attempts ? Math.round((stats.value.correct / stats.value.attempts) * 100) : 0
  )

  function currentProgress() {
    return progress.value[lesson.value.id] ?? (progress.value[lesson.value.id] = emptyProgress())
  }

  function focusInput() {
    void nextTick(() => {
      const field = inputRef.value
      if (!field) return
      // A tap on the input is the only action that should open a touch keyboard.
      if (window.matchMedia('(any-pointer: coarse)').matches || window.matchMedia('(hover: none)').matches) {
        if (document.activeElement === field) field.blur()
        return
      }
      field.focus()
    })
  }
  function pause() {
    clearTimeout(advanceTimer)
    speaker.stop()
  }
  function resetInput() {
    clearTimeout(advanceTimer)
    speaker.stop()
    input.value = ''
    result.value = 'idle'
    revealed.value = false
    skipped.value = false
    lastWrongInput = null
    composing = false
    message.value = ''
    focusInput()
  }

  function selectLesson(id: string) {
    if (!lessons.value.some(item => item.id === id)) return
    lessonId.value = id
    reviewIds.value = null
    if (!canUseRomaji.value) inputMode.value = 'japanese'
    beginSession()
  }

  function dueIds() {
    const endOfDay = new Date()
    endOfDay.setHours(23, 59, 59, 999)
    const due = [
      ...new Set([
        ...stats.value.mistakes,
        ...Object.entries(stats.value.cards)
          .filter(([, card]) => new Date(card.due).getTime() <= endOfDay.getTime())
          .sort((a, b) => new Date(a[1].due).getTime() - new Date(b[1].due).getTime())
          .map(([id]) => id),
      ]),
    ]
    if (!due.length && settings.value.autoAddRandomReviewWhenNoDue) {
      const learned = lesson.value.entries.slice(0, stats.value.index).map(item => item.id)
      for (let i = learned.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1))
        ;[learned[i], learned[j]] = [learned[j], learned[i]]
      }
      return learned
    }
    return due
  }

  function beginSession(reviewOnly = false, from?: number) {
    session.value = createJapaneseSession({
      lessonId: lesson.value.id,
      entries: lesson.value.entries,
      start: from ?? stats.value.index,
      daily: stats.value.daily,
      reviewRatio: settings.value.wordReviewRatio,
      mode: practiceMode.value,
      dueIds: dueIds(),
      reviewOnly,
    })
    finished.value = session.value.tasks.length === 0
    resetInput()
  }

  function submit() {
    if (composing || finished.value || !entry.value || !input.value.trim() || result.value === 'correct') return
    const correct = isJapaneseAnswerCorrect(input.value, entry.value, inputMode.value)
    if (!correct && input.value === lastWrongInput) return
    const state = currentProgress()
    state.attempts++
    if (correct) {
      state.correct++
      if (!revealed.value || stage.value === 'follow') {
        if (!state.mastered.includes(entry.value.id)) state.mastered.push(entry.value.id)
        state.mistakes = state.mistakes.filter(id => id !== entry.value.id)
      }
      result.value = 'correct'
      focusInput()
      if (settings.value.autoNextWord)
        advanceTimer = setTimeout(next, Math.max(200, settings.value.waitTimeForChangeWord || 300))
    } else {
      lastWrongInput = input.value
      if (!state.mistakes.includes(entry.value.id)) state.mistakes.push(entry.value.id)
      result.value = 'wrong'
      if (session.value) session.value.wrong[entry.value.id] = (session.value.wrong[entry.value.id] || 0) + 1
    }
  }

  function assess(known: boolean) {
    if (stage.value !== 'identify' || !entry.value || !session.value || result.value === 'correct') return
    const state = currentProgress()
    state.attempts++
    if (known) {
      state.correct++
      if (!state.mastered.includes(entry.value.id)) state.mastered.push(entry.value.id)
      state.mistakes = state.mistakes.filter(id => id !== entry.value.id)
    } else {
      if (!state.mistakes.includes(entry.value.id)) state.mistakes.push(entry.value.id)
      session.value.wrong[entry.value.id] = (session.value.wrong[entry.value.id] || 0) + 1
    }
    revealed.value = !known
    result.value = 'correct'
    if (known && settings.value.autoNextWord)
      advanceTimer = setTimeout(next, Math.max(200, settings.value.waitTimeForChangeWord || 300))
  }

  function next() {
    if (result.value !== 'correct' || !session.value || !entry.value) return
    clearTimeout(advanceTimer)
    session.value.repetition = skipped.value ? repetitions.value : session.value.repetition + 1
    if (stage.value !== 'identify' && session.value.repetition < repetitions.value) {
      resetInput()
      if (settings.value.wordSound || stage.value === 'listen')
        void nextTick(() => {
          if (entry.value) void speaker.speak(entry.value.text, true, entry.value.reading)
        })
      return
    }
    session.value.repetition = 0
    advanceTask()
  }

  function skipSpelling() {
    if (finished.value || !session.value || !entry.value || stage.value === 'identify' || result.value === 'correct')
      return
    pause()
    const id = entry.value.id
    const state = currentProgress()
    state.attempts++
    state.correct++
    if (!state.mastered.includes(id)) state.mastered.push(id)
    state.mistakes = state.mistakes.filter(item => item !== id)
    skipped.value = true
    result.value = 'correct'
    revealed.value = true
    input.value = ''
    focusInput()
  }

  function advanceTask() {
    if (!session.value || !entry.value) return
    const id = entry.value.id
    if (!session.value.tasks.slice(index.value + 1).some(item => item.entryId === id)) {
      const state = currentProgress()
      const mistakes = session.value.wrong[id] || 0
      const prefs = settings.value
      const grade: Grade =
        mistakes <= (prefs.fsrsEasyLimit ?? 0)
          ? Rating.Easy
          : mistakes <= (prefs.fsrsGoodLimit ?? 3)
            ? Rating.Good
            : mistakes <= (prefs.fsrsHardLimit ?? 6)
              ? Rating.Hard
              : Rating.Again
      state.cards[id] = new FSRS(prefs.fsrsParameters).next(
        state.cards[id] ?? createEmptyCard(),
        new Date(),
        grade
      ).card
      if (!task.value?.review)
        state.index = Math.max(state.index, lesson.value.entries.findIndex(item => item.id === id) + 1)
    }
    if (index.value + 1 >= entries.value.length) {
      finished.value = true
      return
    }
    session.value.position++
    resetInput()
  }

  function restart(review = false) {
    if (review && !dueIds().length) return
    reviewIds.value = review ? dueIds() : null
    beginSession(review, !review && stats.value.index >= lesson.value.entries.length ? 0 : undefined)
  }

  function jumpTo(id: string) {
    const targetIndex = lesson.value.entries.findIndex(item => item.id === id)
    if (targetIndex < 0) return
    reviewIds.value = null
    beginSession(false, targetIndex)
  }

  function importArticle(text: string): boolean {
    try {
      const imported = createCustomArticle(text)
      if (!imported.length) throw new Error('文章中没有可练习的句子。')
      customText.value = text.trim()
      customEntries.value = imported
      progress.value.custom = emptyProgress()
      selectLesson('custom')
      return true
    } catch (error) {
      message.value = error instanceof Error ? error.message : '文章导入失败，请重试。'
      return false
    }
  }

  function speak(text?: string, reading?: string) {
    if (!entry.value) return
    message.value = ''
    void speaker.speak(text ?? entry.value.text, false, text === undefined ? entry.value.reading : reading)
  }

  function importWordbook(book: ParsedJapaneseWordbook) {
    if (wordbooks.value.length >= 10) throw new Error('最多保存 10 本自定义词书，请先移除不再使用的词书。')
    const id = `wordbook-${crypto.randomUUID()}`
    wordbooks.value.push({
      id,
      title: book.title,
      description: `我的词书 · ${book.entries.length} 个词条${book.entries.some(item => !item.reading) ? ' · 未填写假名，使用日语输入法练习' : ''}`,
      kind: 'words',
      entries: book.entries,
    })
    selectLesson(id)
  }

  function removeWordbook() {
    const id = lessonId.value
    if (!wordbooks.value.some(item => item.id === id)) return
    if (!window.confirm(`移除“${lesson.value.title}”及其学习进度？原始词书文件不会被修改。`)) return
    selectLesson('hiragana')
    wordbooks.value = wordbooks.value.filter(item => item.id !== id)
    delete progress.value[id]
  }

  function onKeydown(event: KeyboardEvent) {
    if (!shouldHandleJapaneseKey(event, composing, performance.now() - compositionEndedAt)) return
    if (stage.value === 'identify' && result.value !== 'correct') return
    event.preventDefault()
    if (result.value === 'correct') next()
    else submit()
  }

  function setComposing(value: boolean) {
    composing = value
    if (!value) compositionEndedAt = performance.now()
  }

  function save() {
    if (!ready.value) return
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          version: 1,
          preferencesVersion: 2,
          lessonId: lessonId.value,
          inputMode: inputMode.value,
          practiceMode: practiceMode.value,
          progress: progress.value,
          customText: customText.value,
          wordbooks: wordbooks.value,
          settings: localSettings.value,
          session: session.value,
          finished: finished.value,
        })
      )
      storageMessage.value = ''
    } catch {
      storageMessage.value = '浏览器无法保存进度。请检查存储空间或隐私设置，关闭页面后本次进度可能丢失。'
    }
  }

  onMounted(() => {
    try {
      const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? 'null')
      if (stored?.version === 1) {
        if (Array.isArray(stored.wordbooks)) {
          for (const book of stored.wordbooks.slice(0, 10)) {
            if (
              !book ||
              typeof book.id !== 'string' ||
              !/^wordbook-[a-f\d-]{36}$/.test(book.id) ||
              !Array.isArray(book.entries) ||
              typeof book.title !== 'string'
            )
              continue
            const parsed = parseJapaneseWordbookRows(book.entries, book.title)
            wordbooks.value.push({
              id: book.id,
              title: parsed.title,
              description: `我的词书 · ${parsed.entries.length} 个词条`,
              kind: 'words',
              entries: parsed.entries,
            })
          }
        }
        if (typeof stored.customText === 'string' && stored.customText.trim()) {
          customEntries.value = createCustomArticle(stored.customText)
          customText.value = stored.customText
        }
        for (const item of lessons.value) {
          const state = stored.progress?.[item.id]
          if (!state || typeof state !== 'object') continue
          const ids = new Set(item.entries.map(entry => entry.id))
          const validCount = (value: unknown) =>
            typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 ? value : 0
          progress.value[item.id] = {
            index: Math.min(validCount(state.index), item.entries.length),
            daily: Math.max(1, Math.min(500, validCount(state.daily) || 20)),
            cards: Object.fromEntries(
              Object.entries(state.cards ?? {}).filter(
                ([id, card]: [string, any]) => ids.has(id) && card && Number.isFinite(new Date(card.due).getTime())
              )
            ),
            mastered: Array.isArray(state.mastered)
              ? [...new Set<string>(state.mastered.filter((id: unknown) => typeof id === 'string' && ids.has(id)))]
              : [],
            mistakes: Array.isArray(state.mistakes)
              ? [...new Set<string>(state.mistakes.filter((id: unknown) => typeof id === 'string' && ids.has(id)))]
              : [],
            correct: Math.min(validCount(state.correct), validCount(state.attempts)),
            attempts: validCount(state.attempts),
          }
        }
        if (lessons.value.some(item => item.id === stored.lessonId)) lessonId.value = stored.lessonId
        if (stored.preferencesVersion === 2) {
          if (stored.inputMode === 'romaji' && canUseRomaji.value) inputMode.value = 'romaji'
          if (['system', 'free', 'identify', 'listen', 'recall'].includes(stored.practiceMode))
            practiceMode.value = stored.practiceMode
          if (!options.sharedSettings && stored.settings) {
            const defaults = defaultJapaneseSettings()
            for (const key of Object.keys(defaults))
              if (typeof stored.settings[key] === typeof defaults[key]) localSettings.value[key] = stored.settings[key]
          }
          const saved = stored.session
          const ids = entryMap.value
          if (
            saved?.lessonId === lesson.value.id &&
            saved.mode === practiceMode.value &&
            Array.isArray(saved.tasks) &&
            saved.tasks.length &&
            saved.tasks.length <= 20000 &&
            saved.tasks.every(
              task => ids.has(task.entryId) && ['follow', 'identify', 'listen', 'recall'].includes(task.stage)
            ) &&
            Number.isInteger(saved.position) &&
            saved.position >= 0 &&
            saved.position < saved.tasks.length
          ) {
            session.value = {
              ...saved,
              repetition: Math.max(0, Math.min(repetitions.value - 1, Number(saved.repetition) || 0)),
              wrong: saved.wrong ?? {},
            }
            finished.value = stored.finished === true
          }
        }
      }
    } catch {
      storageMessage.value = '日语学习进度读取失败。你仍可以开始练习。'
    }
    ready.value = true
    if (!session.value) beginSession()
    // Warm up the voice list; some browsers load installed voices asynchronously.
    if ('speechSynthesis' in window) window.speechSynthesis.getVoices()
    focusInput()
  })
  watch([lessonId, inputMode, practiceMode, progress, customText, wordbooks, session, localSettings], save, {
    deep: true,
    flush: 'post',
  })
  watch(inputMode, resetInput)
  watch(practiceMode, () => {
    if (ready.value) beginSession()
  })
  watch(
    [entry, stage, ready],
    () => {
      if (ready.value && entry.value && (settings.value.wordSound || stage.value === 'listen'))
        void nextTick(() => {
          if (entry.value) void speaker.speak(entry.value.text, true, entry.value.reading)
        })
    },
    { flush: 'post' }
  )
  onUnmounted(() => {
    clearTimeout(advanceTimer)
    speaker.stop()
  })

  return {
    lessons,
    lesson,
    lessonId,
    canUseRomaji,
    inputMode,
    practiceMode,
    settings,
    daily,
    startIndex,
    session,
    stage,
    task,
    stageName,
    repetitions,
    beginSession,
    pause,
    assess,
    stats,
    entries,
    index,
    entry,
    romaji,
    showAnswer,
    accuracy,
    input,
    inputRef,
    result,
    revealed,
    skipped,
    finished,
    ready,
    message,
    storageMessage,
    reviewIds,
    customText,
    selectLesson,
    submit,
    next,
    skipSpelling,
    restart,
    jumpTo,
    importArticle,
    importWordbook,
    removeWordbook,
    speak,
    onKeydown,
    setComposing,
  }
}
