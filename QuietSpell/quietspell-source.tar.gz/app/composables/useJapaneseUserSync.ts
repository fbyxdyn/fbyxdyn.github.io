import { onMounted, onUnmounted, ref, watch } from 'vue'
import { createJapaneseSyncClient, getJapaneseSyncEndpoint, JapaneseSyncError } from '@/core/japanese/sync-client'
import type { JapaneseSnapshot } from '@/core/japanese/snapshot'

const USER_ID_KEY = 'quietspell-japanese-user-id-v1'
export function useJapaneseUserSync(options: {
  exportSnapshot: () => JapaneseSnapshot
  restoreSnapshot: (value: unknown) => void
  restoreDownloadBackup: () => void
  endpoint?: string
}) {
  const userId = ref('')
  const inviteCode = ref('')
  const status = ref<'idle' | 'uploading' | 'downloading' | 'success' | 'error'>('idle')
  const message = ref('')
  const endpoint = options.endpoint ?? getJapaneseSyncEndpoint()
  const client = createJapaneseSyncClient(endpoint)
  const revisions = new Map<string, string | null>()
  let controller: AbortController | undefined
  let operation = 0
  function cancel() {
    operation++
    controller?.abort()
    controller = undefined
    if (status.value === 'uploading' || status.value === 'downloading') {
      status.value = 'idle'
      message.value = '操作已取消。上传若已到达云端，请下载核对最新版本。'
    }
  }
  function resetSecret() {
    cancel()
    inviteCode.value = ''
  }
  async function transfer(action: 'upload' | 'download') {
    cancel()
    message.value = ''
    if (!userId.value.length || !inviteCode.value.length) {
      status.value = 'error'
      message.value = !userId.value.length ? '请输入用户 ID。' : '请输入邀请码。'
      return
    }
    const id = userId.value, code = inviteCode.value, active = ++operation
    const abort = new AbortController()
    controller = abort
    status.value = action === 'upload' ? 'uploading' : 'downloading'
    const timer = setTimeout(() => abort.abort('timeout'), 30000)
    try {
      if (action === 'upload') {
        const snapshot = options.exportSnapshot()
        if (!revisions.has(id)) {
          try {
            const remote = await client.download(id, code, abort.signal)
            if (active !== operation || abort.signal.aborted) return
            revisions.set(id, remote.sha)
          } catch (error) {
            if (error instanceof JapaneseSyncError && error.status === 404) revisions.set(id, null)
            else throw error
          }
        }
        if (active !== operation || abort.signal.aborted) return
        const result = await client.upload(id, code, snapshot, revisions.get(id)!, abort.signal)
        if (active !== operation || abort.signal.aborted) return
        revisions.set(id, result.sha)
        message.value = `已上传此用户的日语学习数据。云端时间：${new Date(result.updatedAt).toLocaleString()}`
      } else {
        const result = await client.download(id, code, abort.signal)
        if (active !== operation || abort.signal.aborted) return
        options.restoreSnapshot(result.snapshot)
        revisions.set(id, result.sha)
        message.value = '下载完成，已应用该用户的学习数据。原本机数据已备份，可在下方恢复。'
      }
      status.value = 'success'
    } catch (error) {
      if (active !== operation) return
      status.value = 'error'
      message.value = abort.signal.aborted
        ? '连接超时，本机数据未被替换。上传若已到达云端，请下载核对。'
        : error instanceof JapaneseSyncError || error instanceof Error ? error.message : '同步失败，请稍后重试。'
    } finally {
      clearTimeout(timer)
      if (controller === abort) controller = undefined
    }
  }
  function restoreBackup() {
    cancel()
    try {
      options.restoreDownloadBackup()
      status.value = 'success'
      message.value = '已恢复下载前的本机学习数据。云端数据保持原样。'
    } catch (error) {
      status.value = 'error'
      message.value = error instanceof Error ? error.message : '本机备份恢复失败。'
    }
  }
  onMounted(() => {
    try { userId.value = localStorage.getItem(USER_ID_KEY) ?? '' } catch { /* ID entry remains available. */ }
  })
  watch(userId, value => {
    cancel()
    status.value = 'idle'
    message.value = ''
    try { localStorage.setItem(USER_ID_KEY, value) } catch { /* Sync does not require saving the ID. */ }
  }, { flush: 'sync' })
  watch(inviteCode, () => { cancel(); status.value = 'idle'; message.value = '' }, { flush: 'sync' })
  onUnmounted(resetSecret)
  return { userId, inviteCode, status, message, configured: !!endpoint,
    upload: () => transfer('upload'), download: () => transfer('download'), cancel, resetSecret, restoreBackup }
}
