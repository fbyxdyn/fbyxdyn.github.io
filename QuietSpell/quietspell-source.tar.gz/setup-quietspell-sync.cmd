@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\prepare-japanese-sync-token.ps1"
if errorlevel 1 echo Setup did not complete. No token was sent to the server.
pause
