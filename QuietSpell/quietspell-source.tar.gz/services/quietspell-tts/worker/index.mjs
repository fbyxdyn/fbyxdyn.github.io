// Protocol adapted from @andresaya/edge-tts 1.9.1, GPL-3.0-only.
// https://github.com/andresayac/edge-tts
const VOICES = ['ja-JP-NanamiNeural', 'ja-JP-KeitaNeural']
const ORIGINS = new Set(['https://fbyxdyn.github.io', 'http://127.0.0.1:5567', 'http://localhost:5567'])
const TOKEN = '6A5AA1D4EAFF4E9FB37E23D68491D6F4' // Public Edge client identifier, not a private API key.
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0'
const requests = new Map()
const decoder = new TextDecoder()

export function validateSpeech(url) {
  const text = (url.searchParams.get('text') || '').normalize('NFC').trim()
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, ' ')
  const voice = url.searchParams.get('voice') || VOICES[0]
  if (!text || Array.from(text).length > 1000) throw new Error('Text must contain 1–1000 characters.')
  if (!VOICES.includes(voice)) throw new Error('Unsupported voice.')
  return { text, voice }
}

function escapeXML(text) {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;')
}

export async function synthesisURL(now = Date.now()) {
  const ticks = Math.floor(now / 1000) + 11644473600
  const rounded = (ticks - ticks % 300) * 10000000
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`${rounded}${TOKEN}`))
  const signature = [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('').toUpperCase()
  return 'https://api.msedgeservices.com/tts/cognitiveservices/websocket/v1?' + new URLSearchParams({
    'Ocp-Apim-Subscription-Key': TOKEN, 'Sec-MS-GEC': signature,
    'Sec-MS-GEC-Version': '1-155.0.4283.45', ConnectionId: crypto.randomUUID().replaceAll('-', ''),
  })
}

export async function openMicrosoftSocket(url) {
  const response = await fetch(url, {
    headers: {
      Upgrade: 'websocket', 'User-Agent': USER_AGENT,
      Origin: 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
      Cookie: 'MUID=' + crypto.randomUUID().replaceAll('-', '').toUpperCase(),
    },
    signal: AbortSignal.timeout(12000),
  })
  if (response.status !== 101 || !response.webSocket) throw new Error('Microsoft voice connection failed.')
  const socket = response.webSocket
  try { socket.binaryType = 'arraybuffer' } catch {}
  socket.accept()
  return socket
}

export async function streamSpeech(text, voice, connect = openMicrosoftSocket) {
  const socket = await connect(await synthesisURL())
  const requestId = crypto.randomUUID().replaceAll('-', '')
  let timeout, finished = false, received = false
  const close = () => { try { socket.close(1000, 'Complete') } catch {} }
  const stream = new ReadableStream({
    start(controller) {
      const fail = () => {
        if (finished) return
        finished = true
        clearTimeout(timeout)
        controller.error(new Error('Microsoft voice playback interrupted.'))
        close()
      }
      const finish = () => {
        if (finished) return
        if (!received) { fail(); return }
        finished = true
        clearTimeout(timeout)
        controller.close()
        close()
      }
      const touch = () => { clearTimeout(timeout); timeout = setTimeout(fail, 15000) }
      let messages = Promise.resolve()
      socket.addEventListener('message', event => {
        messages = messages.then(async () => {
        if (finished) return
        touch()
        if (typeof event.data === 'string') {
          if (/Path:turn.end\r?\n/i.test(event.data + '\r\n')) finish()
          return
        }
        const data = typeof event.data?.arrayBuffer === 'function' ? await event.data.arrayBuffer() : event.data
        const bytes = ArrayBuffer.isView(data)
          ? new Uint8Array(data.buffer, data.byteOffset, data.byteLength)
          : new Uint8Array(data)
        if (bytes.length < 2) return
        const length = (bytes[0] << 8) | bytes[1]
        if (2 + length > bytes.length) return
        const header = decoder.decode(bytes.subarray(2, 2 + length))
        if (/Path:audio\r?\n/i.test(header + '\r\n') && bytes.length > 2 + length) {
          received = true
          controller.enqueue(bytes.slice(2 + length))
        }
        }).catch(fail)
      })
      socket.addEventListener('error', fail)
      socket.addEventListener('close', () => { void messages.then(() => { if (!finished) received ? finish() : fail() }) })
      const timestamp = new Date().toUTCString()
      socket.send(`X-Timestamp:${timestamp}\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n` +
        JSON.stringify({ context: { synthesis: { audio: { metadataoptions: { sentenceBoundaryEnabled: false, wordBoundaryEnabled: false }, outputFormat: 'audio-24khz-48kbitrate-mono-mp3' } } } }))
      socket.send(`X-RequestId:${requestId}\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:${timestamp}\r\nPath:ssml\r\n\r\n` +
        `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="ja-JP"><voice name="${voice}"><prosody rate="+0%" pitch="+0Hz" volume="+0%">${escapeXML(text)}</prosody></voice></speak>`)
      touch()
    },
    cancel() { finished = true; clearTimeout(timeout); close() },
  })
  return stream
}

export function createHandler(connect = openMicrosoftSocket) {
  return async function handle(request) {
    const url = new URL(request.url)
    const origin = request.headers.get('Origin')
    const allowed = !origin || ORIGINS.has(origin) || origin === url.origin
    const headers = { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', Vary: 'Origin' }
    if (origin && allowed) headers['Access-Control-Allow-Origin'] = origin
    if (!allowed) return new Response('Origin not allowed', { status: 403, headers })
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: { ...headers, 'Access-Control-Allow-Methods': 'GET, OPTIONS' } })
    if (request.method !== 'GET') return new Response('Method not allowed', { status: 405, headers })
    if (url.pathname === '/' || url.pathname === '/health') return Response.json({ service: 'QuietSpell Japanese voice', voices: VOICES, storesAudio: false }, { headers })
    if (url.pathname !== '/speech') return new Response('Not found', { status: 404, headers })
    let input
    try { input = validateSpeech(url) } catch (error) { return new Response(error.message, { status: 400, headers }) }
    const ip = request.headers.get('CF-Connecting-IP') || 'local'
    const now = Date.now()
    if (requests.size > 1024) for (const [key, value] of requests) if (value.until < now) requests.delete(key)
    const count = requests.get(ip) || { until: now + 60000, count: 0 }
    if (count.until < now) { count.until = now + 60000; count.count = 0 }
    if (++count.count > 90) return new Response('Please retry shortly.', { status: 429, headers })
    requests.set(ip, count)
    try {
      const audio = await streamSpeech(input.text, input.voice, connect)
      // Keep only this request in memory; verify audio before returning a success response.
      const bytes = await new Response(audio).arrayBuffer()
      if (!bytes.byteLength) throw new Error('Empty voice response.')
      return new Response(bytes, { headers: { ...headers, 'Content-Type': 'audio/mpeg' } })
    } catch {
      return new Response('Microsoft voice is temporarily unavailable.', { status: 502, headers })
    }
  }
}

export default { fetch: createHandler() }
