// Protocol adapted from @andresaya/edge-tts 1.9.1, GPL-3.0-only.
// https://github.com/andresayac/edge-tts
const VOICES = ['ja-JP-NanamiNeural', 'ja-JP-KeitaNeural']
const ORIGINS = new Set(['https://fbyxdyn.github.io', 'http://127.0.0.1:5567', 'http://localhost:5567'])
const TOKEN = '6A5AA1D4EAFF4E9FB37E23D68491D6F4' // Public Edge client identifier, not a private API key.
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0'
const requests = new Map()
const decoder = new TextDecoder()

export const AUDITION_HTML = String.raw`<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>日语试音 · QuietSpell</title>
<meta name="description" content="试听微软 Nanami 女声和 Keita 男声，与 QuietSpell 学习网站使用相同音源。">
<style>
:root{color-scheme:light;font-family:Inter,"Segoe UI","Microsoft YaHei",system-ui,sans-serif;color:#172337;background:#f3f6fb;font-synthesis:none}
*{box-sizing:border-box}body{margin:0;min-height:100vh}button,input,textarea,select{font:inherit}button,a,input,textarea,select{-webkit-tap-highlight-color:transparent}button{cursor:pointer}button:disabled{cursor:default;opacity:.55}a{color:#255acb;text-decoration:none}a:hover{text-decoration:underline}
.page{max-width:840px;margin:auto;padding:30px 24px 40px}.top{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:42px}.brand{font-size:19px;font-weight:750;letter-spacing:-.5px;display:flex;align-items:center;gap:10px;color:#1b2b46}.logo{width:32px;height:32px;border-radius:10px;background:#2659d4;color:white;display:grid;place-items:center;font-size:20px}.health{display:flex;align-items:center;gap:7px;font-size:13px;color:#526277}.dot{width:7px;height:7px;border-radius:50%;background:#8795a8}.ready .dot{background:#278459}.offline .dot{background:#c86938}
.eyebrow{font-size:12px;letter-spacing:2px;color:#3764bc;font-weight:700;margin:0 0 10px}h1{font-size:clamp(28px,5vw,38px);line-height:1.25;letter-spacing:-1px;margin:0 0 12px}.intro{font-size:15px;line-height:1.75;color:#657184;margin:0 0 26px}.panel{background:white;border:1px solid #e1e7f0;border-radius:22px;padding:28px;box-shadow:0 12px 34px #1d365407}.section-title{display:block;font-size:14px;font-weight:650;margin:0 0 13px}.voices{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:26px}.voice-input{position:absolute;width:1px;height:1px;opacity:0}.voice{position:relative;border:1.5px solid #e0e6ef;border-radius:15px;padding:18px;display:flex;gap:13px;align-items:center;cursor:pointer;transition:border-color .15s,background .15s}.voice-input:checked+.voice{border-color:#3264d8;background:#f3f7ff}.voice-input:focus-visible+.voice{outline:3px solid #9bb9ff;outline-offset:3px}.avatar{width:42px;height:42px;flex-shrink:0;display:grid;place-items:center;border-radius:50%;background:#e3ecff;color:#3159b4;font-weight:650;font-size:19px}.keita{background:#e3edf0;color:#326575}.voice-name{font-size:16px;font-weight:700}.voice-meta{display:block;color:#6b7789;font-size:13px;margin-top:4px}.check{margin-left:auto;width:17px;height:17px;border-radius:50%;border:1.5px solid #bec8d9;flex-shrink:0}.voice-input:checked+.voice .check{border:5px solid #3264d8;background:white}
.text-head{display:flex;justify-content:space-between;align-items:center}.count{font-size:12px;color:#8590a1}textarea{display:block;width:100%;resize:vertical;min-height:128px;max-height:320px;border:1px solid #d6dfec;border-radius:12px;padding:15px 16px;font-size:16px;line-height:1.8;color:#233047;background:#fcfdff;outline:none}textarea:focus{border-color:#4677df;box-shadow:0 0 0 3px #e6eeff}.samples{display:flex;flex-wrap:wrap;gap:8px;margin:11px 0 22px}.sample{font-size:14px;color:#5a6c87;background:#f4f7fb;border:1px solid #e8edf4;border-radius:7px;min-height:40px;padding:5px 10px}.sample:hover{background:#eaf0fb}
.options{display:flex;align-items:center;gap:20px;flex-wrap:wrap;margin-bottom:20px}.option{display:flex;align-items:center;gap:9px;font-size:13px;color:#657184}.option select{min-height:36px;border:1px solid #dce3ed;border-radius:8px;padding:5px 9px;background:white;color:#263a59}.option input{accent-color:#3264d8;max-width:105px}output{min-width:36px;color:#526882}.actions{display:flex;gap:10px;align-items:center}.primary,.secondary{min-height:46px;border-radius:10px;padding:11px 22px;font-weight:650;font-size:14px}.primary{background:#285bd0;color:white;border:1px solid #285bd0;box-shadow:0 4px 10px #285bd01c}.primary:hover{background:#204db8}.secondary{background:white;color:#526379;border:1px solid #dce3ed}.status{font-size:13px;color:#6d7c90;line-height:1.6;margin:14px 0 6px;min-height:21px}.status.error{color:#b34b36}audio{display:block;width:100%;height:43px;margin:12px 0 0}.foot{display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;font-size:12px;color:#7c889a;padding:20px 2px;line-height:1.7}.back{font-size:13px;color:#3b62a4}.note{margin:8px 0 0;color:#7c889a;font-size:12px;line-height:1.8}
@media(max-width:560px){.page{padding:20px 16px 24px}.top{margin-bottom:32px}.panel{padding:20px 16px;border-radius:17px}.voices{gap:10px}.voice{padding:13px 10px;gap:9px}.avatar{width:32px;height:32px;font-size:15px}.voice-name{font-size:15px}.voice-meta{font-size:12px}.check{width:15px;height:15px}.intro{font-size:14px}.option input{max-width:90px}.option select{min-height:44px}.actions .primary{flex:1}.primary,.secondary{min-height:48px}.foot{padding-top:16px}.brand{font-size:18px}.health{font-size:12px}.samples{gap:6px}.sample{min-height:44px}}
</style>
</head>
<body><main class="page">
<header class="top"><a class="brand" href="/"><span class="logo" aria-hidden="true">♪</span>QuietSpell</a><div class="health" id="health"><span class="dot" aria-hidden="true"></span><span id="health-label">检测服务中</span></div></header>
<p class="eyebrow">JAPANESE VOICE STUDIO</p><h1>选一个喜欢的日语声音</h1><p class="intro">试听 Nanami 女声和 Keita 男声。这里与学习网站使用相同音源，手机、电脑都可以直接播放。</p>
<section class="panel" aria-label="日语试音面板">
<span class="section-title" id="voice-label">选择音色</span><div class="voices" role="radiogroup" aria-labelledby="voice-label">
<div><input class="voice-input" type="radio" name="voice" value="ja-JP-NanamiNeural" id="nanami" checked><label class="voice" for="nanami"><span class="avatar" aria-hidden="true">N</span><span><span class="voice-name">Nanami</span><span class="voice-meta">微软 · 日语女声</span></span><span class="check" aria-hidden="true"></span></label></div>
<div><input class="voice-input" type="radio" name="voice" value="ja-JP-KeitaNeural" id="keita"><label class="voice" for="keita"><span class="avatar keita" aria-hidden="true">K</span><span><span class="voice-name">Keita</span><span class="voice-meta">微软 · 日语男声</span></span><span class="check" aria-hidden="true"></span></label></div>
</div>
<div class="text-head"><label class="section-title" for="speech-text">想听哪句话？</label><span class="count" id="count">0 / 300</span></div>
<textarea id="speech-text" lang="ja" maxlength="300" spellcheck="false">こんにちは。日本語の勉強を始めましょう。毎日少しずつ練習すると、上手になります。</textarea>
<div class="samples" aria-label="选择试音例句"><button type="button" class="sample" data-sample="0">日常问候</button><button type="button" class="sample" data-sample="1">数字与时间</button><button type="button" class="sample" data-sample="2">学习例句</button></div>
<div class="options"><label class="option" for="rate">语速<select id="rate"><option value="0.75">0.75 倍</option><option value="1" selected>正常</option><option value="1.25">1.25 倍</option><option value="1.5">1.5 倍</option></select></label><label class="option" for="volume">音量<input type="range" min="0" max="100" value="100" id="volume"><output id="volume-label" for="volume">100%</output></label></div>
<div class="actions"><button type="button" class="primary" id="play">播放试听</button><button type="button" class="secondary" id="stop" disabled>停止</button></div>
<p class="status" id="status" role="status" aria-live="polite">选择音色后，点击播放试听。</p><audio id="player" controls controlslist="nodownload" playsinline webkit-playsinline preload="none" aria-label="日语试听播放器"></audio>
<p class="note">手机首次播放需要点击按钮。学习网站的音色可在「学习设置」中切换。</p>
</section>
<footer class="foot"><span>实时生成并播放，不保存音频。</span><a class="back" href="https://fbyxdyn.github.io/QuietSpell/japanese/" target="_blank" rel="noopener noreferrer">打开 QuietSpell 学习网站</a></footer>
</main>
<script>
const byId = id => document.getElementById(id);
const audio = byId('player'), text = byId('speech-text'), status = byId('status');
const samples = ['こんにちは。日本語の勉強を始めましょう。毎日少しずつ練習すると、上手になります。','明日の朝九時に、駅の前で会いましょう。','毎日少しずつ練習すると、日本語が上手になります。'];
let sequence = 0, timeout, pendingFetch, objectURL;
const clips = new Map();
const primer = 'data:audio/wav;base64,UklGRsQAAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA';
const say = (message, error) => { status.textContent = message; status.classList.toggle('error', !!error); };
const count = () => { byId('count').textContent = Array.from(text.value).length + ' / 300'; byId('play').disabled = !text.value.trim(); };
const selected = () => document.querySelector('input[name="voice"]:checked').value;
const voiceName = () => selected() === 'ja-JP-KeitaNeural' ? 'Keita 男声' : 'Nanami 女声';
function stop(message) { sequence++; clearTimeout(timeout); if (pendingFetch) pendingFetch.abort(); pendingFetch = null; audio.onplaying = null; audio.onended = null; audio.onerror = null; audio.pause(); audio.removeAttribute('src'); audio.load(); if (objectURL) URL.revokeObjectURL(objectURL); objectURL = null; byId('stop').disabled = true; if (message) say(message); }
try { const saved = localStorage.getItem('quietspell-audition-voice'); if (saved === 'ja-JP-KeitaNeural') byId('keita').checked = true; } catch {}
document.querySelectorAll('input[name="voice"]').forEach(input => input.addEventListener('change', () => { stop('已选择 ' + voiceName() + '，点击播放试听。'); try { localStorage.setItem('quietspell-audition-voice', selected()); } catch {} }));
document.querySelectorAll('[data-sample]').forEach(button => button.addEventListener('click', () => { stop('已换好例句，点击播放试听。'); text.value = samples[Number(button.dataset.sample)]; count(); }));
text.addEventListener('input', count);
byId('rate').addEventListener('change', () => { audio.playbackRate = Number(byId('rate').value); });
byId('volume').addEventListener('input', () => { audio.volume = Number(byId('volume').value) / 100; byId('volume-label').value = byId('volume').value + '%'; });
byId('stop').addEventListener('click', () => stop('已停止。'));
byId('play').addEventListener('click', () => {
  if (!text.value.trim()) { text.focus(); return; }
  stop(); const active = sequence; const name = voiceName();
  const url = new URL('/speech', location.origin); url.searchParams.set('voice', selected()); url.searchParams.set('text', text.value.trim());
  audio.volume = Number(byId('volume').value) / 100; audio.playbackRate = Number(byId('rate').value); byId('stop').disabled = false;
  const controller = new AbortController(); pendingFetch = controller;
  say('正在连接 ' + name + '…');
  const failed = error => { if (active !== sequence) return; clearTimeout(timeout); controller.abort(); clips.delete(url.href); byId('stop').disabled = true; say(error && error.name === 'NotAllowedError' ? '请再次点击「播放试听」开启声音。' : '这次未能播放，请检查网络后重试。', true); };
  timeout = setTimeout(() => { if (active === sequence) { stop(); say('连接超时，请稍后重试。', true); } }, 15000);
  // Prime on the tap, then play an in-page object URL rather than a remote file URL.
  audio.src = primer; const primed = audio.play();
  const load = async () => {
    const cached = clips.get(url.href); if (cached) return cached;
    const response = await fetch(url.href, { signal: controller.signal, credentials: 'omit', cache: 'no-store' });
    if (!response.ok || !(response.headers.get('Content-Type') || '').startsWith('audio/')) throw new Error('Voice unavailable');
    const blob = await response.blob(); if (blob.size < 256 || controller.signal.aborted) throw new Error('Empty audio');
    clips.set(url.href, blob); while (clips.size > 8) clips.delete(clips.keys().next().value); return blob;
  };
  Promise.all([load(), primed]).then(([blob]) => {
    if (active !== sequence || controller.signal.aborted) return;
    objectURL = URL.createObjectURL(blob); audio.src = objectURL;
    audio.onplaying = () => { if (active === sequence) { clearTimeout(timeout); say('正在播放 · ' + name); } };
    audio.onended = () => { if (active === sequence) { byId('stop').disabled = true; say('播放完毕，可以换一个音色听听。'); } };
    audio.onerror = failed; return audio.play();
  }).catch(failed);
});
fetch('/health').then(response => response.ok ? response.json() : Promise.reject()).then(data => { if (!Array.isArray(data.voices)) throw new Error(); byId('health').className = 'health ready'; byId('health-label').textContent = '服务已就绪'; }).catch(() => { byId('health').className = 'health offline'; byId('health-label').textContent = '请检查网络'; });
count();
</script></body></html>`

export function validateSpeech(url) {
  const text = (url.searchParams.get('text') || '').normalize('NFC').trim()
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, ' ')
  const voice = url.searchParams.get('voice') || VOICES[0]
  if (!text || Array.from(text).length > 1000) throw new Error('Text must contain 1–1000 characters.')
  if (!VOICES.includes(voice)) throw new Error('Unsupported voice.')
  return { text, voice }
}

function escapeXML(text) {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;')
}

export async function synthesisURL(now = Date.now()) {
  const ticks = Math.floor(now / 1000) + 11644473600
  const rounded = (ticks - ticks % 300) * 10000000
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`${rounded}${TOKEN}`))
  const signature = [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('').toUpperCase()
  return 'https://api.msedgeservices.com/tts/cognitiveservices/websocket/v1?' + new URLSearchParams({
    'Ocp-Apim-Subscription-Key': TOKEN, 'Sec-MS-GEC': signature,
    'Sec-MS-GEC-Version': '1-155.0.4283.45', ConnectionId: crypto.randomUUID().replaceAll('-', ''),
  })
}

export async function openMicrosoftSocket(url) {
  const response = await fetch(url, {
    headers: {
      Upgrade: 'websocket', 'User-Agent': USER_AGENT,
      Origin: 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
      Cookie: 'MUID=' + crypto.randomUUID().replaceAll('-', '').toUpperCase(),
    },
    signal: AbortSignal.timeout(12000),
  })
  if (response.status !== 101 || !response.webSocket) throw new Error('Microsoft voice connection failed.')
  const socket = response.webSocket
  try { socket.binaryType = 'arraybuffer' } catch {}
  socket.accept()
  return socket
}

export async function streamSpeech(text, voice, connect = openMicrosoftSocket) {
  const socket = await connect(await synthesisURL())
  const requestId = crypto.randomUUID().replaceAll('-', '')
  let timeout, finished = false, received = false
  const close = () => { try { socket.close(1000, 'Complete') } catch {} }
  const stream = new ReadableStream({
    start(controller) {
      const fail = () => {
        if (finished) return
        finished = true
        clearTimeout(timeout)
        controller.error(new Error('Microsoft voice playback interrupted.'))
        close()
      }
      const finish = () => {
        if (finished) return
        if (!received) { fail(); return }
        finished = true
        clearTimeout(timeout)
        controller.close()
        close()
      }
      const touch = () => { clearTimeout(timeout); timeout = setTimeout(fail, 15000) }
      let messages = Promise.resolve()
      socket.addEventListener('message', event => {
        messages = messages.then(async () => {
        if (finished) return
        touch()
        if (typeof event.data === 'string') {
          if (/Path:turn.end\r?\n/i.test(event.data + '\r\n')) finish()
          return
        }
        const data = typeof event.data?.arrayBuffer === 'function' ? await event.data.arrayBuffer() : event.data
        const bytes = ArrayBuffer.isView(data)
          ? new Uint8Array(data.buffer, data.byteOffset, data.byteLength)
          : new Uint8Array(data)
        if (bytes.length < 2) return
        const length = (bytes[0] << 8) | bytes[1]
        if (2 + length > bytes.length) return
        const header = decoder.decode(bytes.subarray(2, 2 + length))
        if (/Path:audio\r?\n/i.test(header + '\r\n') && bytes.length > 2 + length) {
          received = true
          controller.enqueue(bytes.slice(2 + length))
        }
        }).catch(fail)
      })
      socket.addEventListener('error', fail)
      socket.addEventListener('close', () => { void messages.then(() => { if (!finished) received ? finish() : fail() }) })
      const timestamp = new Date().toUTCString()
      socket.send(`X-Timestamp:${timestamp}\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n` +
        JSON.stringify({ context: { synthesis: { audio: { metadataoptions: { sentenceBoundaryEnabled: false, wordBoundaryEnabled: false }, outputFormat: 'audio-24khz-48kbitrate-mono-mp3' } } } }))
      socket.send(`X-RequestId:${requestId}\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:${timestamp}\r\nPath:ssml\r\n\r\n` +
        `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="ja-JP"><voice name="${voice}"><prosody rate="+0%" pitch="+0Hz" volume="+0%">${escapeXML(text)}</prosody></voice></speak>`)
      touch()
    },
    cancel() { finished = true; clearTimeout(timeout); close() },
  })
  return stream
}

export function createHandler(connect = openMicrosoftSocket) {
  return async function handle(request) {
    const url = new URL(request.url)
    const origin = request.headers.get('Origin')
    const allowed = !origin || ORIGINS.has(origin) || origin === url.origin
    const headers = { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', Vary: 'Origin' }
    if (origin && allowed) headers['Access-Control-Allow-Origin'] = origin
    if (!allowed) return new Response('Origin not allowed', { status: 403, headers })
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: { ...headers, 'Access-Control-Allow-Methods': 'GET, OPTIONS' } })
    if (request.method !== 'GET') return new Response('Method not allowed', { status: 405, headers })
    if (url.pathname === '/') return new Response(AUDITION_HTML, { headers: { ...headers, 'Content-Type': 'text/html; charset=utf-8' } })
    if (url.pathname === '/health') return Response.json({ service: 'QuietSpell Japanese voice', voices: VOICES, storesAudio: false }, { headers })
    if (url.pathname !== '/speech') return new Response('Not found', { status: 404, headers })
    let input
    try { input = validateSpeech(url) } catch (error) { return new Response(error.message, { status: 400, headers }) }
    const ip = request.headers.get('CF-Connecting-IP') || 'local'
    const now = Date.now()
    if (requests.size > 1024) for (const [key, value] of requests) if (value.until < now) requests.delete(key)
    const count = requests.get(ip) || { until: now + 60000, count: 0 }
    if (count.until < now) { count.until = now + 60000; count.count = 0 }
    if (++count.count > 90) return new Response('Please retry shortly.', { status: 429, headers })
    requests.set(ip, count)
    try {
      const audio = await streamSpeech(input.text, input.voice, connect)
      // Keep only this request in memory; verify audio before returning a success response.
      const bytes = await new Response(audio).arrayBuffer()
      if (!bytes.byteLength) throw new Error('Empty voice response.')
      return new Response(bytes, { headers: { ...headers, 'Content-Type': 'audio/mpeg', 'Content-Disposition': 'inline; filename="quietspell-japanese.mp3"' } })
    } catch (error) {
      console.error('voice_upstream_failed', error?.name, error?.message)
      return new Response('Microsoft voice is temporarily unavailable.', { status: 502, headers })
    }
  }
}

export default { fetch: createHandler() }
