# uniCloud 支付宝云语音适配

本地准备版，尚未部署。必须先由主窗口完成账号／服务空间开通及手机不挂 VPN
的纯 health 连通测试，再部署语音函数。不要把此包上传到同步函数的位置。

用户要求不产生费用。本包已接入 TTS 与 Sync 共用的持久预算模块，但云端预算与
平台停用设置尚未核验，因而**不能直接上线**。须先由主窗口核对平台免费额度、
停用条件与通知延迟；应用拒绝请求及预算数据库读写本身也消耗平台资源。
`/speech` 默认关闭并返回503，不会连接微软；只有主窗口核验全部预算与平台停用
设置后，才能在服务端设置 `QUIETSPELL_TTS_ENABLED=true`。不要在网页里设置该开关。

共享模块打包为 `quota/index.js`，使用同一空间的 `quietspell_service_budget` 集合。
主窗口须部署该集合的客户端全拒绝 schema；不能用客户端可写集合做预算依据。
每次调用先预留完整20秒计算与最大出网，后按实际时长加1秒余量结算；预算读取
最多2秒、结算最多1秒，失败时不放行上游合成。预留失败但迟到写入的额度不返还。
所有调用（含 health、关闭合成和错误请求）均计数；无法统计未进入函数的网关请求。
最大音频2MiB按Base64扩张后再加4KiB响应信封及64KiB传输余量预留；结算按整个
集成响应JSON字节数加64KiB估算。这是保守应用估计，不是平台精确出网计费公式。
本包不配置平台硬停用，也不承诺零费用；未核验前不得启用业务。

运行环境：Nodejs18；云函数名建议 `quietspell-japanese-voice`，HTTP URL 化路径
使用 `/voice-quietspell`，避免与同步服务 `/quietspell` 前缀重叠。`/health` 返回两种音色，`/speech?text=...&voice=...`
返回 MP3。URL 化会移除配置前缀，再将剩余路径放入 `event.path`。

预算参考配置：128 MB、云函数超时20秒；适配层15秒绝对截止并中止上游连接，
每次最多300字。客户端本来按100字分段，不影响语法句子。最坏运行时预算应至少
按128 MB × 20秒＝2.5 GB·s／次预留，另计调用、平台开销及可能的出网资源；
这只是保守规划值，实际计量规则由平台决定，不是零费用保证。

`index.js` 将 URL 化事件转换为已有语音 Worker 的请求；只替换 WebSocket
握手实现，继续复用文本验证、音色白名单、CORS、MP3 帧解析和错误处理。
`ws` 依赖固定为 8.23.0，由支付宝云按 package.json 安装。TLS 证书校验开启，
不跟随上游重定向，客户端不能指定任意上游 URL。
适配层关闭上游错误日志，不打印请求体、文本、Cookie或凭据；平台自身访问日志
与采集设置仍需主窗口另行关闭／核对。

音频仅在当前请求内存中存在，返回 `mpserverlessComposedResponse:true`、
`isBase64Encoded:true` 的二进制集成响应，并保留 `Content-Type:audio/mpeg`、
`Content-Disposition:inline`、`Cache-Control:no-store`。不写磁盘／云存储，
无需 GitHub Token 或支付宝应用密钥。服务端 Microsoft 请求所用的公开 Edge
客户端标识不是用户私钥，沿用现有协议；不代表正式 Azure 商业 API。

前端仍用 fetch → Blob／WebAudio 播放，不导航到 MP3 地址，防止手机浏览器
把响应当作独立下载。试听页配置必须保留 `/voice-quietspell` 前缀，不可只取域名。

上线验证顺序：手机 health 可达 → 云端向 Microsoft WebSocket 可达 → Nanami
与 Keita 实际都返回非空 MP3 → 用语法长句验证 → 接入 GitHub 试听页与学习页。
本地模拟测试不等于上述云端步骤已经通过。

限制：平台默认域名可能共享限流；现有 90 次／分钟／IP 是进程内尽力限制，
不是分布式配额。若云端拿不到可信 clientIP，会共用一个进程内限流桶。
HTTP 请求本身受平台计费与用量规则约束；本包不创建或购买任何资源。

官方说明：
- https://doc.dcloud.net.cn/uniCloud/http.html
- https://doc.dcloud.net.cn/uniCloud/cf-functions.html
- https://doc.dcloud.net.cn/uniCloud/faq.html

构建包由父目录 `node build-unicloud.mjs` 生成；不要手工复制不同版本的协议代码。
License: GPL-3.0-only；ws: MIT。
