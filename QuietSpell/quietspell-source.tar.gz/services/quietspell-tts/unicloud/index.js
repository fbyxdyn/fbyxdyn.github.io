'use strict'
// uniCloud URL integration adapter. Audio stays in memory and is returned as Base64.
const { webcrypto } = require('node:crypto')
const { isIP } = require('node:net')
if (!globalThis.crypto) globalThis.crypto = webcrypto
const MAX_AUDIO_BYTES = 2 * 1024 * 1024
// Includes the Base64 integration envelope and conservative transport overhead.
// This application estimate is not the provider's billing meter.
const TRANSPORT_ALLOWANCE_BYTES = 64 * 1024
const INTEGRATION_ENVELOPE_BYTES = 4096
const MAX_SPEECH_OUTBOUND_BYTES = Math.ceil(MAX_AUDIO_BYTES / 3) * 4 + TRANSPORT_ALLOWANCE_BYTES + INTEGRATION_ENVELOPE_BYTES

async function bounded(operation, milliseconds) {
  let timer
  try {
    return await Promise.race([Promise.resolve().then(operation), new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('Budget operation unavailable.')), milliseconds)
    })])
  } finally { clearTimeout(timer) }
}

function integrated(status, value, headers = {}) {
  return { mpserverlessComposedResponse: true, statusCode: status, isBase64Encoded: false,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers }, body: JSON.stringify(value) }
}

function createNodeConnector(WebSocket, getHeaders, { signal } = {}) {
  return url => new Promise((resolve, reject) => {
    // The synthesis module is the only producer of this URL; never accept a client target.
    const target = new URL(url)
    if (target.protocol !== 'https:' || target.port || target.username || target.password || target.hostname !== 'api.msedgeservices.com' ||
        target.pathname !== '/tts/cognitiveservices/websocket/v1') {
      reject(new Error('Unsupported voice upstream.')); return
    }
    target.protocol = 'wss:'
    let socket
    try {
      if (signal?.aborted) { reject(new Error('Voice request canceled.')); return }
      socket = new WebSocket(target.href, { headers: getHeaders(), handshakeTimeout: 12000,
        maxPayload: 2 * 1024 * 1024, followRedirects: false, perMessageDeflate: false, rejectUnauthorized: true })
      socket.binaryType = 'arraybuffer'
      socket.once('open', () => resolve(socket))
      socket.on('error', () => reject(new Error('Microsoft voice connection failed.')))
      const abort = () => {
        reject(new Error('Voice request canceled.'))
        try { if (typeof socket.terminate === 'function') socket.terminate(); else socket.close() } catch {}
      }
      signal?.addEventListener('abort', abort, { once: true })
      socket.once('close', () => signal?.removeEventListener('abort', abort))
    } catch { reject(new Error('Microsoft voice connection failed.')) }
  })
}

function createUniCloudHandler({ loadWorker = () => import('./voice-worker.mjs'), WebSocketClass, deadlineMs = 15000,
  speechEnabled = () => process.env.QUIETSPELL_TTS_ENABLED === 'true',
  loadQuota = () => require('./quota/index.js').createUniCloudQuota(globalThis.uniCloud) } = {}) {
  let workerPromise, quota
  async function runRequest(event = {}, context = {}) {
    let deadline, controller, onAbort
    try {
      if (typeof Request !== 'function' || typeof Response !== 'function') {
        return integrated(503, { error: 'Use the Nodejs18 runtime.' })
      }
      const method = event.httpMethod
      const path = event.path
      if (!['GET', 'OPTIONS', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD'].includes(method) ||
          typeof path !== 'string' || path.length > 1000 || !path.startsWith('/') || /[?#\\\u0000-\u0020]/.test(path)) {
        return integrated(400, { error: 'Invalid HTTP integration request.' })
      }
      // The URL prefix is removed by uniCloud before event.path reaches this function.
      // Root is a machine-readable health response; the audition UI lives on GitHub.
      const normalized = path === '/' ? '/health' : path
      // Outbound synthesis stays disabled until shared free-tier budgets are approved.
      if (normalized === '/speech' && !speechEnabled()) return integrated(503, { error: 'Real-time voice is not enabled yet.' })
      const url = new URL('https://voice-function.invalid' + normalized)
      for (const [key, value] of Object.entries(event.queryStringParameters || {})) {
        if (typeof value !== 'string') return integrated(400, { error: 'Invalid query parameters.' })
        url.searchParams.set(key, value)
      }
      if (normalized === '/speech' && Array.from(url.searchParams.get('text') || '').length > 300) {
        return integrated(400, { error: 'Text must contain at most 300 characters per request.' })
      }
      const headers = new Headers()
      for (const [key, value] of Object.entries(event.headers || {})) {
        // Never forward a caller-provided CF-Connecting-IP or other proxy identity.
        if (key.toLowerCase() === 'origin' && typeof value === 'string') headers.set('Origin', value)
      }
      const ip = context.clientIP || context.CLIENTIP
      if (typeof ip === 'string' && isIP(ip)) headers.set('CF-Connecting-IP', ip)
      const request = new Request(url, { method, headers })
      controller = new AbortController()
      const timedOut = new Promise((_, reject) => {
        onAbort = () => reject(new Error('Voice request deadline exceeded.'))
        controller.signal.addEventListener('abort', onAbort, { once: true })
      })
      deadline = setTimeout(() => controller.abort(), deadlineMs)
      workerPromise ??= loadWorker()
      const operation = (async () => {
        const worker = await workerPromise
        const Socket = WebSocketClass || require('ws')
        const handle = worker.createHandler(createNodeConnector(Socket, worker.microsoftSocketHeaders, { signal: controller.signal }), { onUpstreamError: () => {} })
        return handle(request)
      })()
      const response = await Promise.race([operation, timedOut])
      const responseHeaders = Object.fromEntries(response.headers.entries())
      const binary = (response.headers.get('Content-Type') || '').toLowerCase().startsWith('audio/')
      const bytes = Buffer.from(await response.arrayBuffer())
      if (bytes.length > MAX_AUDIO_BYTES) return integrated(502, { error: 'Voice response unavailable.' })
      return { mpserverlessComposedResponse: true, statusCode: response.status,
        isBase64Encoded: binary, headers: responseHeaders, body: binary ? bytes.toString('base64') : bytes.toString('utf8') }
    } catch {
      // No request text, upstream URL, cookies or response bodies are logged or reflected.
      return integrated(502, { error: 'Japanese voice is temporarily unavailable.' })
    } finally {
      clearTimeout(deadline)
      if (controller) {
        controller.signal.removeEventListener('abort', onAbort)
        controller.abort()
      }
    }
  }
  return async function main(event = {}, context = {}) {
    const started = Date.now()
    let ticket, response
    try {
      quota ??= loadQuota()
      ticket = await bounded(() => quota.reserve({ service: 'voice', memoryMB: 128, timeoutSeconds: 20,
        maxOutboundBytes: event.path === '/speech' ? MAX_SPEECH_OUTBOUND_BYTES : TRANSPORT_ALLOWANCE_BYTES + INTEGRATION_ENVELOPE_BYTES }), 2000)
      if (!ticket) throw new Error('Missing budget reservation.')
      response = await runRequest(event, context)
    } catch (error) {
      response = integrated(error?.status === 429 ? 429 : 503, { error: 'Voice service budget is unavailable. Please use the original voice.' })
    } finally {
      if (ticket) {
        // Failed settlement keeps the reservation; a late settlement can only account
        // for this completed request. Health checks and rejections also consume calls.
        try { await bounded(() => quota.settle(ticket, { durationMs: Date.now() - started,
          outboundBytes: Buffer.byteLength(JSON.stringify(response || {}), 'utf8') + TRANSPORT_ALLOWANCE_BYTES }), 1000) } catch {}
      }
    }
    return response
  }
}

exports.createNodeConnector = createNodeConnector
exports.createUniCloudHandler = createUniCloudHandler
exports.main = createUniCloudHandler()
