import assert from 'node:assert/strict'
import test from 'node:test'
import { validateSpeech, synthesisURL, createHandler } from './worker/index.mjs'

function fakeSocket(blob = false) {
  const socket = new EventTarget()
  socket.sent = []
  socket.close = () => { socket.closed = true }
  socket.send = message => {
    socket.sent.push(message)
    if (socket.sent.length !== 2) return
    queueMicrotask(() => {
      const header = new TextEncoder().encode('Path:audio\r\nContent-Type:audio/mpeg\r\n')
      const frame = new Uint8Array(2 + header.length + 4)
      frame[0] = header.length >> 8; frame[1] = header.length & 255
      frame.set(header, 2); frame.set([255, 243, 232, 196], 2 + header.length)
      socket.dispatchEvent(new MessageEvent('message', { data: blob ? new Blob([frame]) : frame.buffer }))
      socket.dispatchEvent(new MessageEvent('message', { data: 'Path:turn.end\r\n\r\n' }))
    })
  }
  return socket
}

await test('relay accepts exactly Nanami/Keita and rejects empty or oversized requests', () => {
  for (const voice of ['ja-JP-NanamiNeural', 'ja-JP-KeitaNeural']) {
    assert.equal(validateSpeech(new URL('https://relay/speech?' + new URLSearchParams({ text: 'こんにちは', voice }))).voice, voice)
  }
  for (const params of [{ text: '' }, { text: 'あ'.repeat(1001) }, { text: 'こんにちは', voice: 'untrusted' }]) {
    assert.throws(() => validateSpeech(new URL('https://relay/speech?' + new URLSearchParams(params))))
  }
})
await test('relay emits MP3 frames and escapes request text in SSML', async () => {
  const socket = fakeSocket()
  const response = await createHandler(async () => socket)(new Request('https://relay/speech?' + new URLSearchParams({ text: '<愛情>&', voice: 'ja-JP-KeitaNeural' })))
  assert.equal(response.headers.get('Content-Type'), 'audio/mpeg')
  assert.equal(response.headers.get('Cache-Control'), 'no-store')
  assert.deepEqual(new Uint8Array(await response.arrayBuffer()), new Uint8Array([255, 243, 232, 196]))
  assert.match(socket.sent[1], /ja-JP-KeitaNeural/)
  assert.match(socket.sent[1], /&lt;愛情&gt;&amp;/)
  assert.ok(socket.closed)
})
await test('unknown origins and malformed inputs never contact Microsoft', async () => {
  let connected = 0
  const handler = createHandler(async () => { connected++; return fakeSocket() })
  assert.equal((await handler(new Request('https://relay/speech?text=こんにちは', { headers: { Origin: 'https://unrelated.example' } }))).status, 403)
  assert.equal((await handler(new Request('https://relay/speech?text=こんにちは&voice=bad'))).status, 400)
  assert.equal(connected, 0)
})
await test('cloud WebSocket Blob frames are decoded before turn.end closes the audio', async () => {
  const response = await createHandler(async () => fakeSocket(true))(new Request('https://relay/speech?text=こんにちは'))
  assert.deepEqual(new Uint8Array(await response.arrayBuffer()), new Uint8Array([255, 243, 232, 196]))
})
await test('upstream handshake failures return a non-audio failure for original-voice fallback', async () => {
  const response = await createHandler(async () => { throw new Error('offline') })(new Request('https://relay/speech?text=こんにちは'))
  assert.equal(response.status, 502)
})
await test('signature window and connection IDs match the service protocol', async () => {
  const first = new URL(await synthesisURL(1700000000000))
  const second = new URL(await synthesisURL(1700000001000))
  assert.equal(first.searchParams.get('Sec-MS-GEC'), second.searchParams.get('Sec-MS-GEC'))
  assert.notEqual(first.searchParams.get('ConnectionId'), second.searchParams.get('ConnectionId'))
})
