import assert from 'node:assert/strict'
import test from 'node:test'
import { EventEmitter } from 'node:events'
import adapter from './unicloud/index.js'
import * as worker from './worker/index.mjs'
import quotaModule from '../quietspell-unicloud/quota/index.js'

const origin = 'https://fbyxdyn.github.io'
// In-memory dependency for transport tests; production requires persistent quota.
const testBudget = { reserve: async () => ({ id: 'transport-test' }), settle: async () => true }
const loadQuota = () => testBudget
function fixture(broken = false, loadBudget = loadQuota) {
  const sockets = []
  class Socket extends EventEmitter {
    constructor(url, options) {
      super(); this.url = url; this.options = options; this.sent = []; sockets.push(this)
      queueMicrotask(() => this.emit(broken ? 'error' : 'open', broken ? new Error('test upstream failure') : undefined))
    }
    addEventListener(name, handler) { this.on(name, data => handler({ data })) }
    close() { this.closed = true; this.emit('close') }
    send(message) {
      this.sent.push(message)
      if (this.sent.length !== 2) return
      queueMicrotask(() => {
        const header = Buffer.from('Path:audio\r\nContent-Type:audio/mpeg\r\n')
        const frame = Buffer.alloc(2 + header.length + 4)
        frame.writeUInt16BE(header.length); header.copy(frame, 2); Buffer.from([255, 243, 232, 196]).copy(frame, 2 + header.length)
        this.emit('message', frame)
        this.emit('message', 'Path:turn.end\r\n\r\n')
      })
    }
  }
  const main = adapter.createUniCloudHandler({ loadWorker: async () => worker, WebSocketClass: Socket, speechEnabled: () => true, loadQuota: loadBudget })
  return { main, sockets }
}
function event(path, queryStringParameters = {}, headers = { origin }) {
  return { path, httpMethod: 'GET', queryStringParameters, headers }
}

await test('uniCloud root and health return composed JSON without opening Microsoft connections', async () => {
  const f = fixture()
  for (const path of ['/', '/health']) {
    const response = await f.main(event(path))
    assert.equal(response.mpserverlessComposedResponse, true)
    assert.equal(response.statusCode, 200)
    assert.equal(response.isBase64Encoded, false)
    assert.deepEqual(JSON.parse(response.body).voices, ['ja-JP-NanamiNeural', 'ja-JP-KeitaNeural'])
    assert.equal(response.headers['access-control-allow-origin'], origin)
    assert.equal(response.headers['cache-control'], 'no-store')
  }
  assert.equal(f.sockets.length, 0)
})

await test('Nanami and Keita return byte-exact MP3 through base64 integration, with secure Node WebSocket settings', async () => {
  const f = fixture()
  for (const voice of ['ja-JP-NanamiNeural', 'ja-JP-KeitaNeural']) {
    const response = await f.main(event('/speech', { text: 'はい、アイスクリーム。溶けないうちに早く食べてくださいね。', voice }))
    assert.equal(response.statusCode, 200)
    assert.equal(response.isBase64Encoded, true)
    assert.deepEqual(Buffer.from(response.body, 'base64'), Buffer.from([255, 243, 232, 196]))
    assert.equal(response.headers['content-type'], 'audio/mpeg')
    assert.match(response.headers['content-disposition'], /^inline;/)
    const socket = f.sockets.at(-1)
    assert.equal(new URL(socket.url).protocol, 'wss:')
    assert.equal(new URL(socket.url).hostname, 'api.msedgeservices.com')
    assert.equal(socket.options.rejectUnauthorized, true)
    assert.equal(socket.options.followRedirects, false)
    assert.equal(socket.options.handshakeTimeout, 12000)
    assert.match(socket.options.headers['User-Agent'], /Edg\//)
    assert.match(socket.sent[1], new RegExp(voice))
    assert.equal(socket.closed, true)
  }
})

await test('query text is passed exactly once and SSML metacharacters are escaped', async () => {
  const f = fixture()
  assert.equal((await f.main(event('/speech', { text: '<愛情>& + 100%' }))).statusCode, 200)
  assert.match(f.sockets[0].sent[1], /&lt;愛情&gt;&amp; \+ 100%/)
})

await test('malformed query, invalid voice, huge text and forbidden origin cannot contact Microsoft', async () => {
  const f = fixture()
  for (const [request, status] of [
    [event('/speech', { text: ['not', 'a string'] }), 400],
    [event('/speech', { text: 'こんにちは', voice: 'untrusted' }), 400],
    [event('/speech', { text: 'あ'.repeat(301) }), 400],
    [event('/speech', { text: 'こんにちは' }, { Origin: 'https://foreign.example' }), 403],
    [event('/speech?target=https://foreign.example'), 400],
    [event('//speech'), 404],
  ]) assert.equal((await f.main(request)).statusCode, status)
  assert.equal(f.sockets.length, 0)
})

await test('preflight and unsupported methods retain the original API policy', async () => {
  const f = fixture()
  const preflight = await f.main({ ...event('/speech'), httpMethod: 'OPTIONS' })
  assert.equal(preflight.statusCode, 204)
  assert.equal(preflight.headers['access-control-allow-origin'], origin)
  assert.equal(preflight.isBase64Encoded, false)
  assert.equal((await f.main({ ...event('/speech'), httpMethod: 'POST' })).statusCode, 405)
  assert.equal(f.sockets.length, 0)
})

await test('connector rejects arbitrary upstream destinations before constructing any socket', async () => {
  let opened = 0
  const connect = adapter.createNodeConnector(class { constructor() { opened++ } }, () => ({}))
  for (const target of ['https://foreign.example/tts/cognitiveservices/websocket/v1', 'http://api.msedgeservices.com/tts/cognitiveservices/websocket/v1', 'https://api.msedgeservices.com/other']) {
    await assert.rejects(connect(target), /Unsupported/)
  }
  assert.equal(opened, 0)
})

await test('caller proxy headers are dropped and only platform context clientIP is forwarded', async () => {
  const received = []
  const main = adapter.createUniCloudHandler({ loadQuota, WebSocketClass: class {}, loadWorker: async () => ({
    microsoftSocketHeaders: () => ({}), createHandler: () => request => {
      received.push(request); return Response.json({ ok: true })
    },
  }) })
  await main(event('/health', {}, { origin, 'CF-Connecting-IP': '192.0.2.99', authorization: 'never-forward-me' }), { clientIP: '192.0.2.10' })
  assert.equal(received[0].headers.get('CF-Connecting-IP'), '192.0.2.10')
  assert.equal(received[0].headers.get('Authorization'), null)
  await main(event('/health', {}, { 'CF-Connecting-IP': '192.0.2.99' }))
  assert.equal(received[1].headers.get('CF-Connecting-IP'), null)
})

await test('upstream errors remain non-audio failures rather than corrupt base64 successes', async () => {
  const f = fixture(true)
  const response = await f.main(event('/speech', { text: '接続確認' }))
  assert.equal(response.statusCode, 502)
  assert.equal(response.isBase64Encoded, false)
  assert.doesNotMatch(response.body, /test upstream failure|stack|Cookie/)
})

await test('synthesis remains disabled by default until the owner enables the budget-approved service', async () => {
  let loaded = 0
  const main = adapter.createUniCloudHandler({ loadWorker: async () => { loaded++; return worker }, speechEnabled: () => false, loadQuota })
  const response = await main(event('/speech', { text: 'こんにちは' }))
  assert.equal(response.statusCode, 503)
  assert.equal(loaded, 0)
})

await test('absolute deadline settles even if runtime module initialization never finishes', async t => {
  t.mock.timers.enable({ apis: ['setTimeout'] })
  const main = adapter.createUniCloudHandler({ loadWorker: () => new Promise(() => {}), speechEnabled: () => true, loadQuota })
  const pending = main(event('/health'))
  // The persistent reservation completes before the transport deadline begins.
  await new Promise(resolve => setImmediate(resolve))
  t.mock.timers.tick(15000)
  const response = await pending
  assert.equal(response.statusCode, 502)
  assert.equal(response.isBase64Encoded, false)
  t.mock.timers.reset()
})

await test('absolute deadline closes an already-open upstream socket instead of leaving background synthesis running', async t => {
  let socket
  let ready
  const started = new Promise(resolve => { ready = resolve })
  class StalledSocket extends EventEmitter {
    constructor() { super(); socket = this; this.sent = 0; queueMicrotask(() => this.emit('open')) }
    addEventListener(name, listener) { this.on(name, data => listener({ data })) }
    send() { if (++this.sent === 2) ready() }
    close() { this.closed = true; this.emit('close') }
  }
  t.mock.timers.enable({ apis: ['setTimeout'] })
  t.after(() => t.mock.timers.reset())
  const main = adapter.createUniCloudHandler({ loadWorker: async () => worker, WebSocketClass: StalledSocket, speechEnabled: () => true, loadQuota })
  const pending = main(event('/speech', { text: 'タイムアウト確認' }))
  await started
  assert.ok(socket)
  t.mock.timers.tick(15000)
  const response = await pending
  assert.equal(response.statusCode, 502)
  assert.equal(socket.closed, true)
  t.mock.timers.reset()
})

await test('missing, exhausted and unavailable persistent budgets fail closed before loading transport', async () => {
  for (const [loadBudget, status] of [
    [() => { throw new Error('missing store') }, 503],
    [() => ({ reserve: async () => { throw Object.assign(new Error('exhausted'), { status: 429 }) } }), 429],
    [() => ({ reserve: async () => null }), 503],
  ]) {
    let loaded = false
    const main = adapter.createUniCloudHandler({ loadQuota: loadBudget, speechEnabled: () => true,
      loadWorker: async () => { loaded = true; return worker } })
    assert.equal((await main(event('/speech', { text: 'こんにちは' }))).statusCode, status)
    assert.equal(loaded, false)
  }
})

await test('health, disabled synthesis and invalid requests also reserve and settle shared resources', async () => {
  const reservations = [], settlements = []
  const main = adapter.createUniCloudHandler({ loadWorker: async () => worker, WebSocketClass: class {}, speechEnabled: () => false,
    loadQuota: () => ({ reserve: async options => { reservations.push(options); return { id: String(reservations.length) } },
      settle: async (ticket, measured) => { settlements.push({ ticket, measured }); return true } }) })
  for (const request of [event('/health'), event('/speech', { text: 'こんにちは' }), event('/bad?path')]) {
    const response = await main(request)
    const measurement = settlements.at(-1).measured
    assert.ok(measurement.durationMs >= 0)
    assert.equal(measurement.outboundBytes, Buffer.byteLength(JSON.stringify(response)) + 64 * 1024)
  }
  assert.deepEqual(reservations.map(row => row.service), ['voice', 'voice', 'voice'])
  assert.equal(reservations[0].maxOutboundBytes, 64 * 1024 + 4096)
  assert.equal(reservations[1].maxOutboundBytes, Math.ceil(2 * 1024 * 1024 / 3) * 4 + 64 * 1024 + 4096)
  assert.equal(reservations[1].timeoutSeconds, 20)
})

await test('settlement errors do not retry synthesis or erase a successful reservation', async () => {
  let reserved = 0, settled = 0
  const main = adapter.createUniCloudHandler({ loadWorker: async () => worker, WebSocketClass: class {},
    loadQuota: () => ({ reserve: async () => { reserved++; return { id: 'kept-reservation' } },
      settle: async () => { settled++; throw new Error('store offline') } }) })
  assert.equal((await main(event('/health'))).statusCode, 200)
  assert.equal(reserved, 1)
  assert.equal(settled, 1)
})

await test('a hung reservation returns promptly and never starts upstream work after timing out', async t => {
  t.mock.timers.enable({ apis: ['setTimeout'] })
  t.after(() => t.mock.timers.reset())
  let release, loaded = false
  const reservation = new Promise(resolve => { release = resolve })
  const main = adapter.createUniCloudHandler({ speechEnabled: () => true,
    loadQuota: () => ({ reserve: () => reservation, settle: async () => true }),
    loadWorker: async () => { loaded = true; return worker } })
  const pending = main(event('/speech', { text: 'こんにちは' }))
  t.mock.timers.tick(2000)
  assert.equal((await pending).statusCode, 503)
  release({ id: 'late-hold' })
  await new Promise(resolve => setImmediate(resolve))
  assert.equal(loaded, false)
})

await test('the real shared quota module blocks another voice instance after the combined request limit', async () => {
  let document = null
  const clone = value => value == null ? null : structuredClone(value)
  const store = { load: async () => clone(document), create: async value => { document ??= clone(value) },
    compareAndSwap: async (revision, value) => {
      if (document.revision !== revision) return false
      document = clone(value); return true
    } }
  const makeBudget = () => quotaModule.createQuota({ store, limits: { ...quotaModule.LIMITS, requests: { day: 1, week: 1, month: 1 } } })
  const first = fixture(false, makeBudget), second = fixture(false, makeBudget)
  assert.equal((await first.main(event('/speech', { text: 'こんにちは' }))).statusCode, 200)
  assert.equal((await second.main(event('/speech', { text: 'こんにちは' }))).statusCode, 429)
  assert.equal(first.sockets.length, 1)
  assert.equal(second.sockets.length, 0)
  assert.equal(document.days[0].requests, 1)
  assert.equal(document.holds.length, 0)
  assert.ok(document.days[0].outboundBytes > 64 * 1024)
})
