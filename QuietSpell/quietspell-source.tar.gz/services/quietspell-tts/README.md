QuietSpell Japanese voice relay

Real-time Microsoft Nanami/Keita MP3 streams for the existing QuietSpell website.
GET /speech?voice=ja-JP-NanamiNeural&text=こんにちは
GET /health lists the two supported voices.

No audio or text is stored. Audio responses use Cache-Control: no-store.
Only the two Japanese voices are accepted. Browser origins are limited to the
QuietSpell website and local development. Upstream failures activate the
website's original audio fallback.

Build: node build.mjs
Runtime: Cloudflare-compatible Worker ESM (fetch and WebSocket upgrade support).
License: GPL-3.0-only. Protocol framing is adapted from @andresaya/edge-tts 1.9.1:
https://github.com/andresayac/edge-tts
