import { mkdir, copyFile, readFile, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const root = path.dirname(fileURLToPath(import.meta.url))
const destination = path.resolve(root, '../../.cache/releases/quietspell-tts-unicloud-20261122')
const functionRoot = path.join(destination, 'quietspell-japanese-voice')
await mkdir(functionRoot, { recursive: true })
const files = { 'unicloud/index.js': 'index.js', 'unicloud/package.json': 'package.json',
  'unicloud/README.md': 'README.md', 'worker/index.mjs': 'voice-worker.mjs', 'LICENSE': 'LICENSE',
  '../quietspell-unicloud/quota/index.js': 'quota/index.js' }
const hashes = {}
for (const [source, target] of Object.entries(files)) {
  await mkdir(path.dirname(path.join(functionRoot, target)), { recursive: true })
  await copyFile(path.join(root, source), path.join(functionRoot, target))
  hashes[target] = createHash('sha256').update(await readFile(path.join(functionRoot, target))).digest('hex')
}
const archive = path.join(destination, 'quietspell-japanese-voice.tar.gz')
const result = spawnSync('tar', ['-czf', archive, 'quietspell-japanese-voice'], { cwd: destination, stdio: 'inherit' })
if (result.error || result.status !== 0) throw result.error || new Error('Voice packaging failed.')
let zipArchive
if (process.platform === 'win32') {
  zipArchive = path.join(destination, 'quietspell-japanese-voice.zip')
  const zipped = spawnSync('tar', ['--format', 'zip', '-cf', zipArchive, ...Object.values(files)], { cwd: functionRoot, stdio: 'inherit' })
  if (zipped.error || zipped.status !== 0) throw zipped.error || new Error('Voice ZIP packaging failed.')
}
const manifest = { status: 'local-adapter-ready; not-deployed', functionName: 'quietspell-japanese-voice',
  runtime: 'Nodejs18', httpPrefix: '/voice-quietspell', containsUserCredentials: false,
  recordsAudio: false, speechEnabledByDefault: false, persistentSharedBudgetIntegrated: true,
  cloudBudgetConfigurationVerified: false, phoneVoicePlaybackVerified: false,
  memoryMB: 128, functionTimeoutSeconds: 20, absoluteRequestDeadlineSeconds: 15,
  files: hashes, archiveSha256: createHash('sha256').update(await readFile(archive)).digest('hex'),
  ...(zipArchive ? { zipSha256: createHash('sha256').update(await readFile(zipArchive)).digest('hex') } : {}) }
await writeFile(path.join(destination, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n')
console.log(JSON.stringify({ destination, archive, zipArchive, status: manifest.status }))
