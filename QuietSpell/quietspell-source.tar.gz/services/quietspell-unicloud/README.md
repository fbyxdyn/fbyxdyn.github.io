# QuietSpell on uniCloud Alipay

`health/` is a dependency-free connectivity probe. It never reads secrets,
personal data, or GitHub. Deploy it first as `quietspell-health`, Nodejs18,
128 MB, timeout 10 seconds, URL path `/health-quietspell`. The expected response
contains `ok: true`, `service: quietspell-health`, `provider: unicloud-alipay`.
Test both the direct URL and browser fetch from the blog on a phone without VPN.
Alipay default-domain rate limits and HTTP URL production restrictions apply.

Use non-overlapping HTTP path prefixes. In this deployment, binding `/quietspell`
to sync also intercepted `/quietspell-voice/health`. The separate probe uses
`/health-quietspell` and voice uses `/voice-quietspell`; neither starts with the
sync prefix. The first probe's historical `/quietspell-health` URL is not the
production sync health URL, which is `/quietspell/health`.

The owner must create the free Alipay service space, complete real-name/Alipay
authorization, and accept any account agreements personally. The free space
requires manual monthly renewal. Do not enable paid plans, overage billing, or
other paid products without the owner's explicit instruction.

The owner requires zero charges. `budget-policy.json` records aggregate limits;
`quota/index.js` implements persistent counters. The sync function is deployed and
its real cloud reservation path has passed; voice validation is still pending.
The provider documents delayed resource reporting and possible overage invoices
even after resource caps. A resource limit of 0% means unlimited. The owner has
been shown this limitation and guided to retain the free plan and set resource
caps to 50%. Do not claim that an application limiter guarantees zero fees.

`sync/` adapts the existing reviewed sync Worker to uniCloud HTTP events and
`callFunction` events. Package it with an exact copy of
`../quietspell-sync/worker/index.mjs` named `worker.mjs` alongside `index.js`.
Include `quota/index.js` as `quota.js` beside it. Never deploy `sync/` alone without
those two files. Nodejs18 is required. Upload the private budget collection schema
before invoking the deployed adapter. `QUIETSPELL_SYNC_ENABLED=true` is required
for upload/download; it defaults to disabled. A health call does not require the
GitHub secret but exercises the cloud quota store.
Server-side environment keys are `GITHUB_OWNER`, `GITHUB_REPO`, `GITHUB_TOKEN`,
`INVITE_CODE`, optionally `GITHUB_BRANCH`. No real value belongs in a source,
package archive, screenshot, client bundle, console log, or URL. Configure secrets
only after the live probe works and the platform's environment security and
permissions have been reviewed. Do not expose the data repository publicly.

The adapter uses a conservative 2 MiB event body limit, in addition to upstream
platform limits. This is lower than the original Worker's 8 MiB limit; large
article imports may exceed it. It forwards JSON through the provider's composed
HTTP response (`mpserverlessComposedResponse: true`), rather than serializing
status and headers into a plain response object.

HTTP paths below `/quietspell` are `/health`, `/sync/upload`, `/sync/download`.
SDK calls use `action: health|upload|download` and the existing request fields.
SDK results include numeric `status`. Both transports use the same invitation,
private-repository enforcement, snapshot format, and SHA conflict protection.
The invitation remains a shared key, not an individual login.

## Shared application budget

Sync and voice use one private `quietspell_service_budget/shared-v1` ledger.
Conditional revision updates prevent multiple instances from granting the same
remaining budget. The client schema denies all direct reads and writes. Use
Shanghai calendar days, a rolling 7-day window and a rolling 31-day window so a
calendar-month reset cannot double spending within a provider billing cycle.

Before work, reserve requests, configured memory times maximum runtime, and a
conservative outbound size. Settlement counts measured duration plus one second
and measured outgoing application bytes plus protocol allowances. Missing metrics,
process termination or uncertain accounting never force a refund. Actual usage
above a reservation is still recorded. Database errors stop new work; no fallback
to an in-memory counter exists. Expired holds lose their ticket, not their cost.

These are application estimates, not provider invoices. Initial probes, platform
preflights, denied invocations, database operations and startup/platform overhead
still consume free resources. Platform caps and remaining quota must be monitored.
No paid plan, Redis, additional database service, overage deposit or top-up is part
of this deployment.

No cloud deployment or live connectivity success is implied by local tests.
