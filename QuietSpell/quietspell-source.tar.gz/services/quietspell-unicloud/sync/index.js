'use strict'
// GPL-3.0-only. uniCloud HTTP events are adapted to the reviewed sync Worker.
const { webcrypto } = require('node:crypto')
const { AsyncLocalStorage } = require('node:async_hooks')
if (!globalThis.crypto) globalThis.crypto = webcrypto
const MAX_EVENT_BYTES = 2 * 1024 * 1024
const SAFE_ENV_KEYS = ['GITHUB_OWNER', 'GITHUB_REPO', 'GITHUB_TOKEN', 'INVITE_CODE', 'GITHUB_BRANCH']
const ORIGINS = new Set(['https://fbyxdyn.github.io', 'http://127.0.0.1:5567', 'http://localhost:5567'])
function failure(statusCode, code, origin) {
  return { mpserverlessComposedResponse: true, isBase64Encoded: false, statusCode,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', Vary: 'Origin',
      ...(ORIGINS.has(origin) ? { 'Access-Control-Allow-Origin': origin } : {}) },
    body: JSON.stringify({ ok: false, error: { code, message: '同步请求未完成。' } }) }
}
exports.createHandler = function ({ worker, environment = process.env, quota, now = Date.now } = {}) {
  let workerPromise
  let resolvedQuota = quota
  const accounting = new AsyncLocalStorage()
  const countedFetch = async (url, init) => {
    const current = accounting.getStore()
    if (current) current.outboundBytes += Buffer.byteLength(typeof init?.body === 'string' ? init.body : '') + Buffer.byteLength(String(url)) + 4096
    return fetch(url, init)
  }
  return async function (event = {}) {
    if (!event || typeof event !== 'object' || Array.isArray(event)) return { ok: false, status: 400, error: { code: 'INVALID_REQUEST' } }
    const started = now(), usage = { outboundBytes: 1024 }
    const origin = Object.entries(event.headers || {}).find(([key]) => key.toLowerCase() === 'origin')?.[1]
    let ticket
    try {
      const sdk = !event.httpMethod
      const method = sdk ? (event.action === 'health' ? 'GET' : 'POST') : String(event.httpMethod).toUpperCase()
      const path = sdk ? ({ health: '/health', upload: '/sync/upload', download: '/sync/download' }[event.action]) : (event.path === '/' ? '/health' : event.path)
      if (!['/health', '/sync/upload', '/sync/download'].includes(path)) return sdk ? { ok: false, status: 404, error: { code: 'NOT_FOUND' } } : failure(404, 'NOT_FOUND', origin)
      if (path !== '/health' && environment.QUIETSPELL_SYNC_ENABLED !== 'true') return sdk ? { ok: false, status: 503, error: { code: 'SYNC_DISABLED' } } : failure(503, 'SYNC_DISABLED', origin)
      const headers = new Headers()
      if (!sdk) for (const [key, value] of Object.entries(event.headers || {})) {
        if (typeof value === 'string' && !['host', 'content-length', 'transfer-encoding'].includes(key.toLowerCase())) headers.set(key, value)
      }
      let body
      if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) {
        const raw = sdk ? JSON.stringify({ userId: event.userId, inviteCode: event.inviteCode, snapshot: event.snapshot, sha: event.sha }) : event.body
        if (typeof raw !== 'string') return sdk ? { ok: false, status: 400, error: { code: 'INVALID_REQUEST' } } : failure(400, 'INVALID_REQUEST', origin)
        if (Buffer.byteLength(raw) > (event.isBase64Encoded && !sdk ? Math.ceil(MAX_EVENT_BYTES / 3) * 4 : MAX_EVENT_BYTES)) return sdk ? { ok: false, status: 413, error: { code: 'PAYLOAD_TOO_LARGE' } } : failure(413, 'PAYLOAD_TOO_LARGE', origin)
        body = !sdk && event.isBase64Encoded ? Buffer.from(raw, 'base64') : Buffer.from(raw)
        if (body.length > MAX_EVENT_BYTES) return sdk ? { ok: false, status: 413, error: { code: 'PAYLOAD_TOO_LARGE' } } : failure(413, 'PAYLOAD_TOO_LARGE', origin)
        if (sdk) headers.set('Content-Type', 'application/json')
      }
      if (!resolvedQuota) {
        try { resolvedQuota = require('./quota.js').createUniCloudQuota(typeof uniCloud !== 'undefined' ? uniCloud : globalThis.uniCloud) } catch {
          throw Object.assign(new Error('BUDGET_UNAVAILABLE'), { code: 'BUDGET_UNAVAILABLE', status: 503 })
        }
      }
      ticket = await resolvedQuota.reserve({ service: 'sync', memoryMB: 128, timeoutSeconds: 30, maxOutboundBytes: 4 * 1024 * 1024 })
      if (!workerPromise) workerPromise = worker ? Promise.resolve(worker) : import('./worker.mjs').then(module => module.createSyncWorker({ fetch: countedFetch }))
      const implementation = await workerPromise
      const bindings = Object.fromEntries(SAFE_ENV_KEYS.filter(key => typeof environment[key] === 'string').map(key => [key, environment[key]]))
      const response = await accounting.run(usage, () => implementation.fetch(new Request('https://quietspell.invalid' + path, { method, headers, body }), bindings))
      const text = await response.text()
      if (Buffer.byteLength(text) > MAX_EVENT_BYTES) return sdk ? { ok: false, status: 413, error: { code: 'PAYLOAD_TOO_LARGE' } } : failure(413, 'PAYLOAD_TOO_LARGE', origin)
      usage.outboundBytes += Buffer.byteLength(text)
      if (sdk) return { ...JSON.parse(text), status: response.status }
      return { mpserverlessComposedResponse: true, isBase64Encoded: false, statusCode: response.status,
        headers: Object.fromEntries(response.headers), body: text }
    } catch (error) {
      // Never return request data, runtime secrets, or upstream exception details.
      const budgetError = ['BUDGET_EXHAUSTED', 'BUDGET_BUSY', 'BUDGET_UNAVAILABLE'].includes(error?.code)
      const status = budgetError ? (error.status === 429 ? 429 : 503) : 500
      const code = budgetError ? error.code : 'INTERNAL_ERROR'
      return event.httpMethod ? failure(status, code, origin) : { ok: false, status, error: { code } }
    } finally {
      if (ticket) {
        try { await resolvedQuota.settle(ticket, { durationMs: Math.max(0, now() - started), outboundBytes: usage.outboundBytes }) } catch {
          // Keep the full reservation if accounting is unavailable; do not undo a completed upload.
        }
      }
    }
  }
}
exports.main = exports.createHandler()
