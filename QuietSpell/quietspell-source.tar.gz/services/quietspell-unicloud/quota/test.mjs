import assert from 'node:assert/strict'
import test from 'node:test'
import { createRequire } from 'node:module'
const { createQuota, createUniCloudStore, LIMITS } = createRequire(import.meta.url)('./index.js')
const clone = value => value == null ? value : JSON.parse(JSON.stringify(value))
const DAY = 86400000
const reservation = { service: 'sync', memoryMB: 128, timeoutSeconds: 10, maxOutboundBytes: 1000 }
function fixture(limits = LIMITS) {
  let value = null, time = Date.parse('2026-11-22T03:00:00Z'), serial = 0
  const store = {
    async load() { return clone(value) },
    async create(document) { if (value) return false; value = clone(document); return true },
    async compareAndSwap(revision, document) { if (!value || value.revision !== revision) return false; value = clone(document); return true },
  }
  const make = () => createQuota({ store, limits, now: () => time, id: () => 'ticket-' + ++serial })
  return { store, quota: make(), make, get: () => clone(value), advance: amount => { time += amount }, corrupt: input => { value = input } }
}
const withRequestLimits = (day, week, month) => ({ ...LIMITS, requests: { day, week, month } })
test('independent instances share a persistent budget and concurrent callers cannot oversubscribe', async () => {
  const f = fixture(withRequestLimits(1, 1, 1))
  const results = await Promise.allSettled([f.quota.reserve(reservation), f.make().reserve(reservation)])
  assert.equal(results.filter(item => item.status === 'fulfilled').length, 1)
  assert.equal(results.find(item => item.status === 'rejected').reason.code, 'BUDGET_EXHAUSTED')
  assert.equal(f.get().days[0].requests, 1)
})
test('settlement refunds only the reserved excess and cannot be repeated', async () => {
  const f = fixture(), ticket = await f.quota.reserve(reservation)
  assert.equal(await f.quota.settle(ticket, { durationMs: 500, outboundBytes: 100 }), true)
  assert.equal(f.get().days[0].gbSeconds, 0.1875)
  assert.equal(f.get().days[0].outboundBytes, 100)
  assert.equal(f.get().days[0].requests, 1)
  assert.equal(await f.make().settle(ticket, { durationMs: 0, outboundBytes: 0 }), false)
})
test('invalid measurements and abandoned holds keep the full reservation', async () => {
  const f = fixture(), ticket = await f.quota.reserve(reservation)
  assert.equal(await f.quota.settle(ticket, { durationMs: NaN, outboundBytes: 0 }), false)
  f.advance(6 * 60000)
  await f.quota.reserve(reservation)
  assert.equal(f.get().holds.length, 1)
  assert.equal(f.get().days[0].gbSeconds, 2.5)
  assert.equal(await f.quota.settle(ticket, { durationMs: 0, outboundBytes: 0 }), false)
})
test('new Shanghai day resets the daily budget but retains rolling weekly usage', async () => {
  const f = fixture(withRequestLimits(1, 2, 10))
  const first = await f.quota.reserve(reservation)
  await f.quota.settle(first, { durationMs: 0, outboundBytes: 0 })
  f.advance(DAY)
  const second = await f.quota.reserve(reservation)
  await f.quota.settle(second, { durationMs: 0, outboundBytes: 0 })
  f.advance(DAY)
  await assert.rejects(f.quota.reserve(reservation), { code: 'BUDGET_EXHAUSTED' })
  f.advance(5 * DAY)
  await f.quota.reserve(reservation)
})
test('rolling month survives a calendar-month boundary and frees only after 31 days', async () => {
  const f = fixture(withRequestLimits(10, 10, 1))
  const ticket = await f.quota.reserve(reservation)
  await f.quota.settle(ticket, { durationMs: 0, outboundBytes: 0 })
  f.advance(12 * DAY)
  await assert.rejects(f.quota.reserve(reservation), { code: 'BUDGET_EXHAUSTED' })
  f.advance(19 * DAY)
  await f.quota.reserve(reservation)
  assert.equal(f.get().days.length, 1)
})
test('either compute or outbound budget can stop a request before work starts', async () => {
  const compute = fixture({ ...LIMITS, gbSeconds: { day: 1, week: 1, month: 1 } })
  await assert.rejects(compute.quota.reserve(reservation), { code: 'BUDGET_EXHAUSTED' })
  const outbound = fixture({ ...LIMITS, outboundBytes: { day: 999, week: 999, month: 999 } })
  await assert.rejects(outbound.quota.reserve(reservation), { code: 'BUDGET_EXHAUSTED' })
})
test('actual usage above a reservation is charged instead of silently clamped away', async () => {
  const f = fixture(), ticket = await f.quota.reserve(reservation)
  await f.quota.settle(ticket, { durationMs: 20000, outboundBytes: 2000 })
  assert.equal(f.get().days[0].gbSeconds, 2.625)
  assert.equal(f.get().days[0].outboundBytes, 2000)
})
test('store outages, uncertain writes, and corrupted ledgers fail closed', async () => {
  const unavailable = createQuota({ store: { async load() { throw new Error('private database details') } } })
  await assert.rejects(unavailable.reserve(reservation), error => error.status === 503 && error.message === 'BUDGET_UNAVAILABLE')
  const f = fixture()
  f.store.compareAndSwap = async () => { throw new Error('connection lost after possible commit') }
  await assert.rejects(f.quota.reserve(reservation), { code: 'BUDGET_UNAVAILABLE' })
  const malformed = fixture()
  malformed.corrupt({ schemaVersion: 1, revision: 0, days: [{ day: 1, requests: -1 }], holds: [] })
  await assert.rejects(malformed.quota.reserve(reservation), { code: 'BUDGET_UNAVAILABLE' })
})
test('a wall-clock rollback never resets previously recorded usage', async () => {
  const f = fixture()
  await f.quota.reserve(reservation)
  f.advance(-DAY)
  await assert.rejects(f.quota.reserve(reservation), { code: 'BUDGET_UNAVAILABLE' })
})
test('uniCloud CAS updates filter by revision and never write the immutable ID', async () => {
  let expected
  const store = createUniCloudStore({ database: () => ({ collection(name) {
    assert.equal(name, 'quietspell_service_budget')
    return { where(filter) { expected = filter; return { async update(fields) {
      assert.equal('_id' in fields, false)
      assert.equal(fields.revision, 2)
      return { updated: 1 }
    } } } }
  } }) })
  assert.equal(await store.compareAndSwap(1, { _id: 'shared-v1', revision: 2 }), true)
  assert.deepEqual(expected, { _id: 'shared-v1', revision: 1 })
})
