'use strict'
// GPL-3.0-only. Shared persistent application budgets; not a zero-bill guarantee.
const { randomUUID } = require('node:crypto')
const DAY = 86400000
const COLLECTION = 'quietspell_service_budget'
const DOC_ID = 'shared-v1'
const MAX_HOLDS = 64
const HOLD_LIFETIME = 5 * 60000
const METRICS = ['requests', 'gbSeconds', 'outboundBytes']
const LIMITS = Object.freeze({
  requests: Object.freeze({ day: 200, week: 1000, month: 3000 }),
  gbSeconds: Object.freeze({ day: 20, week: 100, month: 400 }),
  outboundBytes: Object.freeze({ day: 10 * 1024 * 1024, week: 50 * 1024 * 1024, month: 250 * 1024 * 1024 }),
})
class QuotaError extends Error {
  constructor(code, status = 503) { super(code); this.code = code; this.status = status }
}
const validNumber = number => typeof number === 'number' && Number.isFinite(number) && number >= 0
const clone = value => JSON.parse(JSON.stringify(value))
const dayOf = time => Math.floor((time + 8 * 3600000) / DAY)
function validateDocument(value) {
  if (!value || value.schemaVersion !== 1 || !Number.isSafeInteger(value.revision) || value.revision < 0 ||
      !Array.isArray(value.days) || value.days.length > 32 || !Array.isArray(value.holds) || value.holds.length > MAX_HOLDS) throw new QuotaError('BUDGET_UNAVAILABLE')
  const seen = new Set()
  for (const row of value.days) {
    if (!Number.isSafeInteger(row.day) || seen.has(row.day) || METRICS.some(key => !validNumber(row[key]))) throw new QuotaError('BUDGET_UNAVAILABLE')
    seen.add(row.day)
  }
  const tickets = new Set()
  for (const hold of value.holds) {
    if (typeof hold.id !== 'string' || tickets.has(hold.id) || !Number.isSafeInteger(hold.day) ||
        !validNumber(hold.createdAt) || !validNumber(hold.gbSeconds) || !validNumber(hold.outboundBytes)) throw new QuotaError('BUDGET_UNAVAILABLE')
    tickets.add(hold.id)
  }
}
function freshDocument() { return { _id: DOC_ID, schemaVersion: 1, revision: 0, days: [], holds: [] } }
function totals(document, day, metric, window) {
  const length = { day: 1, week: 7, month: 31 }[window]
  return document.days.filter(row => row.day >= day - length + 1 && row.day <= day).reduce((sum, row) => sum + row[metric], 0)
}
exports.createQuota = function ({ store, now = Date.now, limits = LIMITS, id = randomUUID } = {}) {
  if (!store) throw new Error('A persistent quota store is required.')
  const guarded = async action => {
    try { return await action() } catch (error) {
      if (error instanceof QuotaError) throw error
      throw new QuotaError('BUDGET_UNAVAILABLE')
    }
  }
  const load = async () => {
    let document = await store.load()
    if (!document) {
      await store.create(freshDocument())
      document = await store.load()
    }
    validateDocument(document)
    return clone(document)
  }
  return {
    async reserve({ service, memoryMB, timeoutSeconds, maxOutboundBytes }) {
      return guarded(async () => {
        if (!['sync', 'voice', 'health'].includes(service) || !Number.isFinite(memoryMB) || memoryMB < 128 ||
            !Number.isFinite(timeoutSeconds) || timeoutSeconds <= 0 || !Number.isSafeInteger(maxOutboundBytes) || maxOutboundBytes < 0) throw new QuotaError('BUDGET_UNAVAILABLE')
        const timestamp = now(), day = dayOf(timestamp)
        const reservation = { requests: 1, gbSeconds: memoryMB / 1024 * timeoutSeconds, outboundBytes: maxOutboundBytes }
        const ticket = { id: id(), day, createdAt: timestamp, service, gbSeconds: reservation.gbSeconds, outboundBytes: maxOutboundBytes, memoryMB, timeoutSeconds }
        for (let attempt = 0; attempt < 12; attempt++) {
          const document = await load(), previousRevision = document.revision
          if (document.days.some(row => row.day > day)) throw new QuotaError('BUDGET_UNAVAILABLE')
          document.days = document.days.filter(row => row.day >= day - 30)
          // Expired holds are removed without refunding their reservations.
          document.holds = document.holds.filter(hold => hold.createdAt > timestamp - HOLD_LIFETIME)
          if (document.holds.length >= MAX_HOLDS) throw new QuotaError('BUDGET_BUSY', 429)
          for (const metric of METRICS) for (const window of ['day', 'week', 'month']) {
            if (totals(document, day, metric, window) + reservation[metric] > limits[metric][window] + 1e-9) throw new QuotaError('BUDGET_EXHAUSTED', 429)
          }
          let row = document.days.find(item => item.day === day)
          if (!row) { row = { day, requests: 0, gbSeconds: 0, outboundBytes: 0 }; document.days.push(row) }
          for (const metric of METRICS) row[metric] += reservation[metric]
          document.holds.push(ticket)
          document.revision++
          if (await store.compareAndSwap(previousRevision, document)) return ticket
        }
        throw new QuotaError('BUDGET_BUSY', 429)
      })
    },
    async settle(ticket, { durationMs, outboundBytes } = {}) {
      return guarded(async () => {
        // Missing/invalid measurements keep the full reservation.
        if (!ticket || typeof ticket.id !== 'string' || !validNumber(durationMs) || !validNumber(outboundBytes)) return false
        for (let attempt = 0; attempt < 12; attempt++) {
          const document = await load(), previousRevision = document.revision
          const hold = document.holds.find(item => item.id === ticket.id)
          if (!hold) return false
          const row = document.days.find(item => item.day === hold.day)
          if (!row || !validNumber(hold.memoryMB) || !validNumber(hold.timeoutSeconds)) throw new QuotaError('BUDGET_UNAVAILABLE')
          // Count a full extra second for adapter/serialization/runtime overhead.
          const actualGBSeconds = hold.memoryMB / 1024 * (durationMs / 1000 + 1)
          row.gbSeconds = Math.max(0, row.gbSeconds - hold.gbSeconds + actualGBSeconds)
          row.outboundBytes = Math.max(0, row.outboundBytes - hold.outboundBytes + Math.ceil(outboundBytes))
          document.holds = document.holds.filter(item => item.id !== hold.id)
          document.revision++
          if (await store.compareAndSwap(previousRevision, document)) return true
        }
        throw new QuotaError('BUDGET_BUSY', 429)
      })
    },
  }
}
exports.createUniCloudStore = function (cloud) {
  const collection = cloud.database().collection(COLLECTION)
  return {
    async load() { return (await collection.doc(DOC_ID).get()).data?.[0] || null },
    async create(document) {
      try { await collection.add(document); return true } catch (error) {
        if ((await collection.doc(DOC_ID).get()).data?.length) return false
        throw error
      }
    },
    async compareAndSwap(revision, document) {
      const { _id, ...fields } = document
      return (await collection.where({ _id: DOC_ID, revision }).update(fields)).updated === 1
    },
  }
}
exports.createUniCloudQuota = cloud => exports.createQuota({ store: exports.createUniCloudStore(cloud) })
exports.QuotaError = QuotaError
exports.LIMITS = LIMITS
