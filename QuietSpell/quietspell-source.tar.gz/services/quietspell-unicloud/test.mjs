import assert from 'node:assert/strict'
import test from 'node:test'
import { createRequire } from 'node:module'
import { createHash } from 'node:crypto'
import { createSyncWorker } from '../quietspell-sync/worker/index.mjs'
const require = createRequire(import.meta.url)
const health = require('./health/index.js').main
const { createHandler: makeHandler } = require('./sync/index.js')
const createHandler = options => makeHandler({ quota: { async reserve() { return {} }, async settle() {} }, ...options })
const origin = 'https://fbyxdyn.github.io'
const env = { QUIETSPELL_SYNC_ENABLED: 'true', GITHUB_OWNER: 'example', GITHUB_REPO: 'private-data', GITHUB_TOKEN: 'synthetic-token', INVITE_CODE: 'synthetic-invite' }
const http = (path, value, base64 = false) => ({ path, httpMethod: value ? 'POST' : 'GET',
  headers: { origin, 'content-type': 'application/json' },
  body: value ? (base64 ? Buffer.from(JSON.stringify(value)).toString('base64') : JSON.stringify(value)) : '', isBase64Encoded: base64 })
const parse = response => JSON.parse(response.body)
function storage() {
  const files = new Map(), blobs = new Map(), calls = []
  const json = (value, status = 200) => new Response(JSON.stringify(value), { status })
  const worker = createSyncWorker({ fetch: async (url, init) => {
    calls.push(url)
    assert.equal(init.headers.Authorization, 'Bearer synthetic-token')
    const path = new URL(url).pathname.replace('/repos/example/private-data', '')
    if (!path) return json({ private: true, default_branch: 'main' })
    if (path.startsWith('/git/blobs/')) return new Response(blobs.get(path.split('/').at(-1)))
    const previous = files.get(path)
    if (init.method !== 'PUT') return previous ? json({ type: 'file', sha: previous.sha, size: previous.text.length }) : json({}, 404)
    const input = JSON.parse(init.body)
    if (previous && input.sha !== previous.sha) return json({}, 409)
    const text = Buffer.from(input.content, 'base64').toString('utf8')
    const sha = createHash('sha1').update(text).digest('hex')
    files.set(path, { sha, text }); blobs.set(sha, text)
    return json({ content: { sha } }, previous ? 200 : 201)
  } })
  return { handler: createHandler({ worker, environment: env }), calls, files }
}
test('health supports SDK calls and actual Alipay composed HTTP responses', async () => {
  const sdk = await health({})
  assert.equal(sdk.provider, 'unicloud-alipay')
  const response = await health({ httpMethod: 'GET', headers: { Origin: origin } })
  assert.equal(response.mpserverlessComposedResponse, true)
  assert.equal(response.statusCode, 200)
  assert.equal(response.headers['Access-Control-Allow-Origin'], origin)
  assert.deepEqual(parse(response), sdk)
})
test('health permits blog preflight, rejects unrelated origins, and has no write method', async () => {
  assert.equal((await health({ httpMethod: 'OPTIONS', headers: { origin } })).statusCode, 204)
  assert.equal((await health({ httpMethod: 'GET', headers: { origin: 'https://unrelated.invalid' } })).statusCode, 403)
  assert.equal((await health({ httpMethod: 'POST' })).statusCode, 405)
  assert.equal((await health({ httpMethod: 'HEAD' })).body, '')
})
test('adapter fails closed without configured server secrets', async () => {
  const handler = createHandler({ worker: createSyncWorker(), environment: { QUIETSPELL_SYNC_ENABLED: 'true' } })
  const response = await handler(http('/sync/download', { userId: 'demo', inviteCode: 'guess' }))
  assert.equal(response.statusCode, 503)
  assert.equal(parse(response).error.code, 'NOT_CONFIGURED')
})
test('SDK upload and base64 HTTP download round-trip Unicode IDs through the same Worker', async () => {
  const f = storage(), userId = ' 用户/🌸 ', snapshot = { version: 1, progress: {}, wordbooks: [], customText: 'test only' }
  const saved = await f.handler({ action: 'upload', userId, inviteCode: env.INVITE_CODE, sha: null, snapshot })
  assert.equal(saved.status, 200)
  const loaded = await f.handler(http('/sync/download', { userId, inviteCode: env.INVITE_CODE }, true))
  assert.equal(loaded.statusCode, 200)
  assert.equal(loaded.mpserverlessComposedResponse, true)
  assert.equal(loaded.isBase64Encoded, false)
  assert.equal(loaded.headers['access-control-allow-origin'], origin)
  assert.deepEqual(parse(loaded).snapshot, snapshot)
  assert.equal(parse(loaded).sha, saved.sha)
  assert.equal(parse(loaded).userId, userId)
  assert.doesNotMatch([...f.files.values()][0].text, /synthetic-token|synthetic-invite/)
})
test('wrong invitation rejects SDK and HTTP callers before any GitHub access', async () => {
  const f = storage()
  const sdk = await f.handler({ action: 'download', userId: 'demo', inviteCode: 'wrong' })
  const url = await f.handler(http('/sync/download', { userId: 'demo', inviteCode: 'wrong' }))
  assert.equal(sdk.status, 403)
  assert.equal(url.statusCode, 403)
  assert.equal(sdk.error.code, 'INVITE_INVALID')
  assert.equal(f.calls.length, 0)
})
test('stale revisions remain conflicts across SDK and HTTP transports', async () => {
  const f = storage(), input = { userId: 'demo', inviteCode: env.INVITE_CODE, sha: null, snapshot: { version: 1 } }
  assert.equal((await f.handler({ action: 'upload', ...input })).status, 200)
  assert.equal((await f.handler(http('/sync/upload', input))).statusCode, 409)
})
test('oversized raw and base64 events are rejected before Worker execution', async () => {
  let calls = 0
  const handler = createHandler({ worker: { fetch() { calls++; throw new Error('must not run') } }, environment: env })
  const body = 'x'.repeat(2 * 1024 * 1024 + 1)
  for (const isBase64Encoded of [false, true]) {
    const response = await handler({ httpMethod: 'POST', path: '/sync/upload', body: isBase64Encoded ? Buffer.from(body).toString('base64') : body, isBase64Encoded })
    assert.equal(response.statusCode, 413)
  }
  assert.equal(calls, 0)
})
test('unknown paths and actions cannot choose upstream destinations', async () => {
  const handler = createHandler({ worker: { fetch() { throw new Error('must not run') } } })
  assert.equal((await handler({ httpMethod: 'GET', path: '//unrelated.invalid' })).statusCode, 404)
  assert.equal((await handler({ action: 'https://unrelated.invalid' })).status, 404)
  assert.equal((await handler(null)).status, 400)
})
test('upstream exception details and extra environment keys never reach responses', async () => {
  const handler = createHandler({ worker: { fetch(request, bindings) {
    assert.equal(bindings.UNRELATED_SECRET, undefined)
    throw new Error('private upstream synthetic-secret')
  } }, environment: { ...env, UNRELATED_SECRET: 'synthetic-secret' } })
  const response = await handler(http('/health'))
  assert.equal(response.statusCode, 500)
  assert.doesNotMatch(response.body, /synthetic-secret|private upstream/)
})
test('sync is disabled until the owner explicitly enables its runtime setting', async () => {
  let called = false
  const handler = createHandler({ environment: {}, worker: { fetch() { called = true } } })
  const response = await handler(http('/sync/download', { userId: 'demo', inviteCode: 'unused' }))
  assert.equal(response.statusCode, 503)
  assert.equal(parse(response).error.code, 'SYNC_DISABLED')
  assert.equal(called, false)
})
test('budget rejection stops sync work and preserves usable CORS error headers', async () => {
  let called = false
  const handler = makeHandler({ environment: env, quota: { async reserve() { throw Object.assign(new Error('private details'), { code: 'BUDGET_EXHAUSTED', status: 429 }) } }, worker: { fetch() { called = true } } })
  const response = await handler(http('/sync/download', { userId: 'demo', inviteCode: 'unused' }))
  assert.equal(response.statusCode, 429)
  assert.equal(response.headers['Access-Control-Allow-Origin'], origin)
  assert.equal(parse(response).error.code, 'BUDGET_EXHAUSTED')
  assert.equal(called, false)
})
test('a completed operation remains successful if settlement fails conservatively', async () => {
  let settles = 0
  const handler = makeHandler({ environment: env, quota: { async reserve() { return { id: 'reserved' } }, async settle() { settles++; throw new Error('store down') } },
    worker: { async fetch() { return new Response(JSON.stringify({ ok: true })) } } })
  const response = await handler(http('/health'))
  assert.equal(response.statusCode, 200)
  assert.equal(settles, 1)
})
