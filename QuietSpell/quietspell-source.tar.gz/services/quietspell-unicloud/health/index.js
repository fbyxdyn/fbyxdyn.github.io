'use strict'
// GPL-3.0-only. Connectivity probe only: no credentials, storage, or upstream calls.
const allowedOrigins = new Set(['https://fbyxdyn.github.io', 'http://127.0.0.1:5567', 'http://localhost:5567'])
exports.main = async function (event = {}) {
  const payload = { ok: true, service: 'quietspell-health', provider: 'unicloud-alipay' }
  if (!event.httpMethod) return payload
  const method = String(event.httpMethod).toUpperCase()
  const origin = Object.entries(event.headers || {}).find(([key]) => key.toLowerCase() === 'origin')?.[1]
  const headers = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', Vary: 'Origin' }
  if (allowedOrigins.has(origin)) headers['Access-Control-Allow-Origin'] = origin
  let statusCode = 200
  let body = payload
  if (origin && !allowedOrigins.has(origin)) {
    statusCode = 403
    body = { ok: false, error: { code: 'ORIGIN_NOT_ALLOWED' } }
  } else if (method === 'OPTIONS') {
    statusCode = 204
    headers['Access-Control-Allow-Methods'] = 'GET, HEAD, OPTIONS'
    headers['Access-Control-Allow-Headers'] = 'Content-Type'
  } else if (!['GET', 'HEAD'].includes(method)) {
    statusCode = 405
    headers.Allow = 'GET, HEAD, OPTIONS'
    body = { ok: false, error: { code: 'METHOD_NOT_ALLOWED' } }
  }
  return { mpserverlessComposedResponse: true, isBase64Encoded: false, statusCode, headers,
    body: method === 'HEAD' || statusCode === 204 ? '' : JSON.stringify(body) }
}
