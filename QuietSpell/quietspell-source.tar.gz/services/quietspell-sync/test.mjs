import assert from 'node:assert/strict'
import test from 'node:test'
import { createHash } from 'node:crypto'
import { createSyncWorker, userLocation, MAX_BODY_BYTES } from './worker/index.mjs'

// Synthetic test credentials only. No local GitHub authentication is accessed.
const env = { INVITE_CODE: 'unit-test-invite', GITHUB_TOKEN: 'unit-test-token', GITHUB_OWNER: 'example', GITHUB_REPO: 'private-progress' }
const origin = 'https://fbyxdyn.github.io'
const snapshot = { version: 1, preferencesVersion: 2, progress: { lesson: { correct: 3 } }, wordbooks: [], customText: '', settings: {}, voice: 'original', session: null, lessonId: 'hiragana', inputMode: 'japanese', practiceMode: 'system', finished: false }
const json = (value, status = 200) => new Response(JSON.stringify(value), { status, headers: { 'Content-Type': 'application/json' } })

function fixture() {
  const files = new Map(), blobs = new Map(), calls = []
  const options = { private: true, fail: 0, race: false, raceCreate: false, invalidPut: false }
  let time = Date.parse('2026-11-21T11:00:00Z')
  const worker = createSyncWorker({ now: () => time, fetch: async (url, init) => {
    calls.push({ url, init })
    assert.equal(new URL(url).origin, 'https://api.github.com')
    assert.equal(init.headers.Authorization, 'Bearer unit-test-token')
    assert.equal(init.redirect, 'error')
    if (options.fail) return json({ message: 'private upstream error and unit-test-token' }, options.fail)
    const suffix = new URL(url).pathname.replace('/repos/example/private-progress', '')
    if (!suffix) return json({ private: options.private, default_branch: 'main' })
    if (suffix.startsWith('/git/blobs/')) {
      assert.equal(init.headers.Accept, 'application/vnd.github.raw+json')
      const text = blobs.get(suffix.split('/').at(-1))
      return text === undefined ? json({}, 404) : new Response(text)
    }
    assert.ok(suffix.startsWith('/contents/'))
    const path = suffix.slice('/contents/'.length).split('/').map(decodeURIComponent).join('/')
    if (init.method !== 'PUT') {
      const file = files.get(path)
      return file ? json({ type: 'file', sha: file.sha, size: Buffer.byteLength(file.text), encoding: 'none' }) : json({}, 404)
    }
    const data = JSON.parse(init.body), old = files.get(path)
    assert.equal(data.branch, 'main')
    if (options.race) return json({}, 409)
    if (options.raceCreate) {
      const sha = 'c'.repeat(40), text = '{}'
      files.set(path, { sha, text }); blobs.set(sha, text)
      return json({}, 422)
    }
    if (options.invalidPut) return json({}, 422)
    if (old && data.sha !== old.sha) return json({}, 409)
    const text = Buffer.from(data.content, 'base64').toString('utf8')
    const sha = createHash('sha1').update(text).digest('hex')
    files.set(path, { sha, text }); blobs.set(sha, text)
    return json({ content: { sha } }, old ? 200 : 201)
  } })
  async function call(path, body, config = env, headers = {}) {
    const request = new Request('https://sync.example' + path, { method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body) })
    const response = await worker.fetch(request, config)
    return { response, data: await response.json() }
  }
  return { worker, call, files, blobs, calls, options, advance: () => time += 60001 }
}
const download = (userId = 'demo') => ({ userId, inviteCode: env.INVITE_CODE })
const upload = (userId = 'demo', sha = null, value = snapshot) => ({ ...download(userId), sha, snapshot: value })

test('safe IDs name folders directly; hostile IDs are encoded without traversal or collisions', async () => {
  assert.equal((await userLocation('Feng_01-abc')).displayFolder, 'Feng_01-abc')
  assert.equal((await userLocation('user/a')).displayFolder, 'user%2Fa')
  assert.equal((await userLocation('user%2Fa')).displayFolder, 'user%252Fa')
  assert.equal((await userLocation('..')).displayFolder, '%2E%2E')
  assert.equal((await userLocation('.!\'()*~')).displayFolder, '%2E%21%27%28%29%2A%7E')
  const ids = ['../a', 'a/b', 'a\\b', 'a%2Fb', '用户🌸', 'é', 'e\u0301', ' x ', 'x', '\0']
  assert.equal(new Set(await Promise.all(ids.map(async id => (await userLocation(id)).filePath))).size, ids.length)
  await assert.rejects(userLocation(''))
  await assert.rejects(userLocation('\ud800'))
})

test('long IDs use a reserved full SHA-256 fallback and cannot collide with a literal hash ID', async () => {
  const long = await userLocation('日'.repeat(80))
  assert.equal(long.folderEncoding, 'sha256')
  assert.match(long.displayFolder, /^sha256-[a-f0-9]{64}$/)
  assert.notEqual((await userLocation(long.displayFolder)).displayFolder, long.displayFolder)
})

test('IDs exceeding 4096 characters upload and download without trimming or truncation', async () => {
  const f = fixture(), id = ' 用户🌸/'.repeat(1200) + ' '
  assert.ok(Array.from(id).length > 4096)
  const saved = await f.call('/sync/upload', upload(id))
  assert.equal(saved.response.status, 200)
  assert.equal(saved.data.userId, id)
  assert.equal(saved.data.folderEncoding, 'sha256')
  const downloaded = await f.call('/sync/download', download(id))
  assert.equal(downloaded.response.status, 200)
  assert.equal(downloaded.data.userId, id)
  assert.deepEqual(downloaded.data.snapshot, snapshot)
  assert.equal(JSON.parse([...f.files.values()][0].text).userId, id)
})

test('unconfigured service fails closed without a GitHub request', async () => {
  const f = fixture()
  for (const missing of Object.keys(env)) {
    const config = { ...env }; delete config[missing]
    const result = await f.call('/sync/upload', upload(), config)
    assert.equal(result.response.status, 503)
    assert.equal(result.data.error.code, 'NOT_CONFIGURED')
  }
  assert.equal(f.calls.length, 0)
})

test('invalid invitation is 403 and neither contacts GitHub nor reflects secrets', async () => {
  const f = fixture()
  const result = await f.call('/sync/download', { ...download(), inviteCode: 'wrong-secret-input' })
  assert.equal(result.response.status, 403)
  assert.equal(result.data.error.code, 'INVITE_INVALID')
  assert.equal(f.calls.length, 0)
  assert.doesNotMatch(JSON.stringify(result.data), /wrong-secret-input|unit-test-token|unit-test-invite/)
})

test('missing data is 404, while a public repository is never read or written', async () => {
  const f = fixture()
  assert.equal((await f.call('/sync/download', download())).data.error.code, 'NO_DATA')
  f.options.private = false
  const before = f.calls.length
  assert.equal((await f.call('/sync/upload', upload())).response.status, 503)
  assert.equal(f.calls.length, before + 1)
  assert.equal(f.files.size, 0)
})

test('Unicode ID and Japanese data roundtrip; invitation and token never enter the stored file', async () => {
  const f = fixture(), id = ' 风 /🌸 '
  const value = { ...snapshot, customText: '今日は日本語を勉強します。' }
  const saved = await f.call('/sync/upload', upload(id, null, value))
  assert.equal(saved.response.status, 200)
  assert.equal(saved.data.userId, id)
  const stored = [...f.files.values()][0].text
  assert.equal(JSON.parse(stored).userId, id)
  assert.doesNotMatch(stored, /unit-test-token|unit-test-invite|inviteCode|GITHUB_TOKEN/)
  const loaded = await f.call('/sync/download', download(id))
  assert.deepEqual(loaded.data.snapshot, value)
  assert.equal(loaded.data.sha, saved.data.sha)
  assert.equal(loaded.data.displayFolder, saved.data.displayFolder)
  assert.equal(loaded.response.headers.get('Cache-Control'), 'no-store')
  assert.ok(f.calls.some(call => call.url.includes('%252F')))
  assert.ok(f.calls.some(call => call.url.endsWith('/git/blobs/' + saved.data.sha)))
})

test('optimistic locking prevents blind overwrite and stale SHA, but accepts current SHA', async () => {
  const f = fixture()
  const first = await f.call('/sync/upload', upload())
  for (const sha of [null, 'b'.repeat(40)]) {
    const result = await f.call('/sync/upload', upload('demo', sha))
    assert.equal(result.response.status, 409)
    assert.equal(result.data.error.code, 'CONFLICT')
  }
  const next = await f.call('/sync/upload', upload('demo', first.data.sha, { ...snapshot, finished: true }))
  assert.equal(next.response.status, 200)
  assert.notEqual(next.data.sha, first.data.sha)
  assert.equal((await f.call('/sync/upload', upload('absent', first.data.sha))).response.status, 409)
})

test('GitHub conflict during PUT is 409 and never retried as a blind overwrite', async () => {
  const f = fixture(); f.options.race = true
  assert.equal((await f.call('/sync/upload', upload())).response.status, 409)
  assert.equal(f.calls.filter(call => call.init.method === 'PUT').length, 1)
})

test('racing creation returning 422 is a conflict; unrelated validation failures are unavailable', async () => {
  const race = fixture(); race.options.raceCreate = true
  assert.equal((await race.call('/sync/upload', upload())).response.status, 409)
  const invalid = fixture(); invalid.options.invalidPut = true
  assert.equal((await invalid.call('/sync/upload', upload())).response.status, 503)
})

test('snapshots larger than 1 MiB roundtrip using raw blob reads', async () => {
  const f = fixture(), value = { ...snapshot, customText: 'a'.repeat(1200000) }
  assert.equal((await f.call('/sync/upload', upload('large', null, value))).response.status, 200)
  const result = await f.call('/sync/download', download('large'))
  assert.equal(result.response.status, 200)
  assert.deepEqual(result.data.snapshot, value)
})

test('streamed oversized JSON is rejected before parsing, authenticating or calling GitHub', async () => {
  const f = fixture()
  const stream = new ReadableStream({ start(controller) {
    controller.enqueue(new Uint8Array(MAX_BODY_BYTES)); controller.enqueue(new Uint8Array(1)); controller.close()
  } })
  const response = await f.worker.fetch(new Request('https://sync.example/sync/upload', { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: origin }, body: stream, duplex: 'half' }), env)
  assert.equal(response.status, 413)
  assert.equal(f.calls.length, 0)
})

test('malformed request shapes and absent SHA cannot cause writes', async () => {
  const f = fixture()
  for (const body of [null, [], upload('', null), upload('id', null, []), { ...download(), snapshot }, upload('id', 'bad-sha')]) {
    assert.equal((await f.call('/sync/upload', body)).response.status, 400)
  }
  assert.equal((await f.call('/sync/upload', upload(), env, { 'Content-Type': 'text/plain' })).response.status, 415)
  assert.equal(f.calls.length, 0)
})

test('invalid UTF-8 or malformed JSON returns 400 without reaching GitHub', async () => {
  const f = fixture()
  for (const body of ['{bad json', new Uint8Array([0xff, 0xfe])]) {
    const response = await f.worker.fetch(new Request('https://sync.example/sync/upload', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body }), env)
    assert.equal(response.status, 400)
  }
  assert.equal(f.calls.length, 0)
})

test('CORS only permits the learning site and known local development origins', async () => {
  const f = fixture()
  for (const allowed of [origin, 'http://127.0.0.1:5567', 'http://localhost:5567']) {
    const response = await f.worker.fetch(new Request('https://sync.example/sync/upload', { method: 'OPTIONS', headers: { Origin: allowed } }))
    assert.equal(response.status, 204)
    assert.equal(response.headers.get('Access-Control-Allow-Origin'), allowed)
    assert.equal(response.headers.get('Access-Control-Allow-Credentials'), null)
  }
  const result = await f.call('/sync/upload', upload(), env, { Origin: 'https://untrusted.example' })
  assert.equal(result.response.status, 403)
  assert.equal(result.response.headers.get('Access-Control-Allow-Origin'), null)
  assert.equal(f.calls.length, 0)
})

test('upstream errors do not expose GitHub errors, paths or credentials', async () => {
  const f = fixture(); f.options.fail = 403
  const result = await f.call('/sync/download', download())
  assert.equal(result.response.status, 503)
  assert.doesNotMatch(JSON.stringify(result.data), /private upstream|private-progress|unit-test-token|unit-test-invite/)
  assert.equal(result.response.headers.get('Retry-After'), '30')
})

test('download rejects an unexpected envelope or mismatched original ID', async () => {
  const f = fixture()
  const saved = await f.call('/sync/upload', upload())
  const stored = JSON.parse(f.blobs.get(saved.data.sha)); stored.userId = 'another-user'
  f.blobs.set(saved.data.sha, JSON.stringify(stored))
  assert.equal((await f.call('/sync/download', download())).response.status, 503)
})

test('rate limit covers failed invitations and resets after one minute', async () => {
  const f = fixture()
  for (let i = 0; i < 30; i++) assert.equal((await f.call('/sync/download', { ...download(), inviteCode: 'bad' })).response.status, 403)
  assert.equal((await f.call('/sync/download', download())).response.status, 429)
  f.advance()
  assert.equal((await f.call('/sync/download', download())).response.status, 404)
})

test('no GET mutation or invitation in query URLs; health has no secret configuration', async () => {
  const f = fixture()
  const get = await f.worker.fetch(new Request('https://sync.example/sync/upload'), env)
  assert.equal(get.status, 405)
  assert.equal((await f.call('/sync/download?inviteCode=not-accepted', download())).response.status, 400)
  const health = await f.worker.fetch(new Request('https://sync.example/health'), env)
  assert.deepEqual(await health.json(), { ok: true, service: 'quietspell-sync' })
  assert.equal(f.calls.length, 0)
})
