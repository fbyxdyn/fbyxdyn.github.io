# Local handoff and remaining deployment steps

The source and built Worker are prepared. This service is registered independently;
its real project ID is in `.openai/hosting.json`. It starts owner-private. Runtime
configuration and deployment require separate verification. The existing TTS
service must not be repurposed or modified for progress sync.

## What is ready

* Standalone Cloudflare-compatible Worker ESM in `dist/server/index.js`.
* Tests for upload/download, Unicode and very long IDs, 8 MiB streamed limits,
  invitation failures, private-repository enforcement and SHA conflicts.
* Dependency-free `build.mjs`, endpoint contract and secret variable names.
* `prepare-release.mjs` produces an allowlisted source/build archive and SHA-256
  manifest. It excludes local environment files, credentials, logs and Git data.

The local handoff archive is **not the official Sites deployment artifact**. Use
the source workflow helper for that artifact. Reuse the registered identity;
do not register another Site or deploy to the voice service's project.

## Owner configuration needed

1. Provide the dedicated **private data repository URL**. Verify it is separate
   from the public blog and confirm the intended branch (default branch is fine).
2. In a secure configuration interface, create/configure a fine-grained GitHub
   token selected for only that repository, with Contents read/write and Metadata
   read. **Do not paste a token into chat.** Do not reuse local Git/SSH credentials
   or a token that can access unrelated repositories.
3. Configure these server-side runtime bindings using the hosting secret manager:
   `GITHUB_OWNER`, `GITHUB_REPO`, `GITHUB_TOKEN`, `INVITE_CODE`, and optional
   `GITHUB_BRANCH`. Only the names are in `.env.example`; no real secrets have
   been included in this release. The invitation was supplied in the frontend
   owner's chat and must be entered directly into secret configuration, not source.

## Later Sites publication workflow

Use the Sites skill/native tools in the publishing chat and retain the existing
service project ID. That ID was persisted with the official Sites
`set-project-id.mjs` helper, omitting `--static-directory` because this is a Worker.
The tracked
`.openai/hosting.json` must contain the actual project ID and no `static` field.

Configure runtime secrets through native Sites tools. Use the source workflow
helper with the returned project-scoped source credential over hidden stdin,
then run `node --test test.mjs` and `node build.mjs` and package using that helper.
Build copies a real registered hosting manifest into the output when present.
Publish the archive associated with that exact source commit. New Sites start
private; any later audience change needs the appropriate native access approval.
The public learning frontend must eventually be able to POST to the service.

Finally, configure the frontend's service URL and verify a test upload/download
on two browsers with synthetic data. Check incorrect invitation 403, stale SHA
409, and that original local progress remains intact on canceled or failed
download. Do not publish personal progress as test data.

## Access model and data retention

The invitation is a shared key, not an account login. Anyone holding it and knowing
an ID can access that ID's snapshot. The private GitHub repository contains the
snapshots and previous versions in Git history. This implementation does not
provide per-person access isolation, account recovery, or data erasure.
