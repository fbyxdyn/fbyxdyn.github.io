// GPL-3.0-only. Runtime secrets are supplied through Worker environment bindings.
export const MAX_BODY_BYTES = 8 * 1024 * 1024
const ORIGINS = new Set(['https://fbyxdyn.github.io', 'http://127.0.0.1:5567', 'http://localhost:5567'])
const encoder = new TextEncoder()
const decoder = new TextDecoder('utf-8', { fatal: true })
const SHA = /^(?:[a-f0-9]{40}|[a-f0-9]{64})$/

class SyncError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code }
}
const unavailable = () => new SyncError(503, 'UPSTREAM_UNAVAILABLE', '同步存储暂不可用，请稍后重试。')
const conflict = () => new SyncError(409, 'CONFLICT', '云端数据已变化，请先下载最新数据，再决定是否上传。')
const invalid = () => new SyncError(400, 'INVALID_REQUEST', '同步请求格式不正确。')
function object(value) { return value !== null && typeof value === 'object' && !Array.isArray(value) }

function config(env) {
  const { INVITE_CODE, GITHUB_TOKEN, GITHUB_OWNER, GITHUB_REPO, GITHUB_BRANCH } = env
  if (typeof INVITE_CODE !== 'string' || !INVITE_CODE || typeof GITHUB_TOKEN !== 'string' || !GITHUB_TOKEN ||
      typeof GITHUB_OWNER !== 'string' || !/^[a-zA-Z0-9-]{1,100}$/.test(GITHUB_OWNER) ||
      typeof GITHUB_REPO !== 'string' || !/^[a-zA-Z0-9_.-]{1,100}$/.test(GITHUB_REPO) ||
      ['.', '..'].includes(GITHUB_REPO) ||
      (GITHUB_BRANCH !== undefined && (typeof GITHUB_BRANCH !== 'string' || !GITHUB_BRANCH || GITHUB_BRANCH.length > 200))) {
    throw new SyncError(503, 'NOT_CONFIGURED', '同步服务尚未配置完成。')
  }
  return { invite: INVITE_CODE, token: GITHUB_TOKEN, owner: GITHUB_OWNER, repo: GITHUB_REPO, branch: GITHUB_BRANCH }
}

async function digest(value) { return new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(value))) }
async function validInvite(actual, expected) {
  if (typeof actual !== 'string' || actual.length > 1024) return false
  const [a, b] = await Promise.all([digest(actual), digest(expected)])
  let difference = 0
  for (let i = 0; i < a.length; i++) difference |= a[i] ^ b[i]
  return difference === 0
}

export async function userLocation(userId) {
  // No normalization: visually similar but distinct IDs remain distinct.
  if (typeof userId !== 'string' || !userId.length || /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(userId)) throw invalid()
  let folder = encodeURIComponent(userId).replace(/[.!'()*~]/g, char => '%' + char.charCodeAt(0).toString(16).toUpperCase())
  // Reserve the hash namespace so an ordinary literal ID cannot collide with a long ID.
  if (/^sha256-[a-f0-9]{64}$/.test(folder)) folder = '%73' + folder.slice(1)
  const hashed = folder.length > 240
  if (hashed) folder = 'sha256-' + [...await digest(userId)].map(byte => byte.toString(16).padStart(2, '0')).join('')
  return { filePath: `users/${folder}/日本語/snapshot.json`, displayFolder: folder, folderEncoding: hashed ? 'sha256' : 'percent' }
}
export async function userFilePath(userId) { return (await userLocation(userId)).filePath }

async function readLimited(response, limit) {
  const length = Number(response.headers.get('Content-Length'))
  if (Number.isFinite(length) && length > limit) throw new SyncError(413, 'PAYLOAD_TOO_LARGE', '数据超过 8 MiB，请减少导入内容后重试。')
  if (!response.body) return ''
  const reader = response.body.getReader()
  let total = 0
  const parts = []
  try {
    for (;;) {
      const { value, done } = await reader.read()
      if (done) break
      total += value.byteLength
      if (total > limit) {
        await reader.cancel()
        throw new SyncError(413, 'PAYLOAD_TOO_LARGE', '数据超过 8 MiB，请减少导入内容后重试。')
      }
      parts.push(value)
    }
  } finally { reader.releaseLock() }
  const bytes = new Uint8Array(total)
  let offset = 0
  for (const part of parts) { bytes.set(part, offset); offset += part.length }
  return decoder.decode(bytes)
}
function parseJSON(text) { try { return JSON.parse(text) } catch { throw invalid() } }
function encodeBase64(text) {
  const bytes = encoder.encode(text)
  let binary = ''
  for (let offset = 0; offset < bytes.length; offset += 8192) binary += String.fromCharCode(...bytes.subarray(offset, offset + 8192))
  return btoa(binary)
}

export function createSyncWorker({ fetch: upstream = globalThis.fetch, now = () => Date.now() } = {}) {
  const requests = new Map()
  function rateLimit(request) {
    // Best-effort per-isolate limit; production edge limits can complement this.
    const key = request.headers.get('CF-Connecting-IP') || 'unknown'
    const time = now()
    for (const [ip, record] of requests) if (time - record.start >= 60000) requests.delete(ip)
    let record = requests.get(key)
    if (!record) {
      if (requests.size >= 1000) throw new SyncError(429, 'RATE_LIMITED', '请求过于频繁，请一分钟后重试。')
      record = { start: time, count: 0 }; requests.set(key, record)
    }
    if (++record.count > 30) throw new SyncError(429, 'RATE_LIMITED', '请求过于频繁，请一分钟后重试。')
  }

  async function github(configuration, suffix = '', init = {}, raw = false) {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), 10000)
    try {
      const response = await upstream(`https://api.github.com/repos/${configuration.owner}/${configuration.repo}${suffix}`, {
        ...init, redirect: 'error', signal: controller.signal,
        headers: { Accept: raw ? 'application/vnd.github.raw+json' : 'application/vnd.github+json', Authorization: `Bearer ${configuration.token}`,
          'X-GitHub-Api-Version': '2026-03-10', 'User-Agent': 'QuietSpell-Sync', 'Content-Type': 'application/json' },
      })
      const text = await readLimited(response, raw ? MAX_BODY_BYTES : 2 * 1024 * 1024)
      let data
      try { data = raw ? text : text ? JSON.parse(text) : null } catch { throw unavailable() }
      return { status: response.status, data }
    } catch { throw unavailable() }
    finally { clearTimeout(timer) }
  }

  async function sync(request, env, operation) {
    const configuration = config(env)
    rateLimit(request)
    if (!(request.headers.get('Content-Type') || '').split(';')[0].trim().match(/^application\/json$/i)) {
      throw new SyncError(415, 'INVALID_REQUEST', '请使用 JSON 格式提交同步请求。')
    }
    let body
    try { body = parseJSON(await readLimited(request, MAX_BODY_BYTES)) }
    catch (error) { if (error instanceof SyncError) throw error; throw invalid() }
    if (!object(body)) throw invalid()
    if (!await validInvite(body.inviteCode, configuration.invite)) throw new SyncError(403, 'INVITE_INVALID', '邀请码不正确。')
    const { filePath, displayFolder, folderEncoding } = await userLocation(body.userId)
    if (operation === 'upload' && (!object(body.snapshot) || !(body.sha === null || typeof body.sha === 'string' && SHA.test(body.sha)))) throw invalid()
    // Fail closed if configured to a public repository, including one made public later.
    const repository = await github(configuration)
    if (repository.status !== 200 || repository.data?.private !== true) throw unavailable()
    const branch = configuration.branch || repository.data.default_branch
    if (typeof branch !== 'string' || !branch) throw unavailable()
    const contentsPath = `/contents/${filePath.split('/').map(encodeURIComponent).join('/')}`
    const current = await github(configuration, `${contentsPath}?ref=${encodeURIComponent(branch)}`)
    if (![200, 404].includes(current.status)) throw unavailable()
    if (current.status === 200 && (current.data?.type !== 'file' || !SHA.test(current.data?.sha || '') || current.data.size > MAX_BODY_BYTES)) throw unavailable()

    if (operation === 'download') {
      if (current.status === 404) throw new SyncError(404, 'NO_DATA', '此用户 ID 还没有上传数据。')
      let envelope
      // Contents JSON omits file data above 1 MiB; raw media supports the full 8 MiB.
      // Pin the raw read to the exact blob SHA so a concurrent update cannot mix data and SHA.
      const raw = await github(configuration, `/git/blobs/${current.data.sha}`, {}, true)
      if (raw.status !== 200) throw unavailable()
      try { envelope = JSON.parse(raw.data) } catch { throw unavailable() }
      if (envelope?.format !== 'quietspell-japanese-sync' || envelope.schemaVersion !== 1 || envelope.userId !== body.userId ||
          !object(envelope.snapshot) || typeof envelope.updatedAt !== 'string') throw unavailable()
      return { ok: true, userId: body.userId, sha: current.data.sha, updatedAt: envelope.updatedAt, displayFolder, folderEncoding, snapshot: envelope.snapshot }
    }

    if ((current.status === 404 && body.sha !== null) || (current.status === 200 && body.sha !== current.data.sha)) throw conflict()
    const updatedAt = new Date(now()).toISOString()
    const stored = JSON.stringify({ format: 'quietspell-japanese-sync', schemaVersion: 1, userId: body.userId, updatedAt, snapshot: body.snapshot }) + '\n'
    if (encoder.encode(stored).byteLength > MAX_BODY_BYTES) throw new SyncError(413, 'PAYLOAD_TOO_LARGE', '数据超过 8 MiB，请减少导入内容后重试。')
    const change = { message: 'Update Japanese learning snapshot', branch, content: encodeBase64(stored) }
    if (body.sha !== null) change.sha = body.sha
    const saved = await github(configuration, contentsPath, { method: 'PUT', body: JSON.stringify(change) })
    if (saved.status === 409) throw conflict()
    if (saved.status === 422) {
      // GitHub can return 422 for a racing first creation. Confirm a changed SHA.
      const latest = await github(configuration, `${contentsPath}?ref=${encodeURIComponent(branch)}`)
      if (latest.status === 200 && SHA.test(latest.data?.sha || '') && latest.data.sha !== body.sha) throw conflict()
      throw unavailable()
    }
    if (![200, 201].includes(saved.status) || !SHA.test(saved.data?.content?.sha || '')) throw unavailable()
    return { ok: true, userId: body.userId, sha: saved.data.content.sha, updatedAt, displayFolder, folderEncoding }
  }

  return {
    async fetch(request, env = {}) {
      const origin = request.headers.get('Origin')
      const headers = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
        Vary: 'Origin', 'X-Content-Type-Options': 'nosniff' }
      if (origin && ORIGINS.has(origin)) headers['Access-Control-Allow-Origin'] = origin
      function reply(data, status = 200) { return new Response(JSON.stringify(data), { status, headers }) }
      try {
        if (origin && !ORIGINS.has(origin)) throw new SyncError(403, 'ORIGIN_NOT_ALLOWED', '此来源不允许调用同步服务。')
        const url = new URL(request.url)
        if (url.search) throw invalid()
        const syncPath = ['/sync/upload', '/sync/download'].includes(url.pathname)
        if (request.method === 'OPTIONS' && syncPath) {
          headers['Access-Control-Allow-Methods'] = 'POST, OPTIONS'
          headers['Access-Control-Allow-Headers'] = 'Content-Type'
          headers['Access-Control-Max-Age'] = '600'
          return new Response(null, { status: 204, headers })
        }
        if (url.pathname === '/health' && request.method === 'GET') return reply({ ok: true, service: 'quietspell-sync' })
        if (!syncPath) throw new SyncError(404, 'NOT_FOUND', '接口不存在。')
        if (request.method !== 'POST') {
          headers.Allow = 'POST, OPTIONS'
          throw new SyncError(405, 'METHOD_NOT_ALLOWED', '请使用 POST 提交同步请求。')
        }
        return reply(await sync(request, env, url.pathname.endsWith('/upload') ? 'upload' : 'download'))
      } catch (error) {
        // Do not log request bodies, user IDs, invitation codes, tokens, or upstream errors.
        const safe = error instanceof SyncError ? error : new SyncError(500, 'INTERNAL_ERROR', '同步暂未完成，请稍后重试。')
        if ([429, 503].includes(safe.status)) headers['Retry-After'] = safe.status === 429 ? '60' : '30'
        return reply({ ok: false, error: { code: safe.code, message: safe.message } }, safe.status)
      }
    },
  }
}

export default createSyncWorker()
