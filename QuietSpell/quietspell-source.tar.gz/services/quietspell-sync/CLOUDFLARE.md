# Cloudflare Workers deployment

The existing Worker runs directly on Cloudflare Workers. This configuration does
not change the older Sites identity or its stored secrets. Use a Workers Free
account; do not enable paid plans or add unrelated storage products.

`wrangler.jsonc` names the Worker `quietspell-progress-sync`. The account is
selected through the owner's Wrangler authentication, not a committed account
credential. Check the selected account and existing Worker before deploying.

1. Install the official `wrangler` CLI in the workspace's isolated cache.
2. Run `wrangler login` and have the owner complete Cloudflare authorization.
3. Run `wrangler whoami`, then `wrangler deploy --dry-run` with this config.
4. Configure `GITHUB_OWNER`, `GITHUB_REPO`, `GITHUB_TOKEN`, and `INVITE_CODE` as
   encrypted Worker secrets. Send values through hidden interactive input or
   process stdin; do not create a plaintext secrets file or put values in argv.
   The GitHub token must cover only the dedicated private data repository.
5. Deploy the reviewed Worker and copy the actual returned `workers.dev` URL.
6. Test `/health`, wrong-invitation rejection, and synthetic upload/download with
   revision conflict protection. A local Worker-to-GitHub test is not evidence
   that the deployed endpoint works.
7. Have the owner test that exact endpoint on their phone without a VPN. Opening
   the Cloudflare dashboard alone does not establish endpoint reachability.
8. Set `NUXT_PUBLIC_JAPANESE_SYNC_ENDPOINT` to that verified endpoint when
   generating the public learning website. Publish only after the check passes.

The source contains only secret key names. Request logging and preview URLs are
disabled in this configuration. Data remains in the private GitHub repository,
including previous snapshots in Git history. The shared invitation authorizes
anyone holding it to access any known user ID; it is not individual account
isolation. The 8 MiB application limit and free-plan CPU/request limits still
apply. GitHub/Cloudflare operators are not excluded by end-to-end encryption.
