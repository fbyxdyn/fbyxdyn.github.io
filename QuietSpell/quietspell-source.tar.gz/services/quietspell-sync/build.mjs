import { mkdir, copyFile, readFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
await mkdir('dist/server', { recursive: true })
await copyFile('worker/index.mjs', 'dist/server/index.js')
// A real manifest is added by the Sites identity helper only after registration.
if (existsSync('.openai/hosting.json')) {
  const manifest = JSON.parse(await readFile('.openai/hosting.json', 'utf8'))
  if (!manifest.project_id || manifest.static) throw new Error('Expected a registered Worker hosting manifest.')
  await mkdir('dist/.openai', { recursive: true })
  await copyFile('.openai/hosting.json', 'dist/.openai/hosting.json')
}
// Registration is intentionally separate; local builds do not create or modify a Site.
console.log('Standalone sync Worker built; publication is a separate step.')
