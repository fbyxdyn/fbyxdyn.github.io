# QuietSpell manual Japanese progress sync

Independent Worker ESM service. Its registered Sites identity is stored in
`.openai/hosting.json`. Deployment and runtime secrets are managed separately;
the service fails closed until fully configured. The voice service is unchanged.

Run `node --test test.mjs` and `node build.mjs` from this directory. No dependencies.
The tests use synthetic credentials and an in-memory GitHub API substitute.

## API

Both endpoints require POST JSON. Never put an invitation code in a URL.

* `/sync/download`: `{userId, inviteCode}` returns
  `{ok:true,userId,sha,updatedAt,displayFolder,folderEncoding,snapshot}`.
* `/sync/upload`: `{userId,inviteCode,snapshot,sha}` returns the same fields without
  `snapshot`. `sha:null` creates a new ID; an existing ID requires its downloaded
  SHA. Missing or malformed SHA is 400. A stale SHA or competing write is 409.
* `/health`: GET returns the service name only, with no configuration or user data.

Errors are `{ok:false,error:{code,message}}`: invalid invitation 403
`INVITE_INVALID`; missing configuration 503 `NOT_CONFIGURED`; no uploaded data
404 `NO_DATA`; version conflict 409 `CONFLICT`; oversized body 413
`PAYLOAD_TOO_LARGE`; excessive requests 429 `RATE_LIMITED`. GitHub failures and
public-repository configuration fail closed with a generic 503.

The complete request and stored envelope are each limited to 8 MiB, counted while
reading the stream before JSON parsing. `snapshot` must be a JSON object; the
frontend validates its application-specific progress and settings schema before
upload and before applying a download. A download must replace only the intended
Japanese state, after the user explicitly chooses download; never auto-merge it.

## ID and file layout

An ID is any nonempty valid Unicode string, used exactly as entered: no trimming,
normalization or separate character limit. The overall 8 MiB request/file limits
still apply. Safe ASCII IDs name their directory directly. Other characters are
percent-encoded, including `. ! ' ( ) * ~`; `%` is also encoded. The GitHub API URL
encodes each resulting path segment again. The user cannot supply a storage path.

Files are `users/<encoded-ID>/日本語/snapshot.json`. If the encoded folder exceeds
240 bytes, use `sha256-<full SHA-256>` instead. Literal IDs matching that reserved
hash syntax escape their initial `s` to avoid collisions. Responses return the
actual folder name and `folderEncoding` (`percent` or `sha256`) for explanation in
the UI. The original ID always remains in the stored envelope and download result.

Each envelope contains `format`, `schemaVersion:1`, `userId`, server `updatedAt`,
and `snapshot`. Neither the request invitation nor GitHub token is included.
Downloads read the exact Git blob SHA; a concurrent write cannot mix an older SHA
with newer contents. Uploads use GitHub's atomic SHA check, with no force retry.

## Deployment configuration required later

Configure the runtime secret manager with `INVITE_CODE`, `GITHUB_TOKEN`,
`GITHUB_OWNER`, `GITHUB_REPO`; optionally `GITHUB_BRANCH` (otherwise default branch).
No real value belongs in `.env.example`, source, manifests, browser bundles,
logs or URLs. No local SSH key, credential-manager token or broad account token
should be transferred to this service.

Use a dedicated **private repository** and a fine-grained GitHub token selected
for **only that repository**, with Contents read/write and Metadata read. No
account administration, repository creation, Workflows or other repository access
is needed. The service checks the repository remains private on every operation.
Token scope selection itself must be configured and reviewed by its owner.

An invitation code is a shared access key, **not an individual login**. Anyone who
has it and knows an ID can read or replace that ID's data after obtaining its SHA.
Do not describe this as per-account privacy. Changing the shared code revokes all
holders. CORS permits only `https://fbyxdyn.github.io` and localhost port 5567;
non-browser requests must still present the invitation. There is a best-effort
30/minute/IP limit per Worker isolate; it is not a durable distributed rate limit.
Responses use `Cache-Control: no-store`. No request or upstream error is logged.

Git history retains earlier snapshots in the private repository. This is manual
backup/sync; it does not implement deletion or retention management.

GitHub reference: [Contents API](https://docs.github.com/en/rest/repos/contents)
and [raw Git blob API](https://docs.github.com/en/rest/git/blobs).

License: GPL-3.0-only, same as the main application.

Local release preparation: run `node prepare-release.mjs`. This runs the tests,
builds the Worker, and creates a source/build archive and hash manifest under
the workspace's `.cache/releases/quietspell-sync-ready-20261121`. See
`DEPLOYMENT.md` for the remaining registration and secret-configuration steps.
