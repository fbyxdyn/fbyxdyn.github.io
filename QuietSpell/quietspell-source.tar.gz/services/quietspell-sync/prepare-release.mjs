import { createHash } from 'node:crypto'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const root = path.dirname(fileURLToPath(import.meta.url))
const output = path.resolve(root, '../../.cache/releases/quietspell-sync-ready-20261121')
function run(command, args) {
  const result = spawnSync(command, args, { cwd: root, stdio: 'inherit' })
  if (result.error || result.status !== 0) throw result.error || new Error('Release preparation check failed.')
}
const files = ['worker/index.mjs', 'build.mjs', 'test.mjs', 'prepare-release.mjs',
  '.env.example', '.gitignore', 'README.md', 'DEPLOYMENT.md', 'LICENSE', 'dist/server/index.js']
const metadataPath = path.join(root, '.openai/hosting.json')
const identity = existsSync(metadataPath) ? JSON.parse(await readFile(metadataPath, 'utf8')).project_id : null
if (identity) files.push('.openai/hosting.json')
const example = await readFile(path.join(root, '.env.example'), 'utf8')
if (example.split(/\r?\n/).some(line => line.trim() && !line.trim().startsWith('#') && !/^[A-Z_]+=$/.test(line))) {
  throw new Error('The environment example must contain variable names with empty values only.')
}
run(process.execPath, ['--test', 'test.mjs'])
run(process.execPath, ['build.mjs'])
await mkdir(output, { recursive: true })
const archive = path.join(output, 'quietspell-sync-source-and-worker.tar.gz')
run('tar', ['-czf', archive, ...files])
const hash = data => createHash('sha256').update(data).digest('hex')
const hashes = Object.fromEntries(await Promise.all(files.map(async name => [name, hash(await readFile(path.join(root, name)))])))
if (hashes['worker/index.mjs'] !== hashes['dist/server/index.js']) throw new Error('Worker build does not match the source.')
const manifest = {
  status: 'ready-awaiting-secure-configuration', registered: !!identity, project_id: identity, deploymentVerified: false,
  requiredOwnerConfiguration: ['private repository URL', 'repository-scoped GitHub token via secret manager'],
  runtimeVariableNames: ['INVITE_CODE', 'GITHUB_TOKEN', 'GITHUB_OWNER', 'GITHUB_REPO', 'GITHUB_BRANCH (optional)'],
  userIdLimit: 'no separate character limit; nonempty valid Unicode within 8 MiB request/file limits',
  archive: path.basename(archive), archiveSha256: hash(await readFile(archive)), files: hashes,
  containsCredentials: false, includesUserProgress: false, ttsServiceModified: false,
}
await writeFile(path.join(output, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n')
await writeFile(path.join(output, 'DEPLOYMENT.md'), await readFile(path.join(root, 'DEPLOYMENT.md')))
console.log(JSON.stringify({ output, archive, archiveSha256: manifest.archiveSha256, status: manifest.status }))
